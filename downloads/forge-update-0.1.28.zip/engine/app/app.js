/* Forge app: vanilla JS, no build step. Talks to the engine at /api with the app key. */
(function () {
'use strict';
var $ = function (s, r) { return (r || document).querySelector(s); };
var el = function (tag, attrs, kids) {
  var e = document.createElement(tag);
  for (var k in (attrs || {})) { var v = attrs[k]; if (v == null || v === false) continue; if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? '' : v); }
  [].concat(kids || []).forEach(function (c) { if (c == null || c === false) return; e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
  return e;
};
var KEY = 'forge.key';
var store = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };

/* ───────── pixel textures ───────── */
var PAL = { grass: ['#5fae3b', '#4f9a31', '#6fc047', '#3f8a2a'], dirt: ['#7a5230', '#6b4527', '#8a5f3a', '#5d3b20'], stone: ['#8b8f8a', '#7a7e79', '#9a9e99', '#6c706b'], deep: ['#3a3d43', '#2f3238', '#45484f', '#25272c'], plank: ['#b08a4f', '#a07c45', '#bd9a5e', '#8e6e39'], gold: ['#e8b93c', '#c99a22', '#ffd866', '#8b8f8a'], diamond: ['#4fd5d0', '#35b5b1', '#8cf0ec', '#8b8f8a'], coal: ['#2a2a2a', '#1b1b1b', '#3a3a3a', '#8b8f8a'] };
function tex(name, size, seed) {
  var c = document.createElement('canvas'); c.width = c.height = size || 16;
  var x = c.getContext && c.getContext('2d'); if (!x) return null;
  var p = PAL[name], s = seed || 7, n = size || 16;
  function r() { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }
  for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) {
    var col = p[Math.floor(r() * 3)];
    if (name === 'grass' && j < 4) col = p[j < 3 || r() < .5 ? (r() < .5 ? 0 : 2) : 3];
    if ((name === 'gold' || name === 'diamond' || name === 'coal') && ((i * 7 + j * 3) % 11 < 3) && r() < .8) col = p[r() < .5 ? 0 : 2];
    if ((name === 'gold' || name === 'diamond' || name === 'coal') && !((i * 7 + j * 3) % 11 < 3)) col = PAL.stone[Math.floor(r() * 3)];
    x.fillStyle = col; x.fillRect(i, j, 1, 1);
  }
  return c;
}
function texUrl(name, size, seed) { var c = tex(name, size, seed); try { return c ? c.toDataURL() : ''; } catch (e) { return ''; } }
function applyTextures() {
  var g = texUrl('grass', 16, 3), d = texUrl('dirt', 16, 5);
  if (g) document.documentElement.style.setProperty('--tex-grass', 'url(' + g + ')');
  if (d) document.documentElement.style.setProperty('--tex-dirt', 'url(' + d + ')');
  var sty = document.createElement('style');
  sty.textContent = g ? 'body.fun main{background-image:linear-gradient(#0000,var(--bg) 140px),var(--tex-dirt);background-size:auto,64px;background-repeat:no-repeat,repeat;image-rendering:pixelated}body.fun .dirt-strip{height:12px;background:var(--tex-grass);background-size:48px;image-rendering:pixelated}' : '';
  document.head.appendChild(sty);
}
var ICONS = { office: 'plank', chat: 'gold', mods: 'diamond', sim: 'coal', versions: 'deep', settings: 'stone' };
function icon(name) { var c = document.createElement('canvas'); c.width = c.height = 16; var t = tex(ICONS[name], 16, name.length * 11); if (t) c.getContext('2d').drawImage(t, 0, 0); return c; }

/* ───────── sound (made on the fly, no files) ───────── */
var fx = (function () {
  var ctx = null;
  function on() { return store.get('forge.sound') !== 'off' && state.settings.sound !== false; }
  function c() { if (!on()) return null; try { if (!ctx) { var C = window.AudioContext || window.webkitAudioContext; if (!C) return null; ctx = new C(); } if (ctx.state === 'suspended') ctx.resume(); return ctx; } catch (e) { return null; } }
  function tone(f, t, d, type, g, to) { var a = c(); if (!a) return; var o = a.createOscillator(), v = a.createGain(); o.type = type || 'square'; var t0 = a.currentTime + t; o.frequency.setValueAtTime(f, t0); if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + d); v.gain.setValueAtTime(.0001, t0); v.gain.exponentialRampToValueAtTime(g || .06, t0 + .008); v.gain.exponentialRampToValueAtTime(.0001, t0 + d); o.connect(v); v.connect(a.destination); o.start(t0); o.stop(t0 + d + .02); }
  function noise(t, d, g) { var a = c(); if (!a) return; var b = a.createBuffer(1, Math.floor(a.sampleRate * d), a.sampleRate), data = b.getChannelData(0); for (var i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length); var s = a.createBufferSource(), v = a.createGain(), fl = a.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 900; s.buffer = b; v.gain.value = g || .08; s.connect(fl); fl.connect(v); v.connect(a.destination); s.start(a.currentTime + t); }
  var S = {
    click: function () { tone(220, 0, .05, 'square', .05, 150); },
    nav: function () { tone(330, 0, .05, 'square', .04); tone(440, .05, .05, 'square', .04); },
    send: function () { tone(520, 0, .06, 'triangle', .07); tone(780, .06, .08, 'triangle', .06); },
    receive: function () { tone(660, 0, .08, 'triangle', .06); tone(520, .08, .1, 'triangle', .05); },
    approve: function () { tone(523, 0, .09, 'square', .05); tone(659, .09, .09, 'square', .05); tone(784, .18, .16, 'square', .05); },
    decline: function () { tone(200, 0, .14, 'sawtooth', .05, 110); },
    hammer: function () { noise(0, .06, .1); tone(140, 0, .08, 'square', .06, 70); },
    pass: function () { tone(880, 0, .07, 'sine', .07); tone(1175, .07, .1, 'sine', .06); },
    fail: function () { tone(160, 0, .22, 'sawtooth', .06, 70); noise(0, .15, .06); },
    built: function () { noise(0, .08, .1); tone(120, 0, .1, 'square', .07); tone(523, .1, .08, 'square', .05); tone(784, .18, .12, 'square', .05); },
    ship: function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, i * .09, .14, 'square', .05); }); },
    alert: function () { tone(740, 0, .1, 'square', .06); tone(740, .16, .1, 'square', .06); }
  };
  return { play: function (n) { try { if (S[n]) S[n](); } catch (e) {} } };
})();

/* ───────── api ───────── */
function key() { return store.get(KEY) || ''; }
function Unauthorized() {}
function api(method, path, body) {
  return fetch('/api' + path, { method: method, headers: { authorization: 'Bearer ' + key(), 'content-type': 'application/json' }, body: body == null ? undefined : JSON.stringify(body) }).then(function (r) {
    if (r.status === 401) throw new Unauthorized();
    if (!r.ok) throw new Error(r.status);
    return r.json();
  });
}

/* ───────── state ───────── */
var state = { data: null, setup: null, update: null, events: [], lastN: 0, tab: 'office', chat: [], typing: false, sel: null, settings: {}, seenCards: {}, seenLayers: {}, seenStages: {}, toast: '', sheet: null, auth: true };
var TABS = [['office', 'Office'], ['chat', 'Chat'], ['mods', 'Mods'], ['sim', 'Tests'], ['versions', 'Versions'], ['settings', 'Setup']];
var AGENT_NAME = { foreman: 'Foreman', coder: 'Coder', builder: 'Builder', tester: 'Tester', scout: 'Scout', publisher: 'Publisher' };
var LAYER_NAME = { static: 'Static', boot: 'Boot', scenario: 'Scenario', soak: 'Soak', compat: 'Compat', multiplayer: 'Multiplayer', regression: 'Regression' };
var LAYER_HELP = { static: 'Files, JSON, mixin list and safety rules', boot: 'A real server starts with the mod', scenario: 'A script of commands played on a real server, checking what the mod does', soak: 'Long simulated game time, watching ticks and memory', compat: 'A real server with popular mods (Lithium, FerriteCore, ModernFix, Spark, C2ME)', multiplayer: 'Several players on one server (off unless you turn it on in Settings)', regression: 'Old bugs stay fixed' };
var STAGE_TEXT = { queued: 'Waiting', spec: 'Planning', code: 'Writing', build: 'Building', test: 'Testing', review: 'Reviewing', ready: 'Ready', built: 'Built', shipped: 'Shipped', parked: 'Parked', stopped: 'Stopped', waiting: 'Needs you' };
var $app = null, scene = null;

function toast(t) { state.toast = t; var n = el('div', { class: 'toast', text: t }); document.body.appendChild(n); setTimeout(function () { n.remove(); }, 2600); }
function ago(at) { var s = Math.max(0, Math.round((Date.now() - at) / 1000)); return s < 60 ? s + 's' : s < 3600 ? Math.round(s / 60) + 'm' : Math.round(s / 3600) + 'h'; }
function clock(at) { var d = new Date(at); return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
function esc(s) { return String(s == null ? '' : s); }
function money(n) { return '$' + (Math.round(n * 100) / 100).toFixed(2); }

/* ───────── data loop ───────── */
function refresh(auto) {
  return Promise.all([api('GET', '/state'), api('GET', '/events/since/' + state.lastN)]).then(function (r) {
    state.auth = true; var d = r[0], ev = r[1];
    state.data = d; state.settings = Object.assign({}, state.settings);
    (ev.events || []).forEach(function (e) { if (e.data && e.data.chat && state.booted) { state.chat.push({ from: 'foreman', text: e.text }); fx.play('receive'); updateChat(); } state.events.push(e); state.lastN = Math.max(state.lastN, e.n); soundFor(e); });
    if (state.events.length > 400) state.events.splice(0, state.events.length - 400);
    d.cards.forEach(function (c) { if (!state.seenCards[c.id]) { state.seenCards[c.id] = 1; if (state.booted) fx.play('alert'); } });
    state.booted = true;
    if (!state.chatLoaded) { state.chatLoaded = true; api('GET', '/chat').then(function (h) { if (!state.chat.length && h && h.length) { state.chat = h.map(function (m) { return { from: m.from, text: m.text }; }); updateChat(); } }).catch(function () {}); }
    // Only redraw when something actually changed, so scrolling and typing are never interrupted.
    var key = JSON.stringify(d, function (k, v) { return k === 'now' ? undefined : v; }) + '|' + state.lastN + '|' + (state.settings && state.settings.fun);
    if (auto === true && key === state.lastKey && $('#shell')) return;
    state.lastKey = key;
    render();
  }).catch(function (e) { if (e instanceof Unauthorized) { state.auth = false; renderPair(); } else { var f = $('#conn'); if (f) f.textContent = 'offline'; } });
}
function soundFor(e) {
  if (!state.booted) return;
  if (e.kind === 'layer') fx.play(e.data && e.data.state === 'pass' ? 'pass' : 'fail');
  else if (e.kind === 'build') fx.play(e.data && e.data.ok ? 'built' : 'fail');
  else if (e.kind === 'tool' && e.agent === 'coder') fx.play('hammer');
  else if (e.kind === 'ship') fx.play('ship');
  else if (e.kind === 'block') fx.play('decline');
}

/* ───────── pairing ───────── */
function renderPair() {
  $app.innerHTML = '';
  var inp = el('input', { placeholder: 'xxxx-xxxx-xxxx-xxxx', autocapitalize: 'none', autocomplete: 'off' });
  $app.appendChild(el('main', {}, el('div', { class: 'wrap' }, el('div', { class: 'card', style: 'max-width:460px;margin:40px auto' }, [
    el('h2', { class: 'mc', text: 'Connect to Forge' }),
    el('p', { class: 'dim', text: 'Type the app key shown on your computer (Settings, Phone). It is stored on this device only.' }),
    inp, el('div', { style: 'height:10px' }), el('button', { class: 'btn go', text: 'Connect', onclick: function () { store.set(KEY, inp.value.trim()); refresh(); } })
  ]))));
}
function getLocalKey() {
  var m = location.hash.match(/[?&]key=([\w-]+)/);
  if (m) { store.set(KEY, m[1]); location.hash = location.hash.replace(/[?&]key=[\w-]+/, ''); return Promise.resolve(); }
  if (key()) return Promise.resolve();
  return fetch('/api/app/key').then(function (r) { return r.ok ? r.json() : null; }).then(function (j) { if (j && j.token) store.set(KEY, j.token); }).catch(function () {});
}

/* ───────── shell ───────── */
function applyTheme(t) { document.documentElement.setAttribute('data-theme', t || 'dark'); store.set('forge.theme', t || 'dark'); }
function render() {
  if (!state.data) return;
  var d = state.data;
  document.body.classList.toggle('fun', !!(state.settings && state.settings.fun));
  var cards = d.cards.length;
  var existing = $('#shell');
  if (!existing) {
    $app.innerHTML = ''; $app.className = 'cols';
    var nav0 = el('nav', { class: 'side', id: 'nav' });
    var col = el('div', { class: 'col' });
    col.appendChild(el('header', { class: 'top', id: 'top' })); col.appendChild(el('main', { id: 'shell' }));
    $app.appendChild(nav0); $app.appendChild(col);
  }
  var top = $('#top'); top.innerHTML = '';
  var TITLES = { office: ['Office', 'What Forge is doing right now.'], chat: ['Chat', 'Talk to the Foreman.'], mods: ['Mods', 'Everything Forge has made.'], sim: ['Tests', 'How each mod was tested.'], versions: ['Versions', 'Minecraft versions Forge can build for.'], settings: ['Setup', 'Keys, budget and look.'] };
  var tt = TITLES[state.tab] || ['Forge', ''];
  top.appendChild(el('div', {}, [el('h1', { text: tt[0] }), el('div', { class: 'sub', text: tt[1] })]));
  top.appendChild(el('span', { class: 'grow' }));
  top.appendChild(el('span', { class: 'pill ' + (d.mode === 'claude' ? 'ok' : 'warn') + ' hide', id: 'modepill', text: d.mode === 'claude' ? 'Claude' : 'Demo mode' }));
  top.appendChild(el('span', { class: 'pill hide', text: money(d.aiMonthCost) + ' / ' + money(d.aiBudget) }));
  var apOn = !!(d.autopilot && d.autopilot.on);
  top.appendChild(el('button', { class: 'btn ' + (apOn ? 'go' : ''), id: 'auto', text: apOn ? 'Autopilot ON' : 'Autopilot', onclick: function () { toggleAutopilot(!apOn); } }));
  top.appendChild(el('button', { class: 'btn ' + (d.paused ? 'go' : 'no'), id: 'kill', text: d.paused ? 'Resume' : 'Stop all', onclick: function () { api('POST', '/pause', { paused: !d.paused }).then(function () { fx.play(d.paused ? 'approve' : 'decline'); refresh(); }); } }));
  var nav = $('#nav'); nav.innerHTML = '';
  nav.appendChild(el('div', { class: 'logo' }, [el('img', { src: 'icon.svg', alt: '' }), 'FORGE']));
  TABS.forEach(function (t) {
    var b = el('button', { class: state.tab === t[0] ? 'on' : '', 'data-tab': t[0], onclick: function () { state.tab = t[0]; fx.play('nav'); state.sel = state.sel; render(); } }, [icon(t[0] === 'sim' ? 'sim' : t[0]), t[1]]);
    if (t[0] === 'office' && cards) b.appendChild(el('span', { class: 'badge', text: String(cards) }));
    nav.appendChild(b);
  });
  var busy = d.projects.filter(function (p) { return ['queued', 'research', 'spec', 'code', 'build', 'test', 'review'].indexOf(p.stage) >= 0; }).length;
  nav.appendChild(el('div', { class: 'sess' }, [el('b', { text: 'This session' }), busy + (busy === 1 ? ' mod' : ' mods') + ' in progress', el('br'), 'AI spend: ' + money(d.aiMonthCost) + ' of ' + money(d.aiBudget)]));
  var main = $('#shell');
  var keepScroll = main.scrollTop; var chatBox = $('.msgs', main); var chatBottom = chatBox ? chatBox.scrollHeight - chatBox.scrollTop - chatBox.clientHeight < 40 : true;
  if (state.tab === 'chat' && state.typingInput !== undefined && $('#chatin', main) && document.activeElement === $('#chatin', main)) { /* keep typing: only update messages */ updateChat(); return; }
  if (state.tab === 'settings' && main.contains(document.activeElement) && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return; // never rebuild under the cursor
  if (state.tab === 'mods' && state.newModOpen && main.contains(document.activeElement) && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
  main.innerHTML = '';
  var wrap = el('div', { class: 'wrap' });
  main.appendChild(wrap);
  var view = { office: viewOffice, chat: viewChat, mods: viewMods, sim: viewSim, versions: viewVersions, settings: viewSettings }[state.tab];
  view(wrap, d);
  main.scrollTop = keepScroll; requestAnimationFrame(function () { if (main.scrollTop !== keepScroll) main.scrollTop = keepScroll; });
  if (state.tab === 'chat') { var nb = $('.msgs', main); if (nb && chatBottom) nb.scrollTop = nb.scrollHeight; }
  if (state.sheet) showSheet(); else { var sh = $('#sheet'); if (sh) sh.remove(); }
}

/* ───────── cards ───────── */
function cardView(c) {
  var b = el('div', { class: 'card ask', 'data-card': c.id }, [
    el('div', { class: 'row between' }, [el('h3', { class: 'mc', text: c.title }), el('span', { class: 'ag ' + c.agent, text: AGENT_NAME[c.agent] || c.agent })]),
    el('div', { class: 'why', text: c.why }),
    el('div', { class: 'yn' }, [el('div', { text: 'Yes: ' + c.ifYes }), el('div', { text: 'No: ' + c.ifNo })]),
    el('div', { class: 'row' }, [
      el('button', { class: 'btn go', text: c.kind === 'publish' ? 'Publish' : 'Yes', onclick: function () { decide(c, 'yes'); } }),
      el('button', { class: 'btn no', text: 'No', onclick: function () { decide(c, 'no'); } }),
      el('button', { class: 'btn', text: 'Later', onclick: function () { decide(c, 'later'); } }),
      el('span', { class: 'dim small', text: c.expiresAt == null ? 'Waits for you, never times out' : 'Counts as "no" if unanswered' })
    ])
  ]);
  return b;
}
function decide(c, v) { fx.play(v === 'yes' ? 'approve' : v === 'no' ? 'decline' : 'click'); api('POST', '/cards/' + c.id, { decision: v }).then(function (r) { toast(r.message || 'Done'); refresh(); }); }

/* ───────── office ───────── */
function toggleAutopilot(on) {
  api('POST', '/autopilot', { on: on }).then(function (r) { toast(r.message); fx.play(on ? 'approve' : 'decline'); refresh(); }).catch(function () { toast('Could not reach Forge.'); });
}
function autopilotCard(d) {
  var a = d.autopilot || { on: false, rounds: 0, note: '' };
  var c = el('div', { class: 'card' + (a.on ? ' ap-on' : '') }, [
    el('div', { class: 'row between' }, [el('h3', { class: 'mc', style: 'margin:0', text: 'Autopilot' }), el('span', { class: 'stage ' + (a.on ? 'ready' : 'stopped'), text: a.on ? 'On' : 'Off' })]),
    el('p', { class: 'dim', text: a.on
      ? 'Running on its own' + (a.since ? ' since ' + clock(a.since) : '') + '. ' + a.rounds + (a.rounds === 1 ? ' improvement' : ' improvements') + ' started so far. It says yes to safe steps, retries stuck mods, and keeps improving your mods. It never publishes, and it stops by itself at your monthly budget. Stop it here or on your phone any time.'
      : 'Turn this on and walk away. Forge keeps building, retrying and improving your mods without asking, until you stop it. It never publishes, and it stops by itself at your monthly budget.' }),
    a.note ? el('div', { class: 'dim small', text: a.note }) : null,
    el('div', { style: 'height:8px' }),
    el('button', { class: 'btn ' + (a.on ? 'no' : 'go'), text: a.on ? 'Stop Autopilot' : 'Start Autopilot', onclick: function () { toggleAutopilot(!a.on); } })
  ]);
  return c;
}
function viewOffice(w, d) {
  w.appendChild(autopilotCard(d));
  d.cards.forEach(function (c) { w.appendChild(cardView(c)); });
  var cv = el('canvas', { class: 'scene', id: 'scene', width: 640, height: 280 });
  if (state.settings && state.settings.fun) w.appendChild(el('div', { class: 'card' }, [el('div', { class: 'row between' }, [el('h3', { class: 'mc', text: 'The workshop' }), el('span', { class: 'dim small', id: 'conn', text: d.toolchain === 'simulated' ? 'pretend tools (demo)' : 'real tools' })]), cv]));
  if (state.settings && state.settings.fun) startScene(cv);
  var work = d.projects.filter(function (p) { return ['queued', 'research', 'spec', 'code', 'build', 'test', 'review'].indexOf(p.stage) >= 0; });
  var row = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Now' })]);
  if (!work.length) row.appendChild(el('div', { class: 'dim', text: 'Nothing is being built. Tell the Foreman what you want, or tap an idea:' }));
  work.forEach(function (p) { row.appendChild(modRow(p)); });
  var chips = el('div', { class: 'chips', style: 'margin-top:8px' });
  ['make a mod where sleeping through the night is faster with more players in bed', 'make a mod where hoppers stop lagging the server', 'make a mod that shows how long a crop needs to grow'].forEach(function (t) { chips.appendChild(el('span', { class: 'chip', text: t.replace('make a mod ', ''), onclick: function () { sendChat(t); state.tab = 'chat'; render(); } })); });
  row.appendChild(chips);
  w.appendChild(row);
  var feed = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'What the team is doing' })]);
  var f = el('div', { class: 'feed', id: 'feed' }); fillFeed(f); feed.appendChild(f); w.appendChild(feed);
}
function fillFeed(f) {
  f.innerHTML = '';
  state.events.slice(-60).reverse().forEach(function (e) { f.appendChild(el('div', {}, [el('time', { text: clock(e.at) }), el('span', { class: 'ag ' + e.agent, text: AGENT_NAME[e.agent] || e.agent }), el('span', { text: e.text })])); });
}
function modRow(p) {
  return el('div', { class: 'row between', style: 'padding:6px 0;cursor:pointer', onclick: function () { state.sel = p.id; state.tab = 'mods'; render(); } }, [
    el('span', {}, [el('b', { text: p.name }), el('span', { class: 'dim', text: '  Minecraft ' + p.profile })]),
    el('span', { class: 'row' }, [layerStrip(p), el('span', { class: 'stage ' + p.stage, text: STAGE_TEXT[p.stage] || p.stage })])
  ]);
}
function layerStrip(p, big) {
  var s = el('div', { class: 'layers' });
  Object.keys(LAYER_NAME).forEach(function (l) {
    var r = p.layers[l]; var running = !r && p.stage === 'test';
    s.appendChild(el('div', { class: 'lt ' + (r ? r.state : running ? 'run' : ''), title: LAYER_NAME[l] + (r ? ': ' + r.detail : ''), text: r ? (r.state === 'pass' ? '✓' : r.state === 'fail' ? '✗' : '–') : LAYER_NAME[l][0] }));
  });
  return s;
}

/* office scene: pixel workers, animated by what each agent is doing */
var SKIN = '#e0b48c';
var ROLE = { foreman: { body: '#3f8f2a', hair: '#e8b93c', item: 'crown' }, coder: { body: '#4aa3df', hair: '#5b3a1e', item: 'pick' }, builder: { body: '#e07b39', hair: '#333', item: 'hammer' }, tester: { body: '#9a6ad8', hair: '#222', item: 'goggles' }, scout: { body: '#b08a5a', hair: '#7a4a1e', item: 'map' }, publisher: { body: '#e9ece6', hair: '#6c706b', item: 'chest' } };
var SPOTS = { foreman: [320, 90], 'coder:1': [110, 150], 'coder:2': [190, 150], builder: [300, 195], 'tester:1': [440, 150], 'tester:2': [500, 150], 'tester:3': [560, 150], scout: [60, 70], publisher: [580, 70] };
function startScene(cv) {
  if (scene && scene.stop) scene.stop();
  var x = cv.getContext && cv.getContext('2d'); if (!x) return;
  var run = true, t0 = Date.now(), raf = 0; var motion = state.settings.animations !== false && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  var grass = tex('grass', 16, 3), dirt = tex('dirt', 16, 5), plank = tex('plank', 16, 9), stone = tex('stone', 16, 2);
  var parts = [];
  function frame() {
    if (!run || !document.body.contains(cv)) return;
    var t = (Date.now() - t0) / 1000; var d = state.data; if (!d) return;
    x.imageSmoothingEnabled = false;
    // back wall and floor
    for (var i = 0; i < 40; i++) for (var j = 0; j < 18; j++) { var tx = j < 3 ? grass : j < 6 ? dirt : (j < 13 ? stone : plank); if (tx) x.drawImage(tx, i * 16, j * 16); }
    x.fillStyle = '#0006'; x.fillRect(0, 96, 640, 6);
    // windows with a day/night sky
    var day = (Math.sin(t / 12) + 1) / 2;
    for (var k = 0; k < 3; k++) { x.fillStyle = 'rgb(' + Math.round(20 + 110 * day) + ',' + Math.round(30 + 150 * day) + ',' + Math.round(70 + 160 * day) + ')'; x.fillRect(200 + k * 80, 108, 44, 40); x.fillStyle = '#000'; x.fillRect(200 + k * 80 + 20, 108, 4, 40); x.fillRect(200 + k * 80, 126, 44, 4); }
    // furniture
    furniture(x, t);
    var ag = {}; d.agents.forEach(function (a) { var id = a.worker ? a.id + ':' + a.worker : a.id; ag[id] = a; });
    Object.keys(SPOTS).forEach(function (id) {
      var a = ag[id]; var role = id.split(':')[0]; var working = a && a.state === 'working'; var sp = SPOTS[id];
      var off = motion ? (working ? Math.sin(t * 9 + sp[0]) * 2 : Math.sin(t * 1.4 + sp[0]) * 1) : 0;
      person(x, sp[0], sp[1] + off, ROLE[role], working, t, motion);
      if (working && motion && Math.random() < .12) parts.push({ x: sp[0] + 10, y: sp[1] - 4, vx: (Math.random() - .5) * 40, vy: -30 - Math.random() * 30, life: 1, c: role === 'builder' ? '#ffb347' : role === 'tester' ? '#9a6ad8' : '#ffd866' });
      if (a && a.state === 'working') bubble(x, sp[0], sp[1] - 34, a.doing || '…');
    });
    for (var q = parts.length - 1; q >= 0; q--) { var p = parts[q]; p.life -= .02; p.x += p.vx * .016; p.y += p.vy * .016; p.vy += 80 * .016; if (p.life <= 0) { parts.splice(q, 1); continue; } x.globalAlpha = p.life; x.fillStyle = p.c; x.fillRect(Math.round(p.x), Math.round(p.y), 3, 3); x.globalAlpha = 1; }
    if (motion) raf = requestAnimationFrame(frame);
  }
  scene = { stop: function () { run = false; cancelAnimationFrame(raf); } };
  frame(); if (!motion) { setInterval(function () { if (run && document.body.contains(cv)) frame(); }, 1500); }
}
function furniture(x, t) {
  function box(a, b, w, h, c) { x.fillStyle = c; x.fillRect(a, b, w, h); x.fillStyle = '#0005'; x.fillRect(a, b + h - 3, w, 3); }
  box(290, 100, 60, 18, '#7a5230'); // foreman desk
  box(90, 160, 120, 14, '#a07c45'); // coder bench
  box(420, 160, 170, 14, '#a07c45'); // test bench
  [[440, 140], [500, 140], [560, 140]].forEach(function (m, i) { x.fillStyle = '#111'; x.fillRect(m[0] - 12, m[1] - 20, 24, 16); x.fillStyle = (Math.floor(t * 2 + i) % 2) ? '#4fd5d0' : '#35b5b1'; x.fillRect(m[0] - 10, m[1] - 18, 20, 12); });
  box(270, 205, 60, 14, '#555'); x.fillStyle = '#ff7a1a'; x.fillRect(278, 196, 8, 8); x.fillStyle = '#ffd866'; x.fillRect(280, 198 - Math.floor(Math.abs(Math.sin(t * 6)) * 3), 4, 4); // anvil + forge fire
  box(40, 80, 44, 14, '#8e6e39'); x.fillStyle = '#e9ece6'; x.fillRect(48, 76, 28, 6); // map table
  box(560, 80, 44, 16, '#8e6e39'); x.fillStyle = '#e8b93c'; x.fillRect(570, 74, 24, 8); // chest
}
function person(x, px, py, r, working, t, motion) {
  px = Math.round(px); py = Math.round(py);
  x.fillStyle = '#0005'; x.fillRect(px - 8, py + 22, 18, 4);
  x.fillStyle = '#2b3a55'; x.fillRect(px - 5, py + 14, 4, 9); x.fillRect(px + 1, py + 14, 4, 9);
  x.fillStyle = r.body; x.fillRect(px - 6, py + 4, 12, 11);
  x.fillStyle = SKIN; x.fillRect(px - 5, py - 6, 10, 10);
  x.fillStyle = r.hair; x.fillRect(px - 5, py - 7, 10, 3);
  var blink = motion && Math.floor(t * 1.3 + px) % 7 === 0;
  x.fillStyle = '#000'; if (!blink) { x.fillRect(px - 3, py - 1, 2, 2); x.fillRect(px + 1, py - 1, 2, 2); } else { x.fillRect(px - 3, py, 2, 1); x.fillRect(px + 1, py, 2, 1); }
  var sw = working && motion ? Math.sin(t * 10 + px) : 0;
  x.fillStyle = SKIN; x.fillRect(px + 6, py + 6 + Math.round(sw * 3), 3, 6);
  if (r.item === 'crown') { x.fillStyle = '#ffd866'; x.fillRect(px - 5, py - 10, 10, 3); x.fillRect(px - 5, py - 12, 2, 2); x.fillRect(px - 1, py - 12, 2, 2); x.fillRect(px + 3, py - 12, 2, 2); }
  if (r.item === 'pick') { x.fillStyle = '#7a5230'; x.fillRect(px + 8, py + 2 + Math.round(sw * 3), 2, 12); x.fillStyle = '#8cf0ec'; x.fillRect(px + 5, py + Math.round(sw * 3), 8, 3); }
  if (r.item === 'hammer') { x.fillStyle = '#7a5230'; x.fillRect(px + 8, py + 4 + Math.round(sw * 4), 2, 10); x.fillStyle = '#8b8f8a'; x.fillRect(px + 5, py + 2 + Math.round(sw * 4), 8, 4); }
  if (r.item === 'goggles') { x.fillStyle = '#4fd5d0'; x.fillRect(px - 5, py - 2, 10, 3); x.fillStyle = '#000'; x.fillRect(px - 1, py - 2, 2, 3); }
  if (r.item === 'map') { x.fillStyle = '#e9ece6'; x.fillRect(px + 7, py + 4, 8, 8); x.fillStyle = '#5fae3b'; x.fillRect(px + 9, py + 6, 3, 3); }
  if (r.item === 'chest') { x.fillStyle = '#b08a4f'; x.fillRect(px + 7, py + 6, 9, 7); x.fillStyle = '#e8b93c'; x.fillRect(px + 10, py + 8, 3, 2); }
}
function bubble(x, px, py, text) {
  text = text.length > 26 ? text.slice(0, 25) + '…' : text; x.font = '10px monospace'; var w = Math.ceil(x.measureText(text).width) + 10; var bx = Math.max(2, Math.min(640 - w - 2, px - w / 2));
  x.fillStyle = '#000'; x.fillRect(bx - 2, py - 12, w + 4, 18); x.fillStyle = '#f7f7ef'; x.fillRect(bx, py - 10, w, 14); x.fillStyle = '#111'; x.fillText(text, bx + 5, py);
}

/* ───────── chat ───────── */
function viewChat(w) {
  var box = el('div', { class: 'card chat' });
  var msgs = el('div', { class: 'msgs' }); box.appendChild(msgs);
  var inp = el('textarea', { id: 'chatin', rows: 2, placeholder: 'Tell the Foreman what mod you want, or ask how things are going…', maxlength: 2000 });
  inp.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
  function go() { var t = inp.value.trim(); if (!t) return; inp.value = ''; sendChat(t); }
  box.appendChild(el('div', { class: 'row', style: 'margin-top:8px;flex-wrap:nowrap' }, [inp, el('button', { class: 'btn go', text: 'Send', onclick: go })]));
  w.appendChild(box); state.typingInput = true; fillChat(msgs);
  if (state.chatDraft) { inp.value = state.chatDraft; state.chatDraft = ''; setTimeout(function () { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }, 0); }
}
function fillChat(msgs) {
  msgs.innerHTML = '';
  if (!state.chat.length) msgs.appendChild(el('div', { class: 'bub foreman', text: 'Hi! I\'m the Foreman. Tell me about a mod you want in your own words and I\'ll get the team building and testing it. I\'ll only interrupt you when a decision is yours.' }));
  state.chat.forEach(function (m) { msgs.appendChild(el('div', { class: 'bub ' + m.from, text: m.text })); });
  if (state.typing) msgs.appendChild(el('div', { class: 'bub foreman typing' }, [el('span'), el('span'), el('span')]));
  msgs.scrollTop = msgs.scrollHeight;
}
function updateChat() { var m = $('.msgs'); if (m) fillChat(m); }
function sendChat(text) {
  state.chat.push({ from: 'you', text: text }); state.typing = true; fx.play('send'); updateChat();
  api('POST', '/chat', { text: text }).then(function (r) { state.chat.push({ from: 'foreman', text: r.reply }); state.typing = false; fx.play('receive'); updateChat(); refresh(); }).catch(function () { state.typing = false; state.chat.push({ from: 'foreman', text: 'I couldn\'t reach the engine. Check that Forge is running.' }); updateChat(); });
}

/* ───────── mods ───────── */
function viewMods(w, d) {
  var head = el('div', { class: 'row between' }, [el('h2', { class: 'mc', style: 'margin:0', text: 'Your mods' }), el('button', { class: 'btn go', text: 'New mod', onclick: function () { state.newModOpen = true; state.sheet = 'new'; render(); } })]);
  w.appendChild(head);
  if (state.sel) { var p = d.projects.filter(function (x) { return x.id === state.sel; })[0]; if (p) { modDetail(w, p, d); return; } }
  if (!d.projects.length) w.appendChild(el('div', { class: 'card dim', text: 'No mods yet. Tell the Foreman an idea in Chat, or press New mod.' }));
  var g = el('div', { class: 'mods' });
  d.projects.slice().reverse().forEach(function (p) {
    g.appendChild(el('div', { class: 'card mod', onclick: function () { state.sel = p.id; render(); } }, [
      el('div', { class: 'row between' }, [el('b', { class: 'mc', text: p.name }), el('span', { class: 'stage ' + p.stage, text: STAGE_TEXT[p.stage] || p.stage })]),
      el('div', { class: 'dim small', text: 'Minecraft ' + p.profile + ' · ' + p.mode + (p.note ? ' · ' + p.note : '') }),
      el('div', { style: 'height:8px' }), layerStrip(p)
    ]));
  });
  w.appendChild(g);
}
function modDetail(w, p, d) {
  var ideaParts = String(p.idea).split(/\n(?:Follow-up from Brian|Improvement|Playtest): /);
  var done = Object.keys(p.layers).filter(function (l) { return p.layers[l].state === 'pass'; }).length;
  var need = Object.keys(LAYER_NAME).filter(function (l) { return !(p.layers[l] && p.layers[l].off); }).length;
  w.appendChild(el('button', { class: 'btn', text: '← All mods', onclick: function () { state.sel = null; render(); } }));
  var c = el('div', { class: 'card' }, [
    el('div', { class: 'row between' }, [el('h2', { class: 'mc', style: 'margin:0', text: p.name }), el('span', { class: 'stage ' + p.stage, text: STAGE_TEXT[p.stage] || p.stage })]),
    el('p', { text: ideaParts[0] }),
    ideaParts.length > 1 ? el('div', { class: 'dim small' }, ideaParts.slice(1).map(function (x) { return el('div', { text: '+ ' + x }); })) : null,
    el('div', { class: 'dim small', text: 'id ' + p.modId + ' · Minecraft ' + p.profile + ' · ' + p.mode + ' · ' + p.files + ' files · ' + p.tokens.toLocaleString() + ' tokens · ' + money(p.cost) }),
    p.note ? el('div', { class: 'pill warn', style: 'margin-top:8px;display:inline-block', text: p.note }) : null,
    el('div', { style: 'height:10px' }), el('div', { class: 'bar' }, el('i', { style: 'width:' + Math.round(done / need * 100) + '%' })),
    el('div', { class: 'dim small', text: done + ' of ' + need + ' test layers passed' + (need < 7 ? ' (' + (7 - need) + ' turned off)' : '') })
  ]);
  w.appendChild(c);
  var lc = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Tests' })]);
  Object.keys(LAYER_NAME).forEach(function (l) {
    var r = p.layers[l];
    lc.appendChild(el('div', { class: 'row', style: 'padding:4px 0;flex-wrap:nowrap' }, [el('div', { class: 'lt ' + (r ? r.state : ''), text: r ? (r.state === 'pass' ? '✓' : r.state === 'fail' ? '✗' : '–') : LAYER_NAME[l][0] }), el('div', {}, [el('b', { text: LAYER_NAME[l] }), el('div', { class: 'dim small', text: r ? r.detail : LAYER_HELP[l] })])]));
  });
  w.appendChild(lc);
  // progress: where it is, who is working on it, and what just happened
  var STEPS = [['queued', 'Waiting'], ['research', 'Researching'], ['spec', 'Planning'], ['code', 'Writing'], ['build', 'Building'], ['test', 'Testing'], ['review', 'Reviewing'], ['ready', 'Done']];
  var cur = STEPS.map(function (x) { return x[0]; }).indexOf(p.stage === 'built' || p.stage === 'shipped' ? 'ready' : p.stage);
  var prog = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Progress' })]);
  var stepRow = el('div', { class: 'steps' });
  STEPS.forEach(function (st, i) { var done = cur >= 0 && (i < cur || (cur === 6 && i === 6)); stepRow.appendChild(el('div', { class: 'stp ' + (done ? 'done' : i === cur ? 'now' : '') }, [el('span', { class: 'dot', text: done ? '✓' : String(i + 1) }), st[1]])); });
  prog.appendChild(stepRow);
  (d.agents || []).filter(function (a) { return a.project === p.id && a.state === 'working'; }).forEach(function (a) { prog.appendChild(el('div', { class: 'now-line', text: (AGENT_NAME[a.id] || a.id) + (a.worker ? ' ' + a.worker : '') + ': ' + (a.doing || 'working') })); });
  var evs = state.events.filter(function (e) { return e.project === p.id; }).slice(-12).reverse();
  var feedBox = el('div', { class: 'feed', style: 'margin-top:8px;max-height:none;overflow:visible' });
  if (!evs.length) feedBox.appendChild(el('div', { class: 'dim small', text: 'Nothing has happened since Forge was opened.' }));
  evs.forEach(function (e) { feedBox.appendChild(el('div', {}, [el('time', { text: clock(e.at) }), el('span', { class: 'ag ' + e.agent, text: AGENT_NAME[e.agent] || e.agent }), el('span', { text: e.text })])); });
  prog.appendChild(feedBox);
  w.insertBefore(prog, lc); // progress sits right under the summary
  // files: tap one to read it
  var fcard = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Files' })]);
  var flist = el('div', { class: 'files' }, el('div', { class: 'dim small', text: 'Loading…' }));
  fcard.appendChild(flist); w.appendChild(fcard);
  api('GET', '/mods/' + p.id + '/files').then(function (r) {
    flist.innerHTML = '';
    var fl = (r && r.files) || [];
    if (!fl.length) flist.appendChild(el('div', { class: 'dim small', text: 'No files yet. They appear here as the Coder writes them.' }));
    fl.forEach(function (f) {
      var open = state.openFile && state.openFile.id === p.id && state.openFile.path === f.path;
      flist.appendChild(el('div', { class: 'frow' + (open ? ' on' : ''), onclick: function () {
        if (open) { state.openFile = null; render(); return; }
        api('GET', '/mods/' + p.id + '/file/' + encodeURIComponent(f.path)).then(function (x) { state.openFile = { id: p.id, path: f.path, text: x.error ? x.error : x.text + (x.truncated ? '\n… (cut off)' : '') }; render(); });
      } }, [el('span', { class: 'fp', text: f.path }), el('span', { class: 'dim small', text: f.size > 1024 ? Math.round(f.size / 1024) + ' KB' : f.size + ' B' })]));
      if (open) flist.appendChild(el('pre', { class: 'code', text: state.openFile.text }));
    });
  }).catch(function () { flist.innerHTML = ''; flist.appendChild(el('div', { class: 'dim small', text: 'Could not load the files.' })); });
  if (p.stage === 'ready' || p.stage === 'built') w.appendChild(el('div', { class: 'card' }, el('div', { class: 'row' }, [el('button', { class: 'btn gold', text: 'Publish to my releases folder', onclick: function () { api('POST', '/mods/' + p.id + '/ship').then(function (r) { toast(r.message); fx.play('ship'); refresh(); }); } }), el('span', { class: 'dim small', text: p.stage === 'built' ? 'Not everything was tested; try it in-game first.' : 'All 7 layers passed.' })])));
  if (p.shippedTo) {
    var onPc = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
    var jarBtns = [];
    if (onPc) jarBtns.push(el('button', { class: 'btn go', text: 'Show the jar', onclick: function () { api('POST', '/mods/' + p.id + '/reveal').then(function (r) { toast(r.message); }); } }));
    jarBtns.push(el('button', { class: 'btn', text: 'Copy folder path', onclick: function () { var done = function () { toast('Copied the folder path.'); }; try { navigator.clipboard.writeText(p.shippedTo).then(done, done); } catch (e) { toast(p.shippedTo); } } }));
    var gh = d.github || {};
    var ghRow = [];
    if (!gh.connected) ghRow.push(el('div', { class: 'dim small', text: 'Connect GitHub in Setup to publish this mod to a public repository, one folder per mod.' }), el('button', { class: 'btn', text: 'Open Setup', onclick: function () { state.tab = 'setup'; render(); } }));
    else {
      ghRow.push(el('button', { class: 'btn ' + (state.confirmGh === p.id ? 'no' : ''), text: state.confirmGh === p.id ? 'Really make it public?' : (p.githubUrl ? 'Update on GitHub' : 'Publish to GitHub (public)'), onclick: function () {
        if (state.confirmGh !== p.id) { state.confirmGh = p.id; render(); setTimeout(function () { if (state.confirmGh === p.id) { state.confirmGh = null; render(); } }, 6000); return; }
        state.confirmGh = null; toast('Publishing to GitHub…'); render();
        api('POST', '/mods/' + p.id + '/github').then(function (r) { toast(r.message); fx.play(r.ok ? 'approve' : 'decline'); refresh(); }).catch(function () { toast('Could not reach Forge.'); });
      } }));
      if (p.githubUrl) { ghRow.push(el('a', { class: 'btn', href: p.githubUrl, target: '_blank', rel: 'noopener', text: 'Open the folder' })); if (p.githubRelease) ghRow.push(el('a', { class: 'btn', href: p.githubRelease, target: '_blank', rel: 'noopener', text: 'Open the release' })); }
    }
    w.appendChild(el('div', { class: 'card' }, [el('b', { text: 'Published' }), el('div', { class: 'pair', text: p.shippedTo }), el('div', { class: 'row', style: 'margin-top:8px' }, jarBtns), el('div', { class: 'row', style: 'margin-top:8px;align-items:center' }, ghRow)]));
  }
  if (p.files > 0 && ['parked', 'stopped', 'ready', 'built', 'shipped'].indexOf(p.stage) >= 0) {
    var ptc = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Play test' }), el('p', { class: 'dim small', text: 'Opens Minecraft with this mod on your computer (no need to copy it anywhere). Make a creative world and play. I watch the game log and chat; type "bug: ..." in game chat, or tell me here, and it goes on the list. Press the green button when you are done and the team fixes the list.' })]);
    var ptStatus = el('div', { class: 'dim small', text: '' });
    var ptLog = el('div', { class: 'ptlog' });
    var ptBugs = el('div', {});
    var ptTalk = el('div', { class: 'pttalk' });
    var ptIn = el('input', { type: 'text', placeholder: 'Tell me what you see…', value: state.ptDraft || '', oninput: function () { state.ptDraft = ptIn.value; }, onkeydown: function (e) { if (e.key === 'Enter') ptSend.click(); } });
    var ptSend = el('button', { class: 'btn', text: 'Send', onclick: function () { var t = ptIn.value.trim(); if (!t) return; ptIn.value = ''; state.ptDraft = ''; ptTalk.appendChild(el('div', { class: 'me', text: 'You: ' + t })); api('POST', '/mods/' + p.id + '/playtest/say', { text: t }).then(function () { ptPoll(true); }); } });
    var ptStart = el('button', { class: 'btn go', text: 'Start play test', onclick: function () { api('POST', '/mods/' + p.id + '/playtest/start').then(function (r) { toast(r.message); ptPoll(true); }); } });
    var ptStop = el('button', { class: 'btn no', text: 'Close the game', onclick: function () { api('POST', '/mods/' + p.id + '/playtest/stop').then(function (r) { toast(r.message); }); } });
    var ptFix = el('button', { class: 'btn gold', text: 'Send the bug list to the team', onclick: function () { api('POST', '/mods/' + p.id + '/playtest/fix').then(function (r) { toast(r.message); fx.play(r.ok ? 'approve' : 'decline'); refresh(); }); } });
    ptc.appendChild(el('div', { class: 'row' }, [ptStart, ptStop]));
    ptc.appendChild(ptStatus); ptc.appendChild(ptLog); ptc.appendChild(el('b', { text: 'Bug list' })); ptc.appendChild(ptBugs); ptc.appendChild(ptTalk);
    ptc.appendChild(el('div', { class: 'row', style: 'margin-top:8px' }, [ptIn, ptSend])); ptc.appendChild(el('div', { style: 'height:8px' })); ptc.appendChild(ptFix);
    w.appendChild(ptc);
    var ptLast = 0, ptTimer = null, ptSeen = 0;
    var ptPoll = function (now) {
      if (ptTimer) { clearTimeout(ptTimer); ptTimer = null; }
      if (!document.body.contains(ptc)) return;
      api('GET', '/mods/' + p.id + '/playtest/' + ptLast).then(function (v) {
        if (v.last < ptLast) { ptLast = 0; ptLog.innerHTML = ''; }
        v.lines.forEach(function (l) { ptLog.appendChild(el('div', { class: 'l ' + l.kind, text: l.t })); });
        while (ptLog.childNodes.length > 250) ptLog.removeChild(ptLog.firstChild);
        if (v.lines.length) ptLog.scrollTop = ptLog.scrollHeight;
        ptLast = v.last;
        ptStatus.textContent = !v.started ? 'Not started.' : v.running ? 'The game is running. ' + v.errors + ' error line' + (v.errors === 1 ? '' : 's') + ' so far.' : 'The game is closed.';
        ptBugs.innerHTML = '';
        if (!v.bugs.length) ptBugs.appendChild(el('div', { class: 'dim small', text: 'Nothing yet.' }));
        v.bugs.forEach(function (b) { ptBugs.appendChild(el('div', { class: 'row between', style: 'padding:2px 0' }, [el('span', { class: 'small', text: '• ' + b.text + (b.from === 'game' ? ' (from game chat)' : b.from === 'claude' ? ' (noticed by Claude)' : '') }), el('button', { class: 'btn', style: 'padding:2px 8px', text: '×', onclick: function () { api('POST', '/mods/' + p.id + '/playtest/bug/' + b.id + '/remove').then(function () { ptPoll(true); }); } })])); });
        if (v.talk.length !== ptSeen) { ptSeen = v.talk.length; ptTalk.innerHTML = ''; v.talk.forEach(function (t) { ptTalk.appendChild(el('div', { class: t.from === 'you' ? 'me' : 'ai', text: (t.from === 'you' ? 'You: ' : 'Claude: ') + t.text })); }); }
        ptTimer = setTimeout(function () { ptPoll(); }, v.running ? 1500 : 4000);
      }).catch(function () { ptTimer = setTimeout(function () { ptPoll(); }, 5000); });
    };
    ptPoll(true);
  }
  if (p.research && ((p.research.refs && p.research.refs.length) || (p.research.log && p.research.log.length))) {
    var rl = null;
    var rcard = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Research and credits' }), el('p', { class: 'dim small', text: (p.research.refs && p.research.refs.length) ? 'Mods looked at before planning. Code is only adapted from permissive licences, and credited in CREDITS.md, the README and the repository.' : 'The Researcher found nothing it could credit. This is what it tried:' })]);
    if (p.research.log && p.research.log.length) { var rl = el('details', { class: 'small dim' }, [el('summary', { text: 'What it searched and read (' + p.research.log.length + ')' })]); p.research.log.forEach(function (l) { rl.appendChild(el('div', { text: l })); }); }
    p.research.refs.forEach(function (r) { rcard.appendChild(el('div', { class: 'small', style: 'padding:3px 0' }, [el('a', { href: r.url, target: '_blank', rel: 'noopener', text: r.name }), ' (' + r.license + ') ' + (r.reuse === 'code' ? 'code adapted with credit' : 'ideas only') + (r.note ? ': ' + r.note : '')])); });
    if (rl) rcard.appendChild(rl);
    w.appendChild(rcard);
  }
  if (p.shippedTo) {
    var vcard = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Version history' })]);
    var vlist = el('div', { class: 'files' }, el('div', { class: 'dim small', text: 'Loading…' }));
    vcard.appendChild(vlist); w.appendChild(vcard);
    api('GET', '/mods/' + p.id + '/versions').then(function (r) {
      vlist.innerHTML = '';
      (r.versions || []).forEach(function (v) {
        var kb = v.bytes ? Math.max(1, Math.round(v.bytes / 1024)) + ' KB' : 'no jar';
        var acts = [];
        if (/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname)) acts.push(el('button', { class: 'btn', text: 'Show', onclick: function () { api('POST', '/mods/' + p.id + '/reveal', { version: v.version }).then(function (x) { toast(x.message); }); } }));
        if (v.release) acts.push(el('a', { class: 'btn', href: v.release, target: '_blank', rel: 'noopener', text: 'GitHub release' }));
        vlist.appendChild(el('div', { class: 'row between', style: 'padding:4px 0' }, [el('div', {}, [el('b', { text: v.version + (v.version === r.current ? ' (latest)' : '') }), el('div', { class: 'dim small', text: (v.jar || 'no jar') + ' · ' + kb + ' · ' + new Date(v.at).toLocaleDateString() })]), el('div', { class: 'row' }, acts)]));
      });
      if (!(r.versions || []).length) vlist.appendChild(el('div', { class: 'dim small', text: 'Nothing published yet.' }));
    }).catch(function () { vlist.innerHTML = ''; vlist.appendChild(el('div', { class: 'dim small', text: 'Could not load the versions.' })); });
  }
  var busy = ['queued', 'research', 'spec', 'code', 'build', 'test', 'review'].indexOf(p.stage) >= 0;
  var acts = [el('button', { class: 'btn go', text: 'Continue', onclick: function () { state.chatDraft = 'About "' + p.name + '": '; state.tab = 'chat'; fx.play('nav'); render(); } })];
  if (['parked', 'stopped'].indexOf(p.stage) >= 0) acts.push(el('button', { class: 'btn', text: 'Try again', onclick: function () { api('POST', '/mods/' + p.id + '/retry').then(function (r) { toast(r.message); refresh(); }); } }));
  if (['ready', 'built', 'shipped'].indexOf(p.stage) >= 0) acts.push(el('button', { class: 'btn', text: 'Test again', onclick: function () { api('POST', '/mods/' + p.id + '/retest').then(function (r) { toast(r.message); fx.play('approve'); refresh(); }); } }));
  var del = el('button', { class: 'btn no', text: state.confirmDelete === p.id ? 'Really delete?' : 'Delete', onclick: function () {
    if (busy) { toast('It is being worked on. Press Stop all first.'); return; }
    if (state.confirmDelete !== p.id) { state.confirmDelete = p.id; render(); setTimeout(function () { if (state.confirmDelete === p.id) { state.confirmDelete = null; render(); } }, 5000); return; }
    api('POST', '/mods/' + p.id + '/delete').then(function (r) { state.confirmDelete = null; state.sel = null; toast(r.message); refresh(); });
  } });
  acts.push(del);
  w.appendChild(el('div', { class: 'card' }, [el('div', { class: 'row' }, acts), el('div', { class: 'dim small', style: 'margin-top:8px', text: 'Continue takes you to the Foreman chat to say what to change or add.' })]));
}
function newModSheet() {
  var name = el('input', { placeholder: 'Mod name, like Sleep Sooner', maxlength: 40 });
  var idea = el('textarea', { rows: 4, placeholder: 'What should it do? Plain words are fine.', maxlength: 800 });
  var mode = el('select', {}, [['vanilla-plus', 'Vanilla Plus (recommended): feels like part of the game'], ['content', 'Content: new blocks, items, textures'], ['library', 'Library for other mods'], ['client', 'Client utility'], ['server', 'Server tweak']].map(function (m) { return el('option', { value: m[0], text: m[1] }); }));
  var prof = el('select', {}, ((state.data && state.data.profiles) || []).map(function (p) { return el('option', { value: p.mc, text: 'Minecraft ' + p.mc + (p.status !== 'supported' ? ' (' + p.status + ')' : '') }); }));
  return el('div', { class: 'card' }, [el('h2', { class: 'mc', text: 'New mod' }), name, el('div', { style: 'height:8px' }), idea, el('div', { style: 'height:8px' }), mode, el('div', { style: 'height:8px' }), prof, el('div', { style: 'height:12px' }),
    el('div', { class: 'row' }, [el('button', { class: 'btn go', text: 'Start building', onclick: function () { api('POST', '/mods', { name: name.value, idea: idea.value, mode: mode.value, profile: prof.value }).then(function (r) { if (r.error) { toast(r.error); return; } state.sheet = null; state.newModOpen = false; state.sel = r.project.id; fx.play('approve'); refresh(); }); } }), el('button', { class: 'btn', text: 'Cancel', onclick: function () { state.sheet = null; state.newModOpen = false; render(); } })])]);
}
function showSheet() {
  var old = $('#sheet'); if (old) return;
  var s = el('div', { class: 'sheet', id: 'sheet' }, state.sheet === 'new' ? newModSheet() : el('div', { class: 'card' }, 'Hello'));
  s.addEventListener('click', function (e) { if (e.target === s) { state.sheet = null; state.newModOpen = false; s.remove(); } });
  document.body.appendChild(s);
}

/* ───────── tests / simulation ───────── */
function viewSim(w, d) {
  var ps = d.projects.filter(function (p) { return Object.keys(p.layers).length; });
  if (!ps.length) { w.appendChild(el('div', { class: 'card dim', text: 'Nothing has been tested yet. Once a mod is built, you can watch the Testers here.' })); return; }
  var sel = ps.filter(function (p) { return p.id === state.simSel; })[0] || ps[ps.length - 1];
  var pick = el('select', { onchange: function (e) { state.simSel = e.target.value; render(); } }, ps.slice().reverse().map(function (p) { return el('option', { value: p.id, text: p.name + ' (' + (STAGE_TEXT[p.stage] || p.stage) + ')', selected: p.id === sel.id }); }));
  w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Tests for' }), pick]));
  // lanes: one per tester worker
  var lanes = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Testers working side by side' })]);
  var lw = el('div', { class: 'lanes' });
  [1, 2, 3].forEach(function (n) {
    var track = el('div', { class: 'track' });
    var mine = Object.keys(sel.layers).filter(function (l) { return sel.layers[l].worker === n; });
    var live = d.agents.filter(function (a) { return a.id === 'tester' && a.worker === n && a.state === 'working' && a.project === sel.id; })[0];
    mine.forEach(function (l) { track.appendChild(el('div', { class: 'seg ' + sel.layers[l].state, title: sel.layers[l].detail, text: LAYER_NAME[l] })); });
    if (live) track.appendChild(el('div', { class: 'seg run', text: live.doing.replace('running ', '') + '…' }));
    lw.appendChild(el('div', { class: 'lane' }, [el('span', { class: 'ag tester', text: 'Tester ' + n }), track]));
  });
  lanes.appendChild(lw); w.appendChild(lanes);
  // soak visuals
  var soak = sel.layers.soak;
  var wc = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Long soak: game days passing' })]);
  var world = el('canvas', { class: 'world', width: 480, height: 120, id: 'world' }); wc.appendChild(world);
  wc.appendChild(el('div', { class: 'dim small', text: soak ? soak.detail : 'The soak has not run yet. It speeds up the game clock and plays for many days while watching ticks and memory.' }));
  w.appendChild(wc);
  drawWorld(world, soak);
  if (soak && soak.series && soak.series.length) {
    var ch = el('canvas', { class: 'chart', width: 600, height: 150 }); var ch2 = el('canvas', { class: 'chart', width: 600, height: 150 });
    w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Tick time (limit 50 ms)' }), ch]));
    w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Memory (MB)' }), ch2]));
    drawChart(ch, soak.series.map(function (s) { return s.tickMs; }), 50, '#7bd04f', soak.state === 'fail'); drawChart(ch2, soak.series.map(function (s) { return s.memMb; }), 0, '#4aa3df', false);
  }
  var det = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'All 7 layers' })]);
  Object.keys(LAYER_NAME).forEach(function (l) { var r = sel.layers[l]; det.appendChild(el('div', { class: 'row', style: 'padding:3px 0;flex-wrap:nowrap' }, [el('div', { class: 'lt ' + (r ? r.state : ''), text: r ? (r.state === 'pass' ? '✓' : r.state === 'fail' ? '✗' : '–') : LAYER_NAME[l][0] }), el('span', { class: 'small', text: LAYER_NAME[l] + ': ' + (r ? r.detail : 'not run yet') })])); });
  w.appendChild(det);
}
function drawWorld(cv, soak) {
  var x = cv.getContext && cv.getContext('2d'); if (!x) return;
  var g = tex('grass', 16, 3), dt = tex('dirt', 16, 5), st = tex('stone', 16, 2);
  var days = soak ? soak.simDays || 0 : 0; var crashed = soak && soak.crashes > 0;
  x.imageSmoothingEnabled = false;
  // sky follows the day count: each pixel column is a day passing
  for (var i = 0; i < 480; i += 2) { var dd = i / 480 * 8 * Math.PI; var l = (Math.sin(dd) + 1) / 2; x.fillStyle = 'rgb(' + Math.round(14 + 110 * l) + ',' + Math.round(22 + 150 * l) + ',' + Math.round(60 + 170 * l) + ')'; x.fillRect(i, 0, 2, 80); }
  for (var a = 0; a < 30; a++) for (var b = 0; b < 3; b++) { var t = b === 0 ? g : b === 1 ? dt : st; if (t) x.drawImage(t, a * 16, 64 + b * 16); }
  if (g) { for (var k = 0; k < 30; k++) x.drawImage(st, k * 16, 112); }
  // a villager and trees, plus a flag for each simulated day
  x.fillStyle = '#7a5230'; [60, 190, 330, 420].forEach(function (tx) { x.fillRect(tx, 40, 6, 24); x.fillStyle = '#3f8a2a'; x.fillRect(tx - 10, 22, 26, 20); x.fillStyle = '#7a5230'; });
  var pct = soak && soak.simDays ? Math.min(1, soak.simDays / 100) : 0;
  x.fillStyle = '#e8b93c'; x.fillRect(Math.round(pct * 440) + 8, 48, 6, 16); x.fillStyle = '#000'; x.fillRect(Math.round(pct * 440) + 8, 44, 2, 20);
  x.fillStyle = '#fff'; x.font = '12px monospace'; x.fillText(days ? 'Day ' + days : 'Day 0', 8, 14);
  if (crashed) { x.fillStyle = '#d9534f'; x.fillRect(0, 0, 480, 4); x.fillRect(0, 76, 480, 4); x.fillStyle = '#fff'; x.fillText('CRASH on day ' + days, 360, 14); }
}
function drawChart(cv, vals, line, color, bad) {
  var x = cv.getContext && cv.getContext('2d'); if (!x || !vals.length) return;
  var W = cv.width, H = cv.height, max = Math.max.apply(null, vals.concat([line || 0])) * 1.1, min = line ? 0 : Math.min.apply(null, vals) * .98;
  x.clearRect(0, 0, W, H); x.fillStyle = '#0004'; x.fillRect(0, 0, W, H);
  x.strokeStyle = '#ffffff22'; for (var i = 1; i < 4; i++) { x.beginPath(); x.moveTo(0, H * i / 4); x.lineTo(W, H * i / 4); x.stroke(); }
  if (line) { var ly = H - (line - min) / (max - min) * H; x.strokeStyle = '#d9534f'; x.setLineDash([6, 4]); x.beginPath(); x.moveTo(0, ly); x.lineTo(W, ly); x.stroke(); x.setLineDash([]); }
  x.strokeStyle = bad ? '#d9534f' : color; x.lineWidth = 3; x.beginPath();
  vals.forEach(function (v, i2) { var px = i2 / Math.max(1, vals.length - 1) * (W - 8) + 4, py = H - 4 - (v - min) / (max - min || 1) * (H - 8); if (i2) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke();
}

/* ───────── versions ───────── */
function viewVersions(w, d) {
  w.appendChild(el('div', { class: 'row between' }, [el('h2', { class: 'mc', style: 'margin:0', text: 'Minecraft versions' }), el('button', { class: 'btn', text: 'Ask the Scout to check Fabric', onclick: function () { toast('The Scout is checking…'); api('POST', '/scout').then(function (r) { toast(r.newVersions && r.newVersions.length ? 'New version found: ' + r.newVersions.join(', ') : 'Nothing new'); refresh(); }); } })]));
  w.appendChild(el('div', { class: 'card dim small', text: 'Minecraft now uses year-based versions (26.x). From 26.1 the game is unobfuscated, so mods use official names with no mappings step and need Java 25. Older versions use Mojang mappings. The Scout reads Fabric\'s own version lists; a new release only becomes "testing", and you decide what to support.' }));
  var g = el('div', { class: 'mods' });
  d.profiles.forEach(function (p) {
    g.appendChild(el('div', { class: 'card' }, [el('div', { class: 'row between' }, [el('b', { class: 'mc', text: 'Minecraft ' + p.mc }), el('span', { class: 'stage ' + (p.status === 'supported' ? 'ready' : p.status === 'testing' ? 'built' : 'parked'), text: p.status })]),
      el('div', { class: 'small', text: 'Java ' + p.java + ' · ' + (p.unobfuscated ? 'unobfuscated, official names' : 'Mojang mappings') }), el('div', { class: 'dim small', text: 'Loom plugin: ' + p.loomId }), el('div', { class: 'dim small', text: 'Fabric Loader ' + p.loader + ' · Fabric API ' + p.fabricApi }), el('div', { class: 'dim small', text: p.verified ? 'Numbers checked against Fabric' : 'Bundled numbers; the Scout re-checks them online' })]));
  });
  w.appendChild(g);
}

/* ───────── settings ───────── */
function viewSettings(w, d) {
  var s = state.setup || {}; var st = s.settings || {};
  function save(patch) { return api('POST', '/setup/settings', patch).then(function (r) { if (!r.ok) toast(r.message); else { state.setup.settings = r.settings; if (patch.theme) applyTheme(patch.theme); if ('sound' in patch) store.set('forge.sound', patch.sound ? 'on' : 'off'); state.settings = r.settings; toast('Saved'); } refresh(); }); }
  function toggle(label, k, help) { var c = el('input', { type: 'checkbox', checked: !!st[k], onchange: function () { var p = {}; p[k] = c.checked; fx.play('click'); save(p); } }); if (st[k]) c.checked = true; return el('label', { class: 'opt' }, [c, el('span', {}, [label, help ? el('div', { class: 'dim small', text: help }) : null])]); }
  if (!state.setup) { api('GET', '/setup').then(function (r) { state.setup = r; state.settings = r.settings; render(); }); w.appendChild(el('div', { class: 'card dim', text: 'Loading…' })); return; }
  var keyIn = el('input', { type: 'password', placeholder: 'sk-ant-…', autocomplete: 'off' });
  w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Claude (the AI brain)' }),
    el('p', { class: 'dim small', text: s.hasKey ? 'A key is saved (' + s.keyHint + '). It stays on this computer.' : 'No key yet, so Forge runs in demo mode with pretend AI. To use real Claude: sign in at console.anthropic.com, add a few dollars of credit under Billing, create an API key under API keys, and paste it here.' }),
    keyIn, el('div', { style: 'height:8px' }),
    el('div', { class: 'row' }, [el('button', { class: 'btn go', text: 'Check and save key', onclick: function () { api('POST', '/setup/key', { key: keyIn.value }).then(function (r) { toast(r.message); if (r.ok) { keyIn.value = ''; state.setup = null; } refresh(); }); } }), s.hasKey ? el('button', { class: 'btn no', text: 'Remove key', onclick: function () { api('DELETE', '/setup/key').then(function () { state.setup = null; refresh(); }); } }) : null]),
    toggle('Demo mode (pretend AI and pretend builds)', 'demo', 'Turn off to use your Claude key and the real Java/Gradle build. The first real build downloads Java and Gradle (a few hundred MB).')]));
  var ghIn = el('input', { type: 'password', placeholder: 'ghp_…', autocomplete: 'off' });
  var ghRepo = el('input', { type: 'text', value: st.githubRepo || 'forge-mods', onchange: function () { save({ githubRepo: ghRepo.value.trim() }); } });
  w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'GitHub (optional)' }),
    el('p', { class: 'dim small', text: s.githubHint ? 'Connected as ' + s.githubHint + '. Mods are published only when you press the button on a mod, and always to a public repository.' : 'Lets you publish a finished mod to a public GitHub repository with one button: a folder per mod, a release per version, the jar attached. To connect: sign in at github.com, open Settings > Developer settings > Personal access tokens > Tokens (classic), generate a new token with the "repo" box ticked, and paste it here. It stays on this computer.' }),
    ghIn, el('div', { style: 'height:8px' }),
    el('div', { class: 'row' }, [el('button', { class: 'btn go', text: 'Check and save token', onclick: function () { api('POST', '/setup/github', { token: ghIn.value }).then(function (r) { toast(r.message); if (r.ok) { ghIn.value = ''; state.setup = null; } refresh(); }); } }), s.githubHint ? el('button', { class: 'btn no', text: 'Remove token', onclick: function () { api('DELETE', '/setup/github').then(function () { state.setup = null; refresh(); }); } }) : null]),
    el('div', { style: 'height:8px' }), el('div', { class: 'small dim', text: 'Repository name (made for you the first time, public, under your account)' }), ghRepo]));
  var bud = el('input', { type: 'number', min: 1, max: 500, value: st.aiBudget, onchange: function () { save({ aiBudget: Number(bud.value) }); } });
  var mt = el('input', { type: 'number', min: 0.5, max: 500, step: 0.5, value: st.modBudget || 5, onchange: function () { save({ modBudget: Number(mt.value) }); } });
  var spent = el('input', { type: 'number', min: 0, max: 100000, step: 0.01, value: (Math.round(state.data.aiMonthCost * 100) / 100), onchange: function () { api('POST', '/spend', { amount: Number(spent.value) }).then(function (r) { toast(r.message); refresh(); }); } });
  var days = el('input', { type: 'number', min: 5, max: 1000, value: st.simDays, onchange: function () { save({ simDays: Number(days.value) }); } });
  w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Spending and testing' }), el('div', { class: 'small dim', text: 'Claude budget per month (dollars). Forge stops politely when it is used up.' }), bud, el('div', { style: 'height:8px' }),
    el('div', { class: 'small dim', text: 'Budget per mod (dollars). One mod parks when it spends this much, even if the monthly budget has room.' }), mt, el('div', { style: 'height:8px' }),
    el('div', { class: 'small dim', text: 'Spent this month (dollars). Forge counts from the usage Claude reports, which can differ a little from your Anthropic console. Type the console number here any time to correct it.' }), spent, el('div', { style: 'height:8px' }),
    el('div', { class: 'small dim', text: 'Soak length in Minecraft days (100 days is about 33 hours of game time).' }), days,
    toggle('I accept the Minecraft EULA for the test servers', 'eula', 'Test servers will not start unless you accept it. Read it at minecraft.net/eula.'),
    toggle('Research other mods first', 'research', 'Before planning a new mod, look at similar mods on Modrinth and GitHub for ideas, and credit them. Code is only copied from permissive licences.'),
    (function () {
      var out = el('div', { class: 'small', style: 'margin:6px 0' });
      var btn = el('button', { class: 'btn', text: 'Test the research connection', onclick: function () {
        out.textContent = 'Trying Modrinth, web search, GitHub…'; btn.disabled = true;
        api('GET', '/setup/research-check').then(function (r) { btn.disabled = false; out.innerHTML = ''; r.checks.forEach(function (c) { out.appendChild(el('div', { text: (c.ok ? '✓ ' : '✗ ') + c.name + ': ' + c.detail, style: 'color:' + (c.ok ? 'var(--ok, #7bc96f)' : 'var(--bad, #e57373)') })); }); }).catch(function () { btn.disabled = false; out.textContent = 'Could not run the check.'; });
      } });
      return el('div', {}, [btn, out]);
    })(),
    toggle('Also check multiplayer', 'multiplayer', 'Off by default. Turn it on if you play with other people on a server.')]));
  var cur = state.settings.theme || 'dark';
  var themes = el('div', { class: 'row' }, ['dark', 'light', 'amoled'].map(function (t) { return el('button', { class: 'btn ' + (cur === t ? 'go' : ''), text: t[0].toUpperCase() + t.slice(1), onclick: function () { save({ theme: t }); } }); }));
  w.appendChild(el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Look and feel' }), themes, toggle('Sound effects', 'sound'), toggle('Animations', 'animations'), toggle('Fun extras (workshop scene, textured background)', 'fun')]));
  var phone = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Phone remote' }), el('p', { class: 'dim small', text: 'Install the Forge app on your phone, then enter one of these addresses and the key. Your phone and computer need to be on the same Wi-Fi.' })]);
  (s.addresses || []).forEach(function (a) { phone.appendChild(el('div', { class: 'pair', text: a })); });
  phone.appendChild(el('div', { class: 'pair', style: 'margin-top:6px', text: 'Key: ' + (key() || '(shown on this computer)') }));
  w.appendChild(phone);
  var up = el('div', { class: 'card' }, [el('h3', { class: 'mc', text: 'Updates' })]); w.appendChild(up);
  api('GET', '/update').then(function (u) {
    up.appendChild(el('div', { text: 'Forge ' + u.current + (u.available ? ' · version ' + u.latest.version + ' is available' : ' · up to date') }));
    if (u.available && u.latest.notes) u.latest.notes.forEach(function (n) { up.appendChild(el('div', { class: 'dim small', text: '• ' + n })); });
    if (u.error) up.appendChild(el('div', { class: 'dim small', text: u.error }));
    up.appendChild(el('div', { class: 'row', style: 'margin-top:8px' }, [el('button', { class: 'btn', text: 'Check now', onclick: function () { api('POST', '/update/check').then(function (r) { toast(r && r.available ? 'Version ' + r.latest.version + ' is available' : r && r.error ? r.error : 'You are up to date'); state.setup = null; refresh(); }); } }), u.available && u.canInstall ? el('button', { class: 'btn go', text: 'Install ' + u.latest.version, onclick: function () { api('POST', '/update/install').then(function (r) { toast(r.message); }); } }) : null]));
    up.appendChild(toggle('Install updates automatically when nothing is building', 'autoUpdate'));
    if (s.canAutostart) up.appendChild(toggle('Start Forge when Windows starts', 'startWithWindows'));
  }).catch(function () {});
}

/* ───────── boot ───────── */
function boot() {
  $app = $('#app');
  applyTheme(store.get('forge.theme') || 'dark');
  applyTextures();
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('.btn')) fx.play('click'); }, true);
  window.addEventListener('beforeunload', function () { if (scene && scene.stop) scene.stop(); });
  getLocalKey().then(function () {
    api('GET', '/setup').then(function (r) { state.setup = r; state.settings = r.settings; applyTheme(r.settings.theme); }).catch(function () {});
    refresh(); setInterval(function () { if (state.auth && !document.hidden) refresh(true); }, 1500);
    // when an update restarts the engine, reload the page once it answers with a new version
    var ver = null; setInterval(function () { fetch('/api/hello', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) { if (ver && j.version !== ver) location.reload(); ver = j.version; }).catch(function () {}); }, 15000);
  });
}
window.__forge = { state: state, refresh: refresh };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

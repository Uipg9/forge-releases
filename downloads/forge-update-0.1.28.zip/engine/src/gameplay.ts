// Playing a mod on a real server: the scenario script a Tester writes (and how it is run), and the popular mods
// the compatibility check runs beside. Pure logic with small interfaces, so it is tested without Minecraft.
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

// ---------- scenario scripts ----------
// One step per line:
//   cmd <server command>      sent to the server console (no slash)
//   expect <regex>            must show up in the server output after the last cmd (within 15 seconds)
//   forbid <regex>            must never show up in the output from here to the end
//   wait <ticks>              fast-forwards game time (tick sprint) and waits until it is done
//   # comment
export type Step = { kind: 'cmd' | 'expect' | 'forbid' | 'wait'; arg: string; line: number };

const BLOCKED_CMD = /^(stop|op|deop|ban|ban-ip|pardon|pardon-ip|whitelist|publish|transfer|save-off|reload|debug|perf)\b/i;
export const MAX_STEPS = 60;

export function parseScenario(text: string): { steps: Step[]; problems: string[] } {
  const steps: Step[] = [];
  const problems: string[] = [];
  text.split(/\r?\n/).forEach((raw, i) => {
    const l = raw.trim();
    if (!l || l.startsWith('#')) return;
    const m = l.match(/^(cmd|expect|forbid|wait)\s+(.+)$/i);
    if (!m) { problems.push(`line ${i + 1}: start with cmd, expect, forbid or wait`); return; }
    const kind = m[1].toLowerCase() as Step['kind'];
    let arg = m[2].trim();
    if (kind === 'cmd') { arg = arg.replace(/^\//, ''); if (BLOCKED_CMD.test(arg)) { problems.push(`line ${i + 1}: the command "${arg.split(' ')[0]}" is not allowed in a scenario`); return; } }
    if (kind === 'expect' || kind === 'forbid') { try { new RegExp(arg, 'i'); } catch { problems.push(`line ${i + 1}: "${arg}" is not a valid pattern`); return; } }
    if (kind === 'wait') { const n = Number(arg); if (!Number.isInteger(n) || n < 1 || n > 48000) { problems.push(`line ${i + 1}: wait takes a number of ticks from 1 to 48000`); return; } }
    steps.push({ kind, arg, line: i + 1 });
  });
  if (steps.length > MAX_STEPS) problems.push(`more than ${MAX_STEPS} steps`);
  if (!steps.some((s) => s.kind === 'cmd')) problems.push('there is no cmd line');
  if (!steps.some((s) => s.kind === 'expect')) problems.push('there is no expect line, so nothing would be checked');
  return { steps: steps.slice(0, MAX_STEPS), problems };
}

/** Console lines that mean the server did not understand a command: a mistake in the script (or a command the mod never registered). */
export const COMMAND_ERROR = /Unknown or incomplete command|Incorrect argument for command|Unknown (item|block|entity|dimension|biome|enchantment) |Expected (a |an )?\w[\w ]* at position|Unknown (scoreboard|attribute|effect|particle|structure)|Invalid (id|name|data|nbt)|Can't find element/i;

export interface ScenarioIO {
  send(cmd: string): void;
  /** Every console line so far. */
  lines(): string[];
  sleep(ms: number): Promise<void>;
  alive(): boolean;
}
export interface ScenarioResult { pass: number; total: number; failures: string[]; badCommands: string[]; ran: number }

export async function runScenario(steps: Step[], io: ScenarioIO, o: { expectMs?: number; waitMs?: number } = {}): Promise<ScenarioResult> {
  const expectMs = o.expectMs ?? 15_000, waitMs = o.waitMs ?? 5 * 60_000;
  const res: ScenarioResult = { pass: 0, total: 0, failures: [], badCommands: [], ran: 0 };
  const forbids: { re: RegExp; from: number; line: number }[] = [];
  let mark = io.lines().length, last = '';
  const since = (from: number) => io.lines().slice(from);
  for (const s of steps) {
    if (!io.alive()) { res.failures.push(`the server stopped before line ${s.line}`); break; }
    res.ran++;
    if (s.kind === 'cmd') {
      mark = io.lines().length; last = s.arg;
      io.send(s.arg + '\n');
      await io.sleep(350);
      const bad = since(mark).find((l) => COMMAND_ERROR.test(l));
      if (bad) res.badCommands.push(`${s.arg} -> ${bad.replace(/^\[[^\]]*\]\s*(\[[^\]]*\]:?\s*)?/, '').slice(0, 120)}`);
    } else if (s.kind === 'wait') {
      mark = io.lines().length;
      io.send(`tick sprint ${s.arg}\n`);
      const end = Date.now() + waitMs;
      while (io.alive() && Date.now() < end && !since(mark).some((l) => /Sprint completed|sprint.*(done|finished)/i.test(l))) await io.sleep(200);
      if (!since(mark).some((l) => /Sprint completed|sprint.*(done|finished)/i.test(l))) { res.failures.push(`line ${s.line}: waiting ${s.arg} ticks did not finish`); break; }
    } else if (s.kind === 'expect') {
      res.total++;
      const re = new RegExp(s.arg, 'i');
      const end = Date.now() + expectMs;
      while (io.alive() && Date.now() < end && !since(mark).some((l) => re.test(l))) await io.sleep(150);
      if (since(mark).some((l) => re.test(l))) res.pass++;
      else res.failures.push(`line ${s.line}: after "${last || 'start'}" the server never printed something matching /${s.arg}/. It printed: ${since(mark).slice(-3).map((l) => l.slice(0, 100)).join(' | ') || 'nothing'}`);
    } else {
      forbids.push({ re: new RegExp(s.arg, 'i'), from: io.lines().length, line: s.line });
    }
  }
  for (const f of forbids) {
    res.total++;
    const hit = since(f.from).find((l) => f.re.test(l));
    if (hit) res.failures.push(`line ${f.line}: the server printed something that must never appear: ${hit.slice(0, 140)}`); else res.pass++;
  }
  return res;
}

// ---------- popular mods to run beside ----------
/** Server-side mods lots of people run. The compatibility check starts a server with every one that exists for the Minecraft version. */
export const COMPANIONS = ['lithium', 'ferrite-core', 'modernfix', 'spark', 'c2me-fabric'];
/** Gives the scenario a player that can walk, place and use things (a "bot"). Used only when it exists for the version. */
export const BOT_MOD = 'carpet';

export interface Fetched { jars: string[]; names: string[]; missing: string[] }

/** Finds each project's newest Fabric release for this Minecraft version on Modrinth, downloads it once into `cache`, and checks its hash. */
export async function fetchMods(slugs: string[], mc: string, cache: string, f: typeof fetch = fetch): Promise<Fetched> {
  mkdirSync(cache, { recursive: true });
  const out: Fetched = { jars: [], names: [], missing: [] };
  for (const slug of slugs) {
    try {
      const q = `https://api.modrinth.com/v2/project/${encodeURIComponent(slug)}/version?loaders=${encodeURIComponent('["fabric"]')}&game_versions=${encodeURIComponent(JSON.stringify([mc]))}`;
      const r = await f(q, { headers: { 'User-Agent': 'Uipg9/forge (mod test runs)' } });
      if (!r.ok) { out.missing.push(slug); continue; }
      const versions = (await r.json()) as { version_type?: string; files?: { url: string; filename: string; primary?: boolean; hashes?: { sha1?: string } }[] }[];
      const v = versions.find((x) => x.version_type === 'release' && x.files?.length) ?? versions.find((x) => x.files?.length);
      const file = v?.files?.find((x) => x.primary && /\.jar$/i.test(x.filename)) ?? v?.files?.find((x) => /\.jar$/i.test(x.filename));
      if (!file) { out.missing.push(slug); continue; }
      const dest = join(cache, file.filename.replace(/[^\w.\-+]/g, '_'));
      if (!existsSync(dest)) {
        const d = await f(file.url, { headers: { 'User-Agent': 'Uipg9/forge (mod test runs)' } });
        if (!d.ok) { out.missing.push(slug); continue; }
        const buf = Buffer.from(await d.arrayBuffer());
        if (file.hashes?.sha1 && createHash('sha1').update(buf).digest('hex') !== file.hashes.sha1) { out.missing.push(slug); continue; }
        writeFileSync(dest, buf);
      }
      out.jars.push(dest); out.names.push(slug);
    } catch { out.missing.push(slug); }
  }
  return out;
}

/** The part of a crash report that says which mods are suspected. */
export function suspectedMods(report: string): string {
  return report.match(/Suspected Mods?:\s*([\s\S]*?)(\n\n|\nDetails:|$)/i)?.[1]?.slice(0, 400) ?? '';
}

export function readIfThere(file: string): string { try { return existsSync(file) ? readFileSync(file, 'utf8') : ''; } catch { return ''; } }

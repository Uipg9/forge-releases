// SimToolchain: a pretend Minecraft build and test run, for practice runs and the demo mode (no Java needed).
// It reads the generated files for "FORGE-DEFECT:<kind>" markers (the stand-in Coder plants them on purpose) and
// reports what a real build or test would: compile errors, boot failures, crashes, leaks, slow ticks.
// The static layer is NOT pretend: it uses the same real file checks as the real toolchain.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import type { Layer, LayerResult, Project, VersionProfile } from '../types.ts';
import { parseBuildOutput, staticChecks, type BuildResult, type TestCtx, type Toolchain } from '../build.ts';
import { TICKS_PER_DAY } from '../config.ts';

export type Defect = 'compile' | 'boot' | 'logic' | 'crash' | 'leak' | 'slow' | 'compat' | 'desync';
export const DEFECTS: Defect[] = ['compile', 'boot', 'logic', 'crash', 'leak', 'slow', 'compat', 'desync'];

function javaFiles(dir: string, out: string[] = []): string[] {
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    if (n === 'build' || n === 'run') continue;
    const p = join(dir, n);
    if (statSync(p).isDirectory()) javaFiles(p, out); else if (n.endsWith('.java')) out.push(p);
  }
  return out;
}

/** Every planted defect in the project: kind, file and line. */
export function findDefects(dir: string): { kind: Defect; file: string; line: number }[] {
  const found: { kind: Defect; file: string; line: number }[] = [];
  for (const f of javaFiles(join(dir, 'src'))) {
    const lines = readFileSync(f, 'utf8').split('\n');
    lines.forEach((l, i) => {
      const m = l.match(/FORGE-DEFECT:(\w+)/);
      if (m && (DEFECTS as string[]).includes(m[1])) found.push({ kind: m[1] as Defect, file: f.slice(dir.length + 1).replace(/\\/g, '/'), line: i + 1 });
    });
  }
  return found;
}

/** Small deterministic random numbers from a string, so a run is repeatable. */
export function rng(seed: string): () => number {
  let h = 2166136261;
  for (const c of seed) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 100000) / 100000; };
}

export class SimToolchain implements Toolchain {
  name = 'simulated';
  /** Real milliseconds to wait per simulated second, so the demo animates. 0 in tests. */
  pace: number;
  sleep: (ms: number) => Promise<void>;
  constructor(pace = 0, sleep: (ms: number) => Promise<void> = (ms) => new Promise((r) => setTimeout(r, ms))) { this.pace = pace; this.sleep = sleep; }
  private async wait(simSeconds: number) { if (this.pace > 0) await this.sleep(simSeconds * this.pace); }

  async ready(p: VersionProfile) { return { ok: true, message: `Demo toolchain for ${p.mc}: pretend builds and tests (install Java in Settings to build for real).` }; }

  async build(dir: string, _project: Project, _p: VersionProfile): Promise<BuildResult> {
    await this.wait(60);
    const bad = findDefects(dir).filter((d) => d.kind === 'compile');
    const log = bad.map((d) => `${d.file}:${d.line}: error: cannot find symbol\n  symbol: method wakePlayers()`).join('\n');
    const errors = bad.length ? parseBuildOutput(log) : [];
    return { ok: !bad.length, ms: 90_000 + bad.length * 4000, errors, log: bad.length ? log + '\nBUILD FAILED' : 'BUILD SUCCESSFUL' };
  }

  async test(layer: Layer, c: TestCtx): Promise<LayerResult> {
    const defects = findDefects(c.dir);
    const of = (k: Defect) => defects.filter((d) => d.kind === k);
    const r = rng(c.project.id + layer + defects.length);
    const base = { layer, worker: c.worker };
    const res = (state: LayerResult['state'], detail: string, ms: number, extra: Partial<LayerResult> = {}): LayerResult => ({ ...base, state, detail, ms, errors: [], ...extra });
    const fail = (k: Defect, msg: string, ms: number, extra: Partial<LayerResult> = {}) => res('fail', msg, ms, { errors: of(k).map((d) => `${d.file}:${d.line}: ${msg}`), ...extra });

    switch (layer) {
      case 'static': {
        await this.wait(4);
        const errs = existsSync(join(c.dir, 'src')) ? staticChecks(c.dir, c.spec, c.profile) : ['no project files'];
        return res(errs.length ? 'fail' : 'pass', errs.length ? `${errs.length} problems in the files` : 'files, JSON, mixin list and safety rules are fine', 4000, { errors: errs });
      }
      case 'boot':
        await this.wait(40);
        return of('boot').length ? fail('boot', 'the server crashed while loading the mod (a mixin did not apply)', 38_000) : res('pass', 'server started with the mod and stopped cleanly', 38_000);
      case 'scenario': {
        await this.wait(30);
        const total = 40 + Math.floor(r() * 20);
        const bad = of('logic').length;
        const pass = bad ? total - 3 - Math.floor(r() * 4) : total;
        return bad ? fail('logic', `${total - pass} of ${total} scenario checks failed (the mod's behavior is wrong)`, 52_000, { assertions: { pass, total } }) : res('pass', `all ${total} scenario checks passed (a bot played the mod's main features)`, 52_000, { assertions: { pass, total } });
      }
      case 'soak': {
        const days = c.simDays;
        const crashAt = of('crash').length ? 5 + Math.floor(r() * (days - 10)) : 0;
        const leak = of('leak').length > 0, slow = of('slow').length > 0;
        const series: NonNullable<LayerResult['series']> = [];
        const step = Math.max(1, Math.round(days / 25));
        let last = 0;
        for (let d = step; d <= days; d += step) {
          if (crashAt && d >= crashAt) break;
          series.push({ day: d, tickMs: Math.round((1.6 + r() * 0.6 + (slow ? d * 0.45 : 0)) * 10) / 10, memMb: Math.round(640 + r() * 14 + (leak ? d * 9 : d * 0.12)) });
          last = d;
          await this.wait(2);
        }
        const worst = Math.max(...series.map((s) => s.tickMs), 0);
        const grew = series.length > 4 && series[series.length - 1].memMb - series[0].memMb > 150;
        const ms = (crashAt || days) * 1000;
        if (crashAt) return fail('crash', `the game crashed on day ${crashAt}`, ms, { series, simDays: last, crashes: 1 });
        if (grew) return fail('leak', `memory kept growing (${series[0].memMb} MB to ${series[series.length - 1].memMb} MB over ${days} days)`, ms, { series, simDays: days, crashes: 0 });
        if (worst > 40) return fail('slow', `ticks got slow (${worst} ms, the limit is 50 ms)`, ms, { series, simDays: days, crashes: 0 });
        return res('pass', `${days} game days (${(days * TICKS_PER_DAY / 1e6).toFixed(1)}M ticks) with no crash, flat memory, worst tick ${worst} ms`, ms, { series, simDays: days, crashes: 0 });
      }
      case 'compat':
        await this.wait(45);
        return of('compat').length ? fail('compat', 'conflicts with another mod (two mixins change the same method)', 61_000) : res('pass', 'ran with Sodium, Lithium, Iris and Controlify: no conflicts', 61_000);
      case 'multiplayer':
        await this.wait(35);
        return of('desync').length ? fail('desync', 'players saw different things (server and client disagree)', 47_000) : res('pass', '4 bots on one server: everyone saw the same thing', 47_000);
      case 'regression': {
        await this.wait(10);
        const back = c.project.regress.filter((id) => defects.some((d) => d.kind === id.split(':')[0]));
        return back.length ? res('fail', `a bug that was fixed before came back: ${back[0]}`, 12_000, { errors: back }) : res('pass', `${c.project.regress.length} past bugs checked, none came back`, 12_000);
      }
    }
  }
}

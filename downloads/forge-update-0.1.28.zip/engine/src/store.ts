// State saved to data/state.json: crash-safe (write a temp file, keep the old one as a backup).
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, copyFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { AgentId, ApprovalCard, ChatMsg, EventRec, Project, VersionProfile } from './types.ts';

export interface State {
  projects: Project[];
  cards: ApprovalCard[];
  events: EventRec[];
  chat: ChatMsg[];
  profiles: VersionProfile[];
  /** Short error-to-fix notes every agent reads on later runs (the "lessons file"). */
  lessons: string[];
  tokens: Record<AgentId, number>;
  tokensDay: string;
  aiMonthCost: number;
  aiMonthKey: string;
  /** The kill switch: nothing runs while this is true. */
  paused: boolean;
  /** Overnight mode: until this time the team runs on its own; big decisions still wait. */
  overnightUntil: number;
  /** Autopilot: keeps going on its own until Brian stops it. Safe steps are approved; publishing never is. */
  autopilot: { on: boolean; since: number; rounds: number; note: string };
  seq: number;
  ids: number;
  lastScoutAt: number;
}

export function emptyState(): State {
  return {
    projects: [], cards: [], events: [], chat: [], profiles: [], lessons: [],
    tokens: { foreman: 0, coder: 0, builder: 0, tester: 0, scout: 0, publisher: 0 }, tokensDay: '',
    aiMonthCost: 0, aiMonthKey: '', paused: false, overnightUntil: 0, autopilot: { on: false, since: 0, rounds: 0, note: '' }, seq: 0, ids: 0, lastScoutAt: 0,
  };
}

export class Store {
  state: State;
  file: string | null;
  constructor(file: string | null) {
    this.file = file;
    this.state = emptyState();
    if (file) this.load();
  }
  private load(): void {
    for (const f of [this.file!, this.file! + '.bak']) {
      try {
        if (!existsSync(f)) continue;
        const j = JSON.parse(readFileSync(f, 'utf8'));
        this.state = { ...emptyState(), ...j, tokens: { ...emptyState().tokens, ...(j.tokens ?? {}) }, autopilot: { ...emptyState().autopilot, ...(j.autopilot ?? {}) } };
        return;
      } catch { /* try the backup */ }
    }
  }
  save(): void {
    if (!this.file) return;
    mkdirSync(dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    writeFileSync(tmp, JSON.stringify(this.state));
    if (existsSync(this.file)) { try { copyFileSync(this.file, this.file + '.bak'); } catch { /* fine */ } }
    renameSync(tmp, this.file);
  }
  id(prefix: string): string { this.state.ids++; return prefix + this.state.ids.toString(36); }
  project(id: string): Project | undefined { return this.state.projects.find((p) => p.id === id); }
  card(id: string): ApprovalCard | undefined { return this.state.cards.find((c) => c.id === id); }
  addEvent(e: Omit<EventRec, 'n'>): EventRec {
    const rec: EventRec = { ...e, n: ++this.state.seq };
    this.state.events.push(rec);
    if (this.state.events.length > 1500) this.state.events.splice(0, this.state.events.length - 1500);
    return rec;
  }
  addLesson(text: string): void {
    const t = text.trim().slice(0, 240);
    if (!t || this.state.lessons.includes(t)) return;
    this.state.lessons.push(t);
    if (this.state.lessons.length > 40) this.state.lessons.shift();
  }
}

// Model adapter. The engine talks to `ModelClient`, never to a vendor directly,
// so a backup vendor (or the stand-in model used for practice) can be swapped in.

import type { Msg, ModelReply, Tier, ToolSpec } from './types.ts';
import { MODELS, LIMITS } from './config.ts';

export interface ModelRequest {
  tier: Tier;
  /** Guide + profile: identical across calls, so it is sent with a cache marker. */
  systemCached: string;
  /** Notes, plan, task: changes per call. */
  systemFresh: string;
  messages: Msg[];
  tools: ToolSpec[];
  /** Who is calling, for logs and the stand-in model. */
  agent: string;
  /** Room for the answer. Readers and scenario writers need more than the short helpers get. */
  maxTokens?: number;
}

export interface ModelClient {
  name: string;
  call(req: ModelRequest): Promise<ModelReply>;
}

/** Rough token count (about 4 characters a token). Good enough for budgets and the 100K cap. */
export function estimateTokens(s: string): number {
  return Math.ceil(s.length / 4);
}

export function requestTokens(req: ModelRequest): number {
  const msgs = req.messages
    .map((m) => (m.text ?? '') + JSON.stringify(m.toolCalls ?? '') + JSON.stringify(m.toolResults ?? ''))
    .join('');
  return estimateTokens(req.systemCached + req.systemFresh + msgs + JSON.stringify(req.tools));
}

export class PromptTooLarge extends Error {}

/** Throws if a request would cross the 100K-token line (Haiku 5.5 charges 5x above it). */
export function assertSize(req: ModelRequest): number {
  const n = requestTokens(req);
  if (n > LIMITS.maxPromptTokens) throw new PromptTooLarge(`request is ~${n} tokens, over the ${LIMITS.maxPromptTokens} cap`);
  return n;
}

/**
 * Real Claude client over the Messages API. The key comes from Setup (or ANTHROPIC_API_KEY) on this computer only.
 * The guide text is marked for prompt caching, so repeat calls pay $0.01 per M tokens for it.
 */
export class ClaudeClient implements ModelClient {
  name = 'claude';
  private key: string;
  private fetchImpl: typeof fetch;
  constructor(key: string, fetchImpl: typeof fetch = fetch) { this.key = key; this.fetchImpl = fetchImpl; }

  async call(req: ModelRequest): Promise<ModelReply> {
    assertSize(req);
    const body = {
      model: MODELS[req.tier],
      // short replies for the cheap helpers: output tokens cost 5x input
      max_tokens: req.maxTokens ?? (req.agent.startsWith('tester') ? 600 : req.agent === 'foreman' ? 2400 : 6000),
      system: [
        // the shared guide is reused by every agent and mod, so it is kept for an hour (longer TTLs must come first)
        { type: 'text', text: req.systemCached, cache_control: { type: 'ephemeral', ttl: '1h' } },
        { type: 'text', text: req.systemFresh },
      ].filter((b) => b.text.trim().length > 0),
      tools: req.tools.map((t) => ({
        name: t.name,
        description: t.description,
        input_schema: {
          type: 'object',
          properties: Object.fromEntries(Object.entries(t.params).map(([k, p]) => [k, { type: p.type, description: p.description }])),
          required: Object.entries(t.params).filter(([, p]) => !p.optional).map(([k]) => k),
        },
      })),
      messages: withCacheMark(req.messages.map(toApiMessage)),
    };
    // Up to 3 tries on rate limits or server errors, with a short backoff.
    let lastErr = '';
    for (let attempt = 0; attempt < 3; attempt++) {
      const res = await this.fetchImpl('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'x-api-key': this.key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const j = (await res.json()) as ApiResponse;
        const text = j.content.filter((c) => c.type === 'text').map((c) => c.text ?? '').join('\n');
        const toolCalls = j.content
          .filter((c) => c.type === 'tool_use')
          .map((c) => ({ id: c.id ?? '', name: c.name ?? '', args: (c.input ?? {}) as Record<string, unknown> }));
        return {
          text,
          toolCalls,
          done: j.stop_reason !== 'tool_use',
          usage: {
            // cache writes cost more than plain input (1.25x for 5 minutes, 2x for 1 hour); count them as extra input so the budget is honest
            input: (j.usage.input_tokens ?? 0) + Math.round((j.usage.cache_creation_input_tokens ?? 0) * 1.6),
            cachedInput: j.usage.cache_read_input_tokens ?? 0,
            output: j.usage.output_tokens ?? 0,
          },
        };
      }
      lastErr = `${res.status} ${await res.text()}`;
      if (res.status !== 429 && res.status < 500) break;
      await new Promise((r) => setTimeout(r, 1000 * (attempt + 1) ** 2));
    }
    throw new Error('Claude API error: ' + lastErr);
  }
}

interface ApiResponse {
  content: { type: string; text?: string; id?: string; name?: string; input?: unknown }[];
  stop_reason: string;
  usage: { input_tokens?: number; output_tokens?: number; cache_read_input_tokens?: number; cache_creation_input_tokens?: number };
}

function toApiMessage(m: Msg): { role: string; content: unknown[] } {
  const content: unknown[] = [];
  if (m.toolResults) for (const r of m.toolResults) content.push({ type: 'tool_result', tool_use_id: r.id, content: r.content, is_error: !r.ok });
  if (m.text) content.push({ type: 'text', text: m.text });
  if (m.toolCalls) for (const c of m.toolCalls) content.push({ type: 'tool_use', id: c.id, name: c.name, input: c.args });
  if (!content.length) content.push({ type: 'text', text: '(continue)' });
  return { role: m.role, content };
}

/** Marks the last block of the last message so each step of an agent loop re-reads the earlier steps at 10% price. */
function withCacheMark(msgs: { role: string; content: unknown[] }[]): { role: string; content: unknown[] }[] {
  if (msgs.length < 2) return msgs;
  const last = msgs[msgs.length - 1];
  const blocks = last.content.map((b) => ({ ...(b as object) }));
  const i = blocks.length - 1;
  (blocks[i] as Record<string, unknown>).cache_control = { type: 'ephemeral' };
  return [...msgs.slice(0, -1), { ...last, content: blocks }];
}

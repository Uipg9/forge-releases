// Every number Brian might want to change lives here.
import type { AgentId, CardKind, Tier } from './types.ts';

export const MODELS: Record<Tier, string> = {
  worker: 'claude-haiku-5-5',
  thinker: 'claude-sonnet-5-5',
};

/** Price per million tokens, used for the cost log. */
export const PRICES: Record<Tier, { input: number; cached: number; output: number }> = {
  // Dollars per million tokens. Brian's console matched this table closely ($2.16 real vs about the same here), so it stays.
  worker: { input: 0.1, cached: 0.01, output: 0.5 },
  thinker: { input: 2, cached: 0.1, output: 10 },
};

/** Foreman and Coder write and judge code, so they get the stronger model. Testers triage logs. */
export const AGENT_TIER: Record<AgentId, Tier> = {
  foreman: 'thinker', coder: 'thinker', builder: 'worker', tester: 'worker', scout: 'worker', publisher: 'worker',
};

export const LIMITS = {
  /** Claude (AI) budget per month in dollars before the team stops and waits. */
  aiBudget: 10,
  /** Dollars one mod may spend in total before it parks. */
  modBudget: 5,
  /** How many times the Builder sends errors back to the Coder before the mod is parked. */
  fixRounds: 4,
  /** The same error this many times in a row parks the mod instead of looping. */
  sameErrorMax: 3,
  /** Tester workers that run test layers at the same time. */
  testers: 3,
  /** Coder workers that write different files at the same time. */
  coders: 2,
  maxFiles: 24,
  maxFileBytes: 40_000,
  /** Steps (model calls) one agent may take on one task. */
  maxSteps: 8,
  /** Simulated game days in a full soak (one day is 24,000 ticks). */
  soakDays: 100,
  /** Mods waiting in line. */
  queueMax: 20,
  /** A single model call may not go over this many tokens. */
  maxPromptTokens: 100_000,
  /** Mods that may run through the pipeline at once. */
  concurrentProjects: 1,
};

export const MINUTE = 60_000;
export const HOUR = 3_600_000;

/** How long a card waits before its safe path runs. null = never times out. A timeout is never a yes. */
export const TIMEOUTS: Record<CardKind, number | null> = {
  scope: 24 * HOUR,
  port: 7 * 24 * HOUR,
  publish: null,
  setup: null,
  idea: 7 * 24 * HOUR,
  stuck: 3 * 24 * HOUR,
};

export const TICKS_PER_DAY = 24_000;
export const VERSION = '0.1.28';

// HTTP API the desktop window and the phone talk to, plus the clock. node:http only.
// Every /api route needs the app key, except /api/hello (so the phone can check an address before pairing)
// and /api/app/* from this same computer (the launcher).
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname, normalize, sep } from 'node:path';
import type { Studio } from './studio.ts';
import { LIMITS, VERSION } from './config.ts';
import { publishToGithub, githubWho } from './github.ts';
import { reveal, type Opener } from './reveal.ts';
import { researchCheck } from './research.ts';
import { type Config, lanAddresses, checkClaudeKey, cleanSettings, applyLimits } from './settings.ts';
import { ClaudeClient, type ModelClient } from './model.ts';
import type { Updater } from './updates.ts';
import { LAYERS, MODES } from './types.ts';
import { listModFiles, readModFile } from './modfiles.ts';

const TYPES: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8' };

async function body(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of req) { size += (c as Buffer).length; if (size > 100_000) throw new Error('body too large'); chunks.push(c as Buffer); }
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  const parsed = JSON.parse(raw);
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
}
function send(res: ServerResponse, code: number, data: unknown): void {
  res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization, content-type', 'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS' });
  res.end(JSON.stringify(data));
}
const isLocal = (req: IncomingMessage) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress ?? '');

export interface ServeOpts {
  port: number;
  config: Config;
  appDir: string | null;
  practiceModel: () => ModelClient;
  tickMs: number;
  onQuit?: () => void;
  updater?: Updater;
  /** For tests: stands in for the real web requests and for opening folders. */
  fetch?: typeof fetch;
  opener?: Opener;
}

export function serve(studio: Studio, o: ServeOpts) {
  const s = studio.store.state;
  const cfg = o.config;
  const useKey = () => { studio.d.model = () => (cfg.secrets.anthropicKey && !cfg.settings.demo ? new ClaudeClient(cfg.secrets.anthropicKey) : o.practiceModel()); };
  useKey();
  const mode = () => (cfg.secrets.anthropicKey && !cfg.settings.demo ? 'claude' : 'practice');
  let lastAction = 0;
  const updateInfo = () => ({ ...(o.updater?.info() ?? { current: VERSION, latest: null, available: false, checkedAt: 0, status: 'idle', error: '', canInstall: false, last: null }), autoUpdate: cfg.settings.autoUpdate });
  const cardView = (c: (typeof s.cards)[number]) => ({ ...c, project: c.project ? s.projects.find((p) => p.id === c.project)?.name : undefined, projectId: c.project });

  const routes: [string, RegExp, (m: RegExpMatchArray, b: Record<string, unknown>) => Promise<unknown> | unknown][] = [
    ['GET', /^\/api\/state$/, () => ({
      version: VERSION, mode: mode(), paused: s.paused, profiles: s.profiles, limits: LIMITS, layers: LAYERS, modes: MODES,
      aiMonthCost: Math.round(s.aiMonthCost * 100) / 100, aiBudget: cfg.settings.aiBudget, now: studio.now,
      agents: studio.agents(), toolchain: studio.d.toolchain().name,
      projects: s.projects.map((p) => ({ id: p.id, name: p.name, modId: p.modId, mode: p.mode, profile: p.profile, stage: p.stage, note: p.note, layers: p.layers, rounds: p.rounds, files: p.files.length, tokens: p.tokens, cost: Math.round(p.cost * 1000) / 1000, version: p.version, shippedTo: p.shippedTo ?? null, research: p.research ? { summary: p.research.summary.slice(0, 1200), refs: p.research.refs, log: (p.research.log ?? []).slice(-30) } : null, githubUrl: p.githubUrl ?? null, githubRelease: p.githubRelease ?? null, idea: p.idea, createdAt: p.createdAt, updatedAt: p.updatedAt })),
      cards: s.cards.filter((c) => c.status === 'waiting' || c.status === 'later').map(cardView),
      working: [...studio.running],
      autopilot: s.autopilot, github: { connected: !!cfg.secrets.githubToken, user: cfg.secrets.githubUser ?? '', repo: cfg.settings.githubRepo },
    })],
    ['GET', /^\/api\/events$/, () => s.events.slice(-300)],
    ['GET', /^\/api\/events\/since\/(\d+)$/, (m) => ({ events: s.events.filter((e) => e.n > Number(m[1])).slice(-300), agents: studio.agents(), paused: s.paused })],
    ['GET', /^\/api\/chat$/, () => s.chat.slice(-100)],
    ['POST', /^\/api\/chat$/, async (_m, b) => ({ reply: await studio.chat(String(b.text ?? '')) })],
    ['POST', /^\/api\/mods$/, (_m, b) => studio.createProject(String(b.name ?? ''), String(b.idea ?? ''), String(b.mode ?? 'vanilla-plus'), typeof b.profile === 'string' ? b.profile : undefined)],
    ['GET', /^\/api\/mods\/(\w+)$/, (m) => s.projects.find((p) => p.id === m[1]) ?? { error: 'no such mod' }],
    ['POST', /^\/api\/mods\/(\w+)\/delete$/, (m) => { const p = studio.store.project(m[1]); return p ? { message: studio.deleteProject(p), mods: studio.s.projects.length } : { error: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/retest$/, (m) => { const p = studio.store.project(m[1]); return p ? { message: studio.retest(p) } : { error: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/retry$/, (m) => { const p = studio.store.project(m[1]); return p ? { message: studio.retry(p) } : { error: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/ship$/, async (m) => { const p = studio.store.project(m[1]); return p ? { message: await studio.ship(p) } : { error: 'no such mod' }; }],
    ['GET', /^\/api\/cards$/, () => s.cards.filter((c) => c.status === 'waiting' || c.status === 'later').map(cardView)],
    ['POST', /^\/api\/cards\/(\w+)$/, (m, b) => studio.decide(m[1], (['yes', 'no', 'later'].includes(String(b.decision)) ? b.decision : 'later') as 'yes' | 'no' | 'later')],
    ['POST', /^\/api\/autopilot$/, (_m, b) => studio.setAutopilot(b.on === true)],
    ['POST', /^\/api\/mods\/(\w+)\/playtest\/start$/, async (m) => { const p = studio.store.project(m[1]); return p ? studio.startPlaytest(p) : { ok: false, message: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/playtest\/stop$/, (m) => { const p = studio.store.project(m[1]); return p ? studio.stopPlaytest(p) : { ok: false, message: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/playtest\/say$/, async (m, b) => { const p = studio.store.project(m[1]); return p ? { reply: await studio.playtestSay(p, String(b.text ?? '')) } : { reply: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/playtest\/fix$/, (m) => { const p = studio.store.project(m[1]); return p ? studio.playtestFix(p) : { ok: false, message: 'no such mod' }; }],
    ['POST', /^\/api\/mods\/(\w+)\/playtest\/bug\/(\d+)\/remove$/, (m) => { const p = studio.store.project(m[1]); if (p) studio.removeBug(p, Number(m[2])); return { ok: true }; }],
    ['GET', /^\/api\/mods\/(\w+)\/playtest\/(\d+)$/, (m) => { const p = studio.store.project(m[1]); return p ? studio.playtestView(p, Number(m[2])) : { error: 'no such mod' }; }],
    ['GET', /^\/api\/mods\/(\w+)\/versions$/, (m) => { const p = studio.store.project(m[1]); return p ? { current: p.version, versions: studio.localVersions(p).map((v) => ({ version: v.version, jar: v.jar, bytes: v.bytes, at: v.at, release: v.release })) } : { error: 'no such mod' }; }],
    ['GET', /^\/api\/mods\/(\w+)\/files$/, (m) => { const p = studio.store.project(m[1]); return p ? { files: listModFiles(studio.dir(p)) } : { error: 'no such mod' }; }],
    ['GET', /^\/api\/mods\/(\w+)\/file\/(.+)$/, (m) => { const p = studio.store.project(m[1]); return p ? readModFile(studio.dir(p), decodeURIComponent(m[2])) : { error: 'no such mod' }; }],
    ['POST', /^\/api\/pause$/, (_m, b) => { studio.setPaused(b.paused === true); return { paused: s.paused }; }],
    ['POST', /^\/api\/scout$/, async () => studio.scoutNow()],
    ['GET', /^\/api\/setup$/, () => ({
      version: VERSION, mode: mode(), hasKey: !!cfg.secrets.anthropicKey, keyHint: cfg.keyHint(), githubHint: cfg.githubHint(), addresses: lanAddresses(o.port), port: o.port, settings: cfg.settings,
      canAutostart: process.platform === 'win32' && !!process.env.FORGE_EXE, aiMonthCost: Math.round(s.aiMonthCost * 100) / 100,
    })],
    ['POST', /^\/api\/setup\/key$/, async (_m, b) => {
      const key = String(b.key ?? '').trim();
      const check = await checkClaudeKey(key);
      if (!check.ok) return check;
      cfg.secrets.anthropicKey = key; cfg.saveSecrets();
      const wasDemo = cfg.settings.demo;
      if (wasDemo) { cfg.settings.demo = false; cfg.saveSettings(); } // a working key means the person wants the real thing
      useKey();
      return { ...check, message: check.message + (wasDemo ? ' Demo mode is now off.' : ''), mode: mode(), keyHint: cfg.keyHint(), settings: cfg.settings };
    }],
    ['POST', /^\/api\/setup\/github$/, async (_m, b) => {
      const token = String(b.token ?? '').trim();
      if (!token) return { ok: false, message: 'Paste the token first.' };
      const who = await githubWho(token, o.fetch);
      if (!who.ok) return who;
      cfg.secrets.githubToken = token; cfg.secrets.githubUser = who.login; cfg.saveSecrets();
      return { ...who, githubHint: cfg.githubHint() };
    }],
    ['DELETE', /^\/api\/setup\/github$/, () => { cfg.secrets.githubToken = ''; cfg.secrets.githubUser = ''; cfg.saveSecrets(); return { ok: true }; }],
    ['POST', /^\/api\/mods\/(\w+)\/github$/, async (m) => {
      const p = studio.store.project(m[1]);
      if (!p) return { ok: false, message: 'There is no such mod.' };
      if (!cfg.secrets.githubToken) return { ok: false, message: 'Connect GitHub in Settings first (it takes a minute).' };
      const input = studio.githubInput(p);
      if ('error' in input) return { ok: false, message: input.error };
      try {
        const common = { token: cfg.secrets.githubToken, repo: cfg.settings.githubRepo, fetch: o.fetch };
        const r = await publishToGithub({ ...input, ...common });
        studio.githubDone(p, r.folderUrl, r.releaseUrl);
        // older versions whose jars are still saved get their own releases too, so the history is all there
        let older = 0;
        for (const v of studio.unpublishedOld(p)) {
          const old = studio.githubOldInput(p, v);
          if ('error' in old) continue;
          try { const ro = await publishToGithub({ ...old, ...common }); studio.githubDone(p, ro.folderUrl, ro.releaseUrl, v); older++; } catch { /* the main publish worked; an old one can be retried */ }
        }
        return { ok: true, message: `Published ${p.name} ${p.version} to GitHub${older ? ` (and ${older} older version${older > 1 ? 's' : ''}, with their jars)` : ''}.`, folderUrl: r.folderUrl, releaseUrl: r.releaseUrl, repoUrl: r.repoUrl };
      } catch (e) { return { ok: false, message: String(e instanceof Error ? e.message : e).replace(cfg.secrets.githubToken, '…').slice(0, 300) }; }
    }],
    ['DELETE', /^\/api\/setup\/key$/, () => { cfg.secrets.anthropicKey = ''; cfg.saveSecrets(); useKey(); return { ok: true, mode: mode() }; }],
    ['POST', /^\/api\/setup\/settings$/, (_m, b) => {
      const { ok, problems } = cleanSettings(b);
      if (problems.length) return { ok: false, message: problems.join(' '), settings: cfg.settings };
      Object.assign(cfg.settings, ok);
      applyLimits(cfg.settings); cfg.saveSettings(); useKey();
      return { ok: true, settings: cfg.settings, mode: mode() };
    }],
    ['GET', /^\/api\/setup\/research-check$/, async () => ({ checks: studio.d.fetch ? await researchCheck(studio.d.fetch, studio.d.githubToken?.() || undefined) : [{ name: 'Internet', ok: false, detail: 'Not available in this mode.' }] })],
    ['POST', /^\/api\/spend$/, (_m, b) => { const a = (b as { amount?: unknown }).amount; if (typeof a !== 'number' || !Number.isFinite(a) || a < 0 || a > 100000) return { ok: false, message: 'Type the dollar amount shown in your Anthropic console.' }; studio.setMonthCost(a); return { ok: true, message: 'Spend this month set to $' + (Math.round(a * 100) / 100).toFixed(2) + '.' }; }],
    ['GET', /^\/api\/update$/, async () => { if (o.updater && Date.now() - o.updater.checkedAt > 5 * 60_000) await o.updater.check().catch(() => {}); return updateInfo(); }],
    ['POST', /^\/api\/update\/check$/, async () => { await o.updater?.check(); return updateInfo(); }],
    ['POST', /^\/api\/update\/install$/, async () => {
      if (!o.updater) return { ok: false, message: 'Updates install through Forge.exe on your Windows computer.' };
      if (studio.running.size) return { ok: false, message: 'The team is building a mod right now. Install when they finish, or leave it and it installs on its own later.' };
      return o.updater.install();
    }],
  ];

  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? '/', 'http://x');
      if (req.method !== 'GET' && url.pathname.startsWith('/api/') && !/^\/api\/(app\/|hello$|update$|events\/since)/.test(url.pathname)) lastAction = Date.now();
      if (req.method === 'OPTIONS') return send(res, 204, {});
      if (url.pathname === '/api/hello') return send(res, 200, { app: 'forge', version: VERSION });
      if (url.pathname.startsWith('/api/app/')) {
        if (!isLocal(req)) return send(res, 403, { error: 'local only' });
        if (url.pathname === '/api/app/key') return send(res, 200, { token: cfg.secrets.token });
        if (url.pathname === '/api/app/awake') return send(res, 200, { keepAwake: studio.running.size > 0, busy: studio.running.size > 0, startWithWindows: cfg.settings.startWithWindows });
        if (url.pathname === '/api/app/quit' && req.method === 'POST') { send(res, 200, { ok: true }); setTimeout(() => (o.onQuit ?? (() => process.exit(0)))(), 200); return; }
        return send(res, 404, { error: 'not found' });
      }
      if (url.pathname.startsWith('/api/')) {
        if (req.headers.authorization !== 'Bearer ' + cfg.secrets.token) return send(res, 401, { error: 'unauthorized' });
        const rv = url.pathname.match(/^\/api\/mods\/(\w+)\/reveal$/);
        if (rv && req.method === 'POST') {
          // opens a window on the computer running Forge, so only that computer may ask
          if (!isLocal(req)) return send(res, 200, { ok: false, message: 'Open Forge on the computer it runs on to show the file there.' });
          const p = studio.store.project(rv[1]);
          if (!p?.shippedTo) return send(res, 200, { ok: false, message: 'Publish the mod to your releases folder first.' });
          const want = String((await body(req)).version ?? '');
          const folder = /^[\w.+-]+$/.test(want) && studio.localVersions(p).some((v) => v.version === want) ? join(studio.d.dataDir, 'releases', p.modId, want) : p.shippedTo;
          return send(res, 200, reveal(folder, process.platform, o.opener));
        }
        for (const [method, re, fn] of routes) {
          const m = url.pathname.match(re);
          if (m && req.method === method) return send(res, 200, await fn(m, method === 'GET' ? {} : await body(req)));
        }
        return send(res, 404, { error: 'not found' });
      }
      if (!o.appDir) return send(res, 404, { error: 'no app' });
      const p = normalize(join(o.appDir, url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname)));
      if (!p.startsWith(normalize(o.appDir + sep)) || !existsSync(p) || statSync(p).isDirectory()) return send(res, 404, { error: 'not found' });
      res.writeHead(200, { 'content-type': TYPES[extname(p)] ?? 'application/octet-stream', 'cache-control': ['.html', '.js', '.css', '.webmanifest'].includes(extname(p)) ? 'no-cache' : 'max-age=86400' });
      res.end(readFileSync(p));
    } catch (e) {
      send(res, 500, { error: String(e).slice(0, 200) });
    }
  });

  // The clock: timeouts every tick, the Scout once a day, and a nudge so queued mods start.
  const tick = async () => {
    try {
      studio.processTimeouts();
      void studio.autopilotTick();
      if (studio.now - s.lastScoutAt > 24 * 3_600_000 && !cfg.settings.demo) await studio.scoutNow();
      void studio.kick();
      studio.store.save();
    } catch (e) { console.error('clock error:', e); }
  };
  const timer = setInterval(() => void tick(), o.tickMs);
  const first = setTimeout(() => void tick(), 1500);

  const upd = o.updater;
  const updateTick = async () => {
    if (!upd) return;
    if (Date.now() - upd.checkedAt > 9 * 60_000) await upd.check(); // one tiny file, so look every ten minutes
    if (upd.shouldAutoInstall({ autoUpdate: cfg.settings.autoUpdate, busy: studio.running.size > 0, lastAction })) { console.log('installing update ' + upd.latest?.version); await upd.install(); }
  };
  const updTimer = upd ? setInterval(() => void updateTick().catch(() => {}), 10 * 60_000) : null;
  const updFirst = upd ? setTimeout(() => void updateTick().catch(() => {}), 30_000) : null;

  server.listen(o.port);
  return { server, tick, stop: () => { clearInterval(timer); clearTimeout(first); if (updTimer) clearInterval(updTimer); if (updFirst) clearTimeout(updFirst); server.close(); } };
}

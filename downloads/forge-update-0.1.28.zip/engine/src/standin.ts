// The stand-in model: a pretend Foreman, Coder and Tester that need no API key. It is used for practice runs, the
// demo mode and the tests. It writes plausible Java, plants defects on purpose (a "FORGE-DEFECT:<kind>" comment the
// pretend toolchain can find), fixes them when handed errors (sometimes it fails, on purpose), and sometimes
// misbehaves (tries to write outside the mod, forbidden code, build files) so the Studio's rules get exercised.
import type { ModelReply, ToolCall } from './types.ts';
import type { ModelClient, ModelRequest } from './model.ts';
import { estimateTokens, requestTokens } from './model.ts';
import { DEFECTS, rng } from './sim/simtool.ts';
import { packageOf, toClass, toModId } from './template.ts';

export interface StandinOpts {
  seed: string;
  /** Chance that a file the Coder writes carries a planted defect. */
  mischief: number;
  /** Chance a Coder write is a rule-break the Studio must block. */
  rogue: number;
  /** Chance a fix does not actually fix it. */
  stubborn: number;
}
export const STANDIN_DEFAULTS: StandinOpts = { seed: 'forge', mischief: 0.35, rogue: 0.08, stubborn: 0.12 };

let counter = 0;
const call = (name: string, args: Record<string, unknown>): ToolCall => ({ id: 'tc' + ++counter, name, args });

export class StandinModel implements ModelClient {
  name = 'practice';
  o: StandinOpts;
  r: () => number;
  calls = 0;
  /** What the stand-in did on purpose, for the audit. */
  stats = { planted: 0, rogue: 0, fixed: 0, failedFix: 0 };
  constructor(o: Partial<StandinOpts> = {}) { this.o = { ...STANDIN_DEFAULTS, ...o }; this.r = rng(this.o.seed); }

  private reply(text: string, toolCalls: ToolCall[], req: ModelRequest): ModelReply {
    const input = requestTokens(req);
    return { text, toolCalls, usage: { input: Math.round(input * 0.15), cachedInput: Math.round(input * 0.85), output: estimateTokens(text) + 80 * toolCalls.length + 40 }, done: !toolCalls.length };
  }

  async call(req: ModelRequest): Promise<ModelReply> {
    this.calls++;
    const first = req.messages[0]?.text ?? '';
    const last = req.messages[req.messages.length - 1];
    const sawResults = last?.toolResults;
    if (sawResults) {
      // after a tool result, the agent finishes (the Studio also stops loops on `stop` results)
      const blocked = sawResults.some((x) => !x.ok);
      if (req.agent.startsWith('coder') && !/done/.test(JSON.stringify(req.messages.slice(-3)))) return this.reply(blocked ? 'Some writes were blocked; I will carry on with the rest.' : '', [call('done', { summary: 'wrote the files I was given' })], req);
      return this.reply(blocked ? 'That was blocked, so I stopped.' : 'Done.', [], req);
    }
    if (req.agent.startsWith('tester') && first.startsWith('PLAYTEST ')) return this.reply('Noted. I am watching the log and will add anything that looks wrong.', [], req);
    if (req.agent.startsWith('tester') && first.startsWith('SCENARIO ')) return this.reply('', [call('submit_scenario', { script: 'cmd forceload add 0 0\ncmd setblock 0 -60 0 minecraft:stone\ncmd execute if block 0 -60 0 minecraft:stone run say CHECK-1-OK\nexpect CHECK-1-OK\nwait 100\nforbid Exception' })], req);
    if (req.agent === 'scout' && first.startsWith('RESEARCH:')) return this.reply('', [call('submit_research', { summary: 'Example mods do this with a tick check; keep it small.', refs: 'Example Mod|https://github.com/example/example-mod|MIT|idea|Showed the tick-check approach' })], req);
    if (req.agent.startsWith('tester') && first.startsWith('JUDGE: ')) return this.reply('', [call('blame', { who: 'mod', why: 'The script looks fair.' })], req);
    if (req.agent.startsWith('tester') && first.startsWith('REVIEW ')) return this.reply('', [call('verdict', { ok: 'yes', summary: 'Traced each requirement through the code and found nothing definitely wrong.' })], req);
    if (req.agent === 'foreman' && first.startsWith('IMPROVE:')) return this.reply('', [call('propose_improvement', { change: 'Handle the edge case where the player is riding or in a boat, and keep a clear log line.' })], req);
    if (req.agent === 'foreman') return first.startsWith('PLAN:') ? this.plan(first, req) : this.chat(first, req);
    if (req.agent.startsWith('coder')) return first.startsWith('FIX:') ? this.fix(first, req) : this.write(first, req);
    if (req.agent.startsWith('tester')) {
      const file = first.match(/^(src\/[^\s:]+)/m)?.[1] ?? 'the file named in the log';
      return this.reply('', [call('diagnose', { file, cause: 'the planted problem in this file; see the log line' })], req);
    }
    return this.reply('Okay.', [], req);
  }

  // ---------- Foreman ----------
  private chat(first: string, req: ModelRequest): ModelReply {
    const said = first.split('Brian says:').pop()!.trim();
    const wants = /\b(make|build|create|add|i want|can you).*\b(mod|minecraft|mixin|sleep|villager|zombie|crop|chest|hopper|inventory|tool)/i.test(said) || /^(mod|make)\b/i.test(said);
    if (wants) {
      const quoted = said.match(/"([^"]{3,40})"/)?.[1];
      const derived = said.replace(/^(please |can you |(a mod )?(where|that|which) |i want (a |an )?|make (me )?(a |an )?|build (me )?(a |an )?|create (me )?(a |an )?)/i, '').replace(/\b(mod|minecraft)\b/gi, '').split(/[.,!?\n]/)[0].trim().split(/\s+/).slice(0, 3).map((w) => w[0]?.toUpperCase() + w.slice(1)).join(' ');
      const name = quoted ?? (derived || 'Little Helper');
      const mode = /\b(new (block|item|mob)|textures?|library|server[- ]only|client[- ]only|hud|minimap)\b/i.test(said) ? (/server/i.test(said) ? 'server' : /library/i.test(said) ? 'library' : /client|hud|minimap/i.test(said) ? 'client' : 'content') : 'vanilla-plus';
      return this.reply('On it.', [call('create_mod', { name, idea: said.slice(0, 400), mode })], req);
    }
    if (/status|going on|how('?s| is)|progress/i.test(said)) return this.reply(first.split('\n')[0].replace(/^STATUS:\s*/, 'Here is where things stand: '), [], req);
    return this.reply('Tell me the mod you want, in your own words, and I will get the helpers going.', [], req);
  }

  private plan(first: string, req: ModelRequest): ModelReply {
    const idea = first.match(/<idea>\n([\s\S]*?)\n<\/idea>/)?.[1] ?? '';
    const pkg = first.match(/Package:\s*([\w.]*\w)/)?.[1] ?? 'net.example';
    const dir = 'src/main/java/' + pkg.replace(/\./g, '/');
    const mode = first.match(/mode ([\w-]+)/)?.[1] ?? 'vanilla-plus';
    const stem = toClass(idea.split(/\s+/).slice(0, 2).join(' ') || 'Thing');
    const files = [`${dir}/mixin/${stem}Mixin.java|the targeted mixin`, `${dir}/${stem}Logic.java|the rule the mixin calls`];
    if (/\b(huge|everything|big)\b/i.test(idea)) for (let i = 0; i < 8; i++) files.push(`${dir}/Part${i}.java|helper ${i}`);
    else if (this.r() < 0.4) files.push(`${dir}/${stem}Config.java|settings`);
    // the Foreman sometimes lists something it should not; the Studio must drop it
    if (this.r() < 0.1) files.push('build.gradle|oops, a build file');
    if (this.r() < 0.05) files.push('../outside/Evil.java|oops, outside the folder');
    const spec = `${idea.slice(0, 200)}\nMust never: change anything outside this behavior, add new items or blocks.\nTest: boot, scenario checks, a ${'long'} soak.`;
    return this.reply('', [call('submit_plan', { spec, files: files.join(';'), needs_approval: /new (block|item)|texture/i.test(idea) ? 'it needs new assets' : mode !== 'vanilla-plus' ? '' : '' })], req);
  }

  // ---------- Coder ----------
  private java(path: string, task: string): string {
    const pkg = path.replace(/^src\/(main|client)\/java\//, '').replace(/\/[^/]+$/, '').replace(/\//g, '.');
    const cls = path.split('/').pop()!.replace('.java', '');
    const isMixin = /\/mixin\//.test(path);
    const modId = pkg.split('.').pop() ?? 'mod';
    void modId; void task;
    if (isMixin) return `package ${pkg};\n\nimport org.spongepowered.asm.mixin.Mixin;\nimport org.spongepowered.asm.mixin.injection.At;\nimport org.spongepowered.asm.mixin.injection.Inject;\nimport org.spongepowered.asm.mixin.injection.callback.CallbackInfo;\nimport net.minecraft.world.level.Level;\n\n@Mixin(Level.class)\npublic abstract class ${cls} {\n    @Inject(method = "tick", at = @At("HEAD"))\n    private void forge$onTick(CallbackInfo ci) {\n        // small, targeted change\n    }\n}\n`;
    return `package ${pkg};\n\npublic final class ${cls} {\n    private ${cls}() {}\n\n    public static boolean applies(int value) {\n        return value > 0;\n    }\n}\n`;
  }

  private plant(src: string): string {
    if (this.r() >= this.o.mischief) return src;
    const kind = DEFECTS[Math.floor(this.r() * DEFECTS.length)];
    this.stats.planted++;
    const i = src.lastIndexOf('\n}');
    return src.slice(0, i) + `\n    // FORGE-DEFECT:${kind}\n` + src.slice(i + 1);
  }

  private write(first: string, req: ModelRequest): ModelReply {
    const paths = [...first.matchAll(/^- (\S+?\.\w+):/gm)].map((m) => m[1]);
    const calls: ToolCall[] = [];
    for (const p of paths) {
      const body = p.endsWith('.java') ? this.plant(this.java(p, first)) : '{}\n';
      calls.push(call('write_file', { path: p, content: body }));
    }
    if (this.r() < this.o.rogue) {
      this.stats.rogue++;
      const pkg = packageOf(toModId('x')).split('.')[0];
      const bad = [
        call('write_file', { path: '../../escape.txt', content: 'x' }),
        call('write_file', { path: 'build.gradle', content: 'apply plugin: "evil"' }),
        call('write_file', { path: `src/main/java/${pkg}/Evil.java`, content: 'package x;\npublic class Evil { void a(){ Runtime.getRuntime().exec("calc"); } }' }),
        call('delete_everything', {}),
      ];
      calls.push(bad[Math.floor(this.r() * bad.length)]);
    }
    return this.reply('Writing the files now.', calls, req);
  }

  private fix(first: string, req: ModelRequest): ModelReply {
    const at = first.indexOf('Current files:');
    const parts = at < 0 ? [] : first.slice(at).split(/^--- /m).slice(1);
    const blocks = parts.map((seg) => { const nl = seg.indexOf('\n'); return [seg, seg.slice(0, nl).trim(), seg.slice(nl + 1).replace(/\nChange only what the errors point at\.\s*$/, '')] as const; });
    const calls: ToolCall[] = [];
    for (const b of blocks) {
      if (this.r() < this.o.stubborn) { this.stats.failedFix++; continue; }
      const fixed = b[2].split('\n').filter((l) => !/FORGE-DEFECT:/.test(l)).join('\n');
      this.stats.fixed++;
      calls.push(call('write_file', { path: b[1], content: fixed.endsWith('\n') ? fixed : fixed + '\n' }));
    }
    if (!calls.length) return this.reply('I could not see the problem in the files I was given.', [call('done', { summary: 'no change' })], req);
    return this.reply('Fixing what the errors point at.', calls, req);
  }
}

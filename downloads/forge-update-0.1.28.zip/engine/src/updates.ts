// Updates. A small file online (latest.json, in the public forge-releases repo) names the newest
// version. When it's newer, the engine downloads the update zip, checks its SHA-256, saves it in
// data/update/, writes ready.json and exits with code 75. Forge.exe then swaps the files, starts the
// new version, and goes back to the old one if the new one won't start (it leaves last.json saying how
// it went). Nothing here touches the API key or the business data.
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

export const RELEASES_API = 'https://api.github.com/repos/Uipg9/forge-releases/contents/latest.json';
export const RELEASES_URL = 'https://raw.githubusercontent.com/Uipg9/forge-releases/main/latest.json';
export const UPDATE_EXIT_CODE = 75;

export interface Latest {
  version: string;
  date?: string;
  notes?: string[];
  /** The update zip for an installed Forge (engine/ and Forge.exe). */
  engine?: { url: string; sha256: string; size?: number };
  /** The phone app. */
  android?: { version: string; url: string; notes?: string[] };
  /** The full Windows download, for a fresh install. */
  windows?: { url: string };
}

export interface UpdateResult { from: string; to: string; ok: boolean; why: string; at: number }

export interface UpdateInfo {
  current: string;
  latest: Latest | null;
  available: boolean;
  checkedAt: number;
  status: 'idle' | 'checking' | 'downloading' | 'installing' | 'error';
  error: string;
  canInstall: boolean;
  last: UpdateResult | null;
}

/** Whether version a is newer than b ("1.10.0" > "1.9.2"). */
export function newer(a: string, b: string): boolean {
  const p = (v: string) => String(v).replace(/^v/i, '').split(/[.+-]/).map((x) => parseInt(x, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0);
  }
  return false;
}

export interface UpdaterOptions {
  version: string;
  dataDir: string;
  url?: string;
  /** True when Forge.exe started this engine and can swap the files. */
  canInstall: boolean;
  fetch?: typeof fetch;
  exit?: (code: number) => void;
  beforeExit?: () => void;
  now?: () => number;
}

export class Updater {
  latest: Latest | null = null;
  checkedAt = 0;
  status: UpdateInfo['status'] = 'idle';
  error = '';
  readonly dir: string;
  private o: UpdaterOptions;

  constructor(o: UpdaterOptions) {
    this.o = o;
    this.dir = join(o.dataDir, 'update');
    // A leftover from an install that never happened must not be picked up later.
    try { rmSync(join(this.dir, 'ready.json'), { force: true }); } catch { /* fine */ }
  }

  private now(): number { return (this.o.now ?? Date.now)(); }

  get available(): boolean { return !!this.latest?.engine?.url && newer(this.latest.version, this.o.version); }

  /** How the last install went (written by Forge.exe). */
  lastResult(): UpdateResult | null {
    try {
      const f = join(this.dir, 'last.json');
      return existsSync(f) ? (JSON.parse(readFileSync(f, 'utf8')) as UpdateResult) : null;
    } catch { return null; }
  }

  info(): UpdateInfo {
    return { current: this.o.version, latest: this.latest, available: this.available, checkedAt: this.checkedAt, status: this.status, error: this.error, canInstall: this.o.canInstall, last: this.lastResult() };
  }

  async check(): Promise<UpdateInfo> {
    if (this.status === 'downloading' || this.status === 'installing') return this.info();
    this.status = 'checking';
    const f = this.o.fetch ?? fetch;
    const plain = { 'cache-control': 'no-cache' };
    // GitHub's raw file host keeps old copies for up to ~10 minutes; its API does not, so it goes first
    const sources: [string, Record<string, string>][] = this.o.url
      ? [[this.o.url, plain]]
      : [[RELEASES_API, { accept: 'application/vnd.github.raw+json', 'user-agent': 'forge-updater', ...plain }], [RELEASES_URL, plain]];
    let found: Latest | null = null, notFound = false, failed = false;
    for (const [u, headers] of sources) {
      try {
        const res = await f(u + '?t=' + this.now(), { signal: AbortSignal.timeout(15_000), headers });
        if (res.status === 404) { notFound = true; continue; }
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const j = (await res.json()) as Latest;
        if (!j || typeof j.version !== 'string' || !/^\d+\.\d+/.test(j.version)) throw new Error('not a version file');
        found = j; break;
      } catch { failed = true; }
    }
    if (found) { this.latest = found; this.error = ''; }
    else if (notFound && !failed) { this.latest = null; this.error = ''; } // nothing published yet
    else this.error = 'Couldn\'t reach the update server. It will try again later.';
    this.checkedAt = this.now();
    this.status = this.error ? 'error' : 'idle';
    return this.info();
  }

  /** Downloads and checks the update, then hands it to Forge.exe (the engine exits a moment later). */
  async install(): Promise<{ ok: boolean; message: string }> {
    if (!this.o.canInstall) return { ok: false, message: 'Updates install through Forge.exe on your Windows computer.' };
    if (this.status === 'downloading' || this.status === 'installing') return { ok: true, message: 'Already installing.' };
    if (!this.available) await this.check();
    const l = this.latest;
    if (!l?.engine || !this.available) return { ok: false, message: this.error || 'You already have the newest version.' };
    this.status = 'downloading';
    try {
      const f = this.o.fetch ?? fetch;
      const res = await f(l.engine.url, { signal: AbortSignal.timeout(180_000), redirect: 'follow' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 100 || buf.length > 300 * 1024 * 1024) throw new Error('bad size');
      const sum = createHash('sha256').update(buf).digest('hex');
      if (sum !== String(l.engine.sha256).toLowerCase()) throw new Error('checksum');
      mkdirSync(this.dir, { recursive: true });
      for (const x of readdirSync(this.dir)) if (x.endsWith('.zip')) rmSync(join(this.dir, x), { force: true });
      const zip = join(this.dir, `forge-${l.version.replace(/[^\w.-]/g, '')}.zip`);
      writeFileSync(zip, buf);
      writeFileSync(join(this.dir, 'ready.json'), JSON.stringify({ version: l.version, from: this.o.version, zip, sha256: sum }));
    } catch (e) {
      this.status = 'error';
      this.error = String(e).includes('checksum')
        ? 'The download didn\'t match its checksum, so it wasn\'t installed. It will try again later.'
        : 'Couldn\'t download the update. It will try again later.';
      return { ok: false, message: this.error };
    }
    this.status = 'installing';
    setTimeout(() => {
      try { this.o.beforeExit?.(); } finally { (this.o.exit ?? process.exit)(UPDATE_EXIT_CODE); }
    }, 800);
    return { ok: true, message: `Installing Forge ${l.version}. It'll be back in a few seconds.` };
  }

  /** Whether to install on its own right now: setting on, no mod being built, and nobody touched the app for 5 minutes. */
  shouldAutoInstall(o: { autoUpdate: boolean; busy: boolean; lastAction: number }): boolean {
    if (!o.autoUpdate || !this.o.canInstall || !this.available || o.busy || this.status === 'downloading' || this.status === 'installing') return false;
    if (this.now() - o.lastAction < 5 * 60_000) return false;
    const last = this.lastResult();
    if (last && !last.ok && last.to === this.latest?.version) return false;
    return true;
  }
}

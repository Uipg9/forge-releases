// Opens the folder that holds a file and selects the file, on the computer Forge runs on (so you can copy the jar).
import { spawn } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/** The mod's jar inside its release folder, if there is one. */
export function findJar(dir: string): string | null {
  try { const j = readdirSync(dir).find((n) => n.endsWith('.jar') && !n.endsWith('-sources.jar')); return j ? join(dir, j) : null; } catch { return null; }
}

export type Opener = (cmd: string, args: string[], verbatim: boolean) => void;
const realOpener: Opener = (cmd, args, verbatim) => { const c = spawn(cmd, args, { detached: true, stdio: 'ignore', windowsVerbatimArguments: verbatim }); c.on('error', () => {}); c.unref(); };

export function reveal(dir: string, platform: NodeJS.Platform = process.platform, open: Opener = realOpener): { ok: boolean; message: string; path: string } {
  if (!dir || !existsSync(dir) || !statSync(dir).isDirectory()) return { ok: false, message: 'That folder is not there any more.', path: dir };
  const jar = findJar(dir);
  if (platform === 'win32') open('explorer.exe', jar ? [`/select,"${jar}"`] : [`"${dir}"`], true);
  else if (platform === 'darwin') open('open', jar ? ['-R', jar] : [dir], false);
  else open('xdg-open', [dir], false);
  return { ok: true, message: jar ? 'Showing the jar.' : 'Opened the folder (there is no jar in it, this was a demo build).', path: jar ?? dir };
}

// The Fabric mod project a new mod starts from, one per version profile.
// 26.x: plugin id net.fabricmc.fabric-loom, no mappings line, plain dependencies, plain jar.
// 1.21.11: plugin id fabric-loom, Mojang mappings, modImplementation, remapped jar.
import type { Mode, VersionProfile } from './types.ts';

export interface ModSpec { modId: string; name: string; description: string; mode: Mode; version?: string }

export const toModId = (name: string): string => {
  const s = name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return (/^[a-z]/.test(s) ? s : 'm_' + s).slice(0, 40) || 'forge_mod';
};
export const toClass = (name: string): string => {
  const s = name.replace(/[^A-Za-z0-9 ]+/g, ' ').split(/\s+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join('');
  return (/^[A-Za-z]/.test(s) ? s : 'Mod' + s).slice(0, 40) || 'ForgeMod';
};
export const packageOf = (modId: string): string => 'com.forge.' + modId.replace(/_/g, '');

export function skeleton(p: VersionProfile, spec: ModSpec): Record<string, string> {
  const pkg = packageOf(spec.modId);
  const cls = toClass(spec.name);
  const dir = 'src/main/java/' + pkg.replace(/\./g, '/');
  const v = spec.version ?? '0.1.0';
  const files: Record<string, string> = {};

  files['settings.gradle'] = `pluginManagement {
    repositories {
        maven { name = 'Fabric'; url = 'https://maven.fabricmc.net/' }
        mavenCentral()
        gradlePluginPortal()
    }
}
rootProject.name = '${spec.modId}'
`;

  files['gradle.properties'] = `org.gradle.jvmargs=-Xmx2G
org.gradle.parallel=true
minecraft_version=${p.mc}
loader_version=${p.loader}
fabric_api_version=${p.fabricApi}
loom_version=${p.loom}
mod_version=${v}
maven_group=com.forge
archives_base_name=${spec.modId}
`;

  const deps = p.unobfuscated
    ? `    minecraft "com.mojang:minecraft:\${project.minecraft_version}"
    implementation "net.fabricmc:fabric-loader:\${project.loader_version}"
    implementation "net.fabricmc.fabric-api:fabric-api:\${project.fabric_api_version}"`
    : `    minecraft "com.mojang:minecraft:\${project.minecraft_version}"
    mappings loom.officialMojangMappings()
    modImplementation "net.fabricmc:fabric-loader:\${project.loader_version}"
    modImplementation "net.fabricmc.fabric-api:fabric-api:\${project.fabric_api_version}"`;
  files['build.gradle'] = `plugins {
    id '${p.loomId}' version "\${loom_version}"
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group
base { archivesName = project.archives_base_name }

repositories {
    mavenCentral()
}

dependencies {
${deps}
}

processResources {
    inputs.property 'version', project.version
    filesMatching('fabric.mod.json') { expand 'version': project.version }
}

tasks.withType(JavaCompile).configureEach {
    it.options.release = ${p.java}
    it.options.compilerArgs << '-Xlint:all' << '-Xlint:-processing'
}

java {
    withSourcesJar()
    sourceCompatibility = JavaVersion.VERSION_${p.java}
    targetCompatibility = JavaVersion.VERSION_${p.java}
}

jar { from('LICENSE') { rename { "\${it}_\${project.base.archivesName.get()}" } } }
`;

  files['LICENSE'] = `MIT License\n\nCopyright (c) ${new Date().getFullYear()} Brian\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, subject to the usual MIT conditions.\n`;

  files['src/main/resources/fabric.mod.json'] = JSON.stringify({
    schemaVersion: 1, id: spec.modId, version: '${version}', name: spec.name, description: spec.description.slice(0, 200),
    authors: ['Brian'], license: 'MIT', environment: spec.mode === 'client' ? 'client' : spec.mode === 'server' ? 'server' : '*',
    entrypoints: { main: [pkg + '.' + cls] }, mixins: [spec.modId + '.mixins.json'],
    depends: { fabricloader: '>=' + p.loader, minecraft: '>=' + p.mc, java: '>=' + p.java, 'fabric-api': '*' },
  }, null, 2) + '\n';
  files[`src/main/resources/${spec.modId}.mixins.json`] = JSON.stringify({
    required: true, package: pkg + '.mixin', compatibilityLevel: 'JAVA_' + p.java, mixins: [], injectors: { defaultRequire: 1 },
  }, null, 2) + '\n';
  files[dir + '/' + cls + '.java'] = `package ${pkg};

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ${cls} implements ModInitializer {
    public static final String MOD_ID = "${spec.modId}";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("${spec.name} loaded");
    }
}
`;
  files['README.md'] = `# ${spec.name}\n\n${spec.description}\n\nMade with Forge for Minecraft ${p.mc} (Fabric). Mode: ${spec.mode}.\n`;
  return files;
}

/** Where the Coder may write: only inside the mod's own package, resources and test folders. */
export function allowedPath(path: string, spec: ModSpec): boolean {
  const p = path.replace(/\\/g, '/');
  if (p.includes('..') || p.startsWith('/') || /^[A-Za-z]:/.test(p)) return false;
  const pkgDir = 'src/main/java/' + packageOf(spec.modId).replace(/\./g, '/') + '/';
  const clientDir = 'src/client/java/' + packageOf(spec.modId).replace(/\./g, '/') + '/';
  if ((p.startsWith(pkgDir) || p.startsWith(clientDir)) && p.endsWith('.java')) return true;
  if (p === `src/main/resources/${spec.modId}.mixins.json`) return true;
  if (p.startsWith('src/main/resources/data/' + spec.modId + '/') && p.endsWith('.json')) return true;
  if (p.startsWith('src/main/resources/assets/' + spec.modId + '/') && /\.(json|lang)$/.test(p)) return true;
  if (p === 'README.md' || p === 'CHANGELOG.md') return true;
  return false;
}

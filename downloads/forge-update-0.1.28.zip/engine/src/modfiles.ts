// Lets the app show a mod's files. Read-only, text files only, and never outside the mod's own folder.
import { readdirSync, readFileSync, statSync, lstatSync } from 'node:fs';
import { join, resolve, sep } from 'node:path';

const SKIP = new Set(['build', '.gradle', 'run', 'node_modules', '.git', 'bin', '.idea', 'out']);
const TEXT = /\.(java|json|md|gradle|properties|txt|toml|mcmeta|lang|xml|yml|yaml|kts)$/i;
const MAX_BYTES = 200_000;

export function listModFiles(root: string): { path: string; size: number }[] {
  const out: { path: string; size: number }[] = [];
  const walk = (dir: string, rel: string, depth: number): void => {
    if (depth > 10 || out.length >= 300) return;
    let ents: import('node:fs').Dirent[];
    try { ents = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents.sort((a, b) => a.name.localeCompare(b.name))) {
      if (e.isSymbolicLink()) continue;
      const r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) { if (!SKIP.has(e.name)) walk(join(dir, e.name), r, depth + 1); }
      else if (e.isFile() && TEXT.test(e.name)) { try { out.push({ path: r, size: statSync(join(dir, e.name)).size }); } catch { /* vanished */ } }
    }
  };
  walk(root, '', 0);
  return out.sort((a, b) => Number(!a.path.startsWith('src/')) - Number(!b.path.startsWith('src/')) || a.path.localeCompare(b.path));
}

export function readModFile(root: string, rel: string): { path: string; text: string; truncated: boolean } | { error: string } {
  const bad = { error: 'that is not a file you can view' };
  const clean = rel.replace(/\\/g, '/');
  const parts = clean.split('/');
  if (!clean || clean.startsWith('/') || /^[A-Za-z]:/.test(clean) || parts.includes('..') || !TEXT.test(clean) || parts.some((x) => SKIP.has(x))) return bad;
  const base = resolve(root);
  const full = resolve(base, clean);
  if (!full.startsWith(base + sep)) return bad;
  try {
    if (!lstatSync(full).isFile()) return bad;
    const buf = readFileSync(full);
    return { path: clean, text: buf.subarray(0, MAX_BYTES).toString('utf8'), truncated: buf.length > MAX_BYTES };
  } catch { return { error: 'that file is not there (yet)' }; }
}

// Publishes a finished mod to a PUBLIC GitHub repo: one folder per mod (source, README, changelog), one commit per
// publish, and a GitHub Release per version with the .jar attached. Uses only GitHub's REST API, no git needed.
// Only ever runs when Brian presses the button on a mod; the token stays on this computer and goes only to api.github.com.
import { Buffer } from 'node:buffer';

export interface PublishInput {
  token: string;
  /** Repository name under the token's own account, for example "forge-mods". */
  repo: string;
  modId: string;
  name: string;
  version: string;
  /** Text and other files for the mod's folder in the repo, paths relative to that folder. */
  files: { path: string; data: Buffer }[];
  jar?: { name: string; data: Buffer };
  /** The new version's changelog section; it is added above the older ones already in the repo. */
  changelogEntry: string;
  /** An older version: only its GitHub Release (with its jar) is made, the folder in the repo is not touched. */
  releaseOnly?: boolean;
  fetch?: typeof fetch;
}
export interface PublishResult { owner: string; repoUrl: string; folderUrl: string; releaseUrl: string; commit: string; created: boolean }

export const REPO_NAME = /^[A-Za-z0-9._-]{1,100}$/;
const API = 'https://api.github.com';

class GhError extends Error {}

function client(token: string, f: typeof fetch) {
  const headers = (extra: Record<string, string> = {}) => ({ Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Uipg9-forge', ...extra });
  async function call(method: string, url: string, body?: unknown, extra: Record<string, string> = {}, raw?: Buffer): Promise<{ status: number; json: any }> {
    const res = await f(url.startsWith('http') ? url : API + url, { method, headers: headers(body !== undefined ? { 'Content-Type': 'application/json', ...extra } : extra), body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined) } as RequestInit);
    let json: any = null;
    try { json = await res.json(); } catch { /* empty body */ }
    return { status: res.status, json };
  }
  const must = async (method: string, url: string, body?: unknown, what = 'GitHub') => {
    const r = await call(method, url, body);
    if (r.status >= 200 && r.status < 300) return r.json;
    if (r.status === 401) throw new GhError('GitHub did not accept the token. Make a new one and paste it in Settings.');
    throw new GhError(`${what} failed (${r.status}): ${String(r.json?.message ?? 'no details').slice(0, 160)}`);
  };
  return { call, must, headers };
}

/** Checks a token and says whose it is. */
export async function githubWho(token: string, f: typeof fetch = fetch): Promise<{ ok: boolean; login: string; message: string }> {
  try {
    const r = await client(token, f).call('GET', '/user');
    if (r.status === 200 && r.json?.login) return { ok: true, login: String(r.json.login), message: `Connected to GitHub as ${r.json.login}.` };
    if (r.status === 401) return { ok: false, login: '', message: 'GitHub did not accept that token.' };
    return { ok: false, login: '', message: `GitHub said ${r.status}.` };
  } catch { return { ok: false, login: '', message: 'Could not reach GitHub. Check the internet and try again.' }; }
}

export async function publishToGithub(i: PublishInput): Promise<PublishResult> {
  const f = i.fetch ?? fetch;
  if (!REPO_NAME.test(i.repo)) throw new GhError('The repository name can only use letters, numbers, dots, dashes and underscores.');
  if (!/^[\w-]+$/.test(i.modId)) throw new GhError('That mod id cannot be used as a folder name.');
  const gh = client(i.token, f);
  const me = await gh.must('GET', '/user', undefined, 'Asking GitHub who you are');
  const owner = String(me.login);
  const base = `/repos/${owner}/${i.repo}`;

  // the repo: found, or made (public, with a README so it has a first commit)
  let created = false;
  let repo = await gh.call('GET', base);
  if (repo.status === 404) {
    const mk = await gh.call('POST', '/user/repos', { name: i.repo, description: 'Minecraft Fabric mods made with Forge. One folder per mod, a release per version.', private: false, auto_init: true });
    if (mk.status !== 201) throw new GhError(`Could not create the repository (${mk.status}: ${String(mk.json?.message ?? '').slice(0, 120)}). Make an empty public repository called ${i.repo} on GitHub with "Add a README" ticked, then press the button again.`);
    repo = mk; created = true;
  } else if (repo.status !== 200) throw new GhError(`GitHub said ${repo.status} when looking for the repository.`);
  if (repo.json?.private) throw new GhError(`${i.repo} is a private repository. Mods are published to a public one, so make it public or choose another name in Settings.`);
  const branch = String(repo.json?.default_branch ?? 'main');

  // where the branch is now
  let head = await gh.call('GET', `${base}/git/ref/heads/${branch}`);
  for (let t = 0; created && head.status !== 200 && t < 5; t++) { await new Promise((r) => setTimeout(r, 600)); head = await gh.call('GET', `${base}/git/ref/heads/${branch}`); }
  if (head.status !== 200) throw new GhError(`The repository has no commits yet. Add a README to ${i.repo} on GitHub, then press the button again.`);
  const parent = String(head.json.object.sha);
  const section = i.changelogEntry.trim();
  let commit = parent;
  if (!i.releaseOnly) {
  const parentCommit = await gh.must('GET', `${base}/git/commits/${parent}`, undefined, 'Reading the latest commit');
  const treeSha = String(parentCommit.tree.sha);
  const old = await gh.must('GET', `${base}/git/trees/${treeSha}?recursive=1`, undefined, 'Reading the repository');
  const prefix = i.modId + '/';
  const oldFiles: { path: string; sha: string }[] = (old.tree ?? []).filter((e: any) => e.type === 'blob' && String(e.path).startsWith(prefix)).map((e: any) => ({ path: String(e.path), sha: String(e.sha) }));

  // the changelog keeps every version: the new section goes on top of what is already there
  const files = i.files.filter((x) => x.path !== 'CHANGELOG.md');
  const oldLog = oldFiles.find((x) => x.path === prefix + 'CHANGELOG.md');
  let history = '';
  if (oldLog) { const b = await gh.call('GET', `${base}/git/blobs/${oldLog.sha}`); if (b.status === 200) history = Buffer.from(String(b.json.content ?? ''), 'base64').toString('utf8').replace(/^# Changelog\s*/i, ''); }
  const sameVersion = new RegExp(`^## ${i.version.replace(/\./g, '\\.')}\\b`, 'm');
  const log = `# Changelog\n\n${section}\n\n${history.split(/\r?\n/).join('\n').split(/(?=^## )/m).filter((s) => s.trim() && !sameVersion.test(s)).join('').trim()}\n`.replace(/\n{3,}/g, '\n\n');
  files.push({ path: 'CHANGELOG.md', data: Buffer.from(log) });

  // one commit with the whole folder; files that no longer exist are removed
  const entries: { path: string; mode: string; type: string; sha: string | null }[] = [];
  for (let k = 0; k < files.length; k += 4) {
    await Promise.all(files.slice(k, k + 4).map(async (file) => {
      const b = await gh.must('POST', `${base}/git/blobs`, { content: file.data.toString('base64'), encoding: 'base64' }, `Uploading ${file.path}`);
      entries.push({ path: prefix + file.path, mode: '100644', type: 'blob', sha: String(b.sha) });
    }));
  }
  for (const o of oldFiles) if (!entries.some((e) => e.path === o.path)) entries.push({ path: o.path, mode: '100644', type: 'blob', sha: null });
  const tree = await gh.must('POST', `${base}/git/trees`, { base_tree: treeSha, tree: entries }, 'Building the folder');
  const unchanged = String(tree.sha) === treeSha;
  if (!unchanged) {
    const c = await gh.must('POST', `${base}/git/commits`, { message: `${i.name} ${i.version}`, tree: tree.sha, parents: [parent] }, 'Saving the commit');
    commit = String(c.sha);
    await gh.must('PATCH', `${base}/git/refs/heads/${branch}`, { sha: commit }, 'Updating the branch');
  }
  }

  // the release with the jar
  const tag = `${i.modId}-v${i.version}`;
  const notes = `${section}\n\nMinecraft Fabric mod made with Forge.`;
  let rel = await gh.call('GET', `${base}/releases/tags/${encodeURIComponent(tag)}`);
  if (rel.status === 200) { await gh.call('PATCH', `${base}/releases/${rel.json.id}`, { name: `${i.name} ${i.version}`, body: notes }); }
  else {
    rel = await gh.call('POST', `${base}/releases`, { tag_name: tag, name: `${i.name} ${i.version}`, body: notes, target_commitish: commit, draft: false, prerelease: false });
    if (rel.status !== 201) throw new GhError(`Could not make the release (${rel.status}: ${String(rel.json?.message ?? '').slice(0, 120)}).`);
  }
  if (i.jar) {
    for (const a of (rel.json.assets ?? []) as { id: number; name: string }[]) if (a.name === i.jar.name) await gh.call('DELETE', `${base}/releases/assets/${a.id}`);
    const up = await gh.call('POST', `https://uploads.github.com/repos/${owner}/${i.repo}/releases/${rel.json.id}/assets?name=${encodeURIComponent(i.jar.name)}`, undefined, { 'Content-Type': 'application/java-archive' }, i.jar.data);
    if (up.status !== 201) throw new GhError(`The release was made but the jar did not upload (${up.status}: ${String(up.json?.message ?? '').slice(0, 120)}).`);
  }
  return { owner, repoUrl: `https://github.com/${owner}/${i.repo}`, folderUrl: `https://github.com/${owner}/${i.repo}/tree/${branch}/${i.modId}`, releaseUrl: String(rel.json.html_url ?? `https://github.com/${owner}/${i.repo}/releases/tag/${tag}`), commit, created };
}

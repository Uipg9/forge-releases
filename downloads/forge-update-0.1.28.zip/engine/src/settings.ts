// Secrets and settings Brian changes from inside the app.
// data/secrets.json: the app key (made up on first run) and the Claude API key. data/settings.json: the rest.
// Neither file ever leaves this machine.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomBytes } from 'node:crypto';
import { networkInterfaces } from 'node:os';
import { MODELS, LIMITS } from './config.ts';

export interface Secrets { token: string; anthropicKey: string; /** Optional: lets Forge publish finished mods to a public GitHub repo when you press the button. */ githubToken?: string; githubUser?: string }

export interface Settings {
  /** Monthly Claude (AI) budget in dollars. */
  aiBudget: number;
  /** Dollars one mod may spend before it parks (the monthly budget still applies on top). */
  modBudget: number;
  /** Simulated Minecraft days a soak test runs (100 is about 33 real hours of game time). */
  simDays: number;
  /** Minecraft asks everyone to accept its EULA before a server runs; Forge only ticks it if you say so. */
  eula: boolean;
  /** Look at other mods online before planning a new one (and credit them). */
  research: boolean;
  /** Also check that several players on one server work. Off by default: Brian plays single player. */
  multiplayer: boolean;
  /** The public GitHub repository (under your account) that finished mods are published to, one folder per mod. */
  githubRepo: string;
  /** Use the pretend build and test tools (no Java, no downloads): for trying the app out. */
  demo: boolean;
  startWithWindows: boolean;
  autoUpdate: boolean;
  sound: boolean;
  animations: boolean;
  fun: boolean;
  theme: 'dark' | 'light' | 'amoled';
}

const DEFAULT_SETTINGS: Settings = { aiBudget: LIMITS.aiBudget, modBudget: LIMITS.modBudget, simDays: LIMITS.soakDays, eula: false, multiplayer: false, research: true, githubRepo: 'forge-mods', demo: true, startWithWindows: false, autoUpdate: true, sound: true, animations: true, fun: false, theme: 'dark' };

export function applyLimits(st: Settings): void { LIMITS.aiBudget = st.aiBudget; LIMITS.modBudget = st.modBudget; LIMITS.soakDays = st.simDays; }

/** Checks a settings change from the app. Anything out of range is refused rather than guessed. */
export function cleanSettings(b: Record<string, unknown>): { ok: Partial<Settings>; problems: string[] } {
  const ok: Partial<Settings> = {};
  const problems: string[] = [];
  const int = (v: unknown, lo: number, hi: number) => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi ? Math.round(v) : null;
  for (const k of ['eula', 'multiplayer', 'research', 'demo', 'startWithWindows', 'autoUpdate', 'sound', 'animations', 'fun'] as const) if (k in b) { if (typeof b[k] === 'boolean') ok[k] = b[k] as boolean; else problems.push(`${k} must be on or off.`); }
  if ('aiBudget' in b) { const v = int(b.aiBudget, 1, 500); if (v === null) problems.push('The Claude budget must be $1 to $500 a month.'); else ok.aiBudget = v; }
  if ('modBudget' in b) { const v = b.modBudget; if (typeof v === 'number' && Number.isFinite(v) && v >= 0.5 && v <= 500) ok.modBudget = Math.round(v * 100) / 100; else problems.push('The per-mod budget must be $0.50 to $500.'); }
  if ('simDays' in b) { const v = int(b.simDays, 5, 1000); if (v === null) problems.push('Soak length must be 5 to 1000 Minecraft days.'); else ok.simDays = v; }
  if ('githubRepo' in b) { if (typeof b.githubRepo === 'string' && /^[A-Za-z0-9._-]{1,100}$/.test(b.githubRepo.trim())) ok.githubRepo = b.githubRepo.trim(); else problems.push('The repository name can only use letters, numbers, dots, dashes and underscores.'); }
  if ('theme' in b) { if (b.theme === 'dark' || b.theme === 'light' || b.theme === 'amoled') ok.theme = b.theme; else problems.push('Theme must be dark, light or amoled.'); }
  return { ok, problems };
}

function readJson<T>(file: string, fallback: T): T {
  try { return existsSync(file) ? { ...fallback, ...JSON.parse(readFileSync(file, 'utf8')) } : fallback; } catch { return fallback; }
}
function writeJson(file: string, data: unknown): void {
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(data, null, 1), { mode: 0o600 });
}

export class Config {
  secrets: Secrets;
  settings: Settings;
  private secretsFile: string;
  private settingsFile: string;
  constructor(dataDir: string) {
    this.secretsFile = dataDir + '/secrets.json';
    this.settingsFile = dataDir + '/settings.json';
    this.secrets = readJson<Secrets>(this.secretsFile, { token: '', anthropicKey: '' });
    this.settings = { ...DEFAULT_SETTINGS, ...readJson<Partial<Settings>>(this.settingsFile, {}) };
    applyLimits(this.settings);
    // Environment variables win (servers); otherwise the app key is made up once and kept.
    if (process.env.FORGE_TOKEN) this.secrets.token = process.env.FORGE_TOKEN;
    if (process.env.ANTHROPIC_API_KEY) this.secrets.anthropicKey = process.env.ANTHROPIC_API_KEY;
    if (!this.secrets.token) { this.secrets.token = makeToken(); this.saveSecrets(); }
  }
  saveSecrets(): void { writeJson(this.secretsFile, this.secrets); }
  saveSettings(): void { writeJson(this.settingsFile, this.settings); }
  githubHint(): string { return this.secrets.githubToken ? (this.secrets.githubUser || 'connected') : ''; }
  keyHint(): string { const k = this.secrets.anthropicKey; return k ? '…' + k.slice(-4) : ''; }
}

/** Easy to type on a phone: four groups of four letters and digits, no look-alikes (0/O, 1/l). */
export function makeToken(): string {
  const abc = 'abcdefghjkmnpqrstuvwxyz23456789';
  const b = randomBytes(16);
  let s = '';
  for (let i = 0; i < 16; i++) s += abc[b[i] % abc.length] + (i % 4 === 3 && i < 15 ? '-' : '');
  return s;
}

/** This machine's addresses on the local network, for pairing the phone. */
export function lanAddresses(port: number): string[] {
  const out: string[] = [];
  for (const list of Object.values(networkInterfaces())) for (const n of list ?? []) {
    if (n.family === 'IPv4' && !n.internal) out.push(`http://${n.address}:${port}`);
  }
  return out;
}

/** Checks a Claude key with the smallest possible request (one output token, about $0.00001). */
export async function checkClaudeKey(key: string, fetchImpl: typeof fetch = fetch): Promise<{ ok: boolean; message: string }> {
  const k = key.trim();
  if (!/^sk-ant-[\w-]{20,}$/.test(k)) return { ok: false, message: 'That doesn\'t look like a Claude API key. It should start with sk-ant- and be quite long.' };
  try {
    let note = 'Key works. The agents now use real Claude.';
    for (const model of [...new Set(Object.values(MODELS))]) {
      const res = await fetchImpl('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'x-api-key': k, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
        body: JSON.stringify({ model, max_tokens: 1, messages: [{ role: 'user', content: 'ping' }] }),
      });
      if (res.ok) continue;
      const body = await res.text().catch(() => '');
      const why = body.match(/"message"\s*:\s*"((?:[^"\\]|\\.)*)"/)?.[1] ?? '';
      if (res.status === 401) return { ok: false, message: 'Anthropic rejected that key. Copy it again from console.anthropic.com (it is only shown once when you create it).' };
      if (res.status === 403) return { ok: false, message: 'That key isn\'t allowed to use the API yet. Check the key\'s workspace in the console.' };
      if (res.status === 400 && /credit|billing/i.test(body)) return { ok: false, message: 'The key works, but the account has no credit. Add a payment method or credits under Billing in the console, then try again.' };
      if (res.status === 429) { note = 'Key works (Anthropic says slow down right now, which is fine).'; continue; }
      if (res.status === 404 || res.status === 400) return { ok: false, message: `The key works, but Claude doesn't accept the model "${model}" on this account${why ? ': ' + why.slice(0, 160) : ''}.` };
      return { ok: false, message: `Anthropic answered ${res.status} for ${model}. Try again in a minute.` };
    }
    return { ok: true, message: note };
  } catch {
    return { ok: false, message: 'Couldn\'t reach Anthropic. Check this computer\'s internet connection.' };
  }
}

// The Toolchain: what actually builds and tests a mod. Two implementations share one interface:
//  - GradleToolchain runs the real Fabric build and a real headless server on this computer.
//  - SimToolchain (sim/simtool.ts) pretends, for practice runs and the demo mode with no setup.
// Both share the static checks below, which really do read the generated files.
import { spawn, execFile } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import type { Layer, LayerResult, Project, VersionProfile } from './types.ts';
import { allowedPath, packageOf, toClass, type ModSpec } from './template.ts';
import { BOT_MOD, COMPANIONS, fetchMods, parseScenario, readIfThere, runScenario, suspectedMods, type ScenarioResult } from './gameplay.ts';

export interface BuildError { file: string; line: number; message: string; fingerprint: string }
export interface BuildResult { ok: boolean; ms: number; errors: BuildError[]; log: string }
export interface TestCtx { dir: string; project: Project; profile: VersionProfile; worker: number; eula: boolean; simDays: number; spec: ModSpec; /** The scenario script a Tester wrote (see gameplay.ts). Only the real toolchain plays it. */ scenario?: string }

/** Windows keeps a jar locked while any java still has it open, and a gradle build that is stopped leaves its game server running. This ends every java process started from this mod's folder and whatever still holds the test port, so the next run starts clean. */
export async function killStrays(dir: string, port = 25590): Promise<void> {
  if (process.platform !== 'win32') return;
  const d = dir.replace(/\//g, '\\').replace(/'/g, "''");
  const ps = `Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'java' -and $_.CommandLine -like '*${d}*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Get-NetTCPConnection -LocalPort ${port} -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }`;
  await new Promise<void>((res) => { try { execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 20000 }, () => res()); } catch { res(); } });
  await new Promise((r) => setTimeout(r, 600)); // let Windows release the files
}

/** Ends a process and everything it started (on Windows a plain kill leaves the game running). */
function killTree(child: { pid?: number; kill(): boolean }): void {
  try { if (process.platform === 'win32' && child.pid) spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true }); else child.kill(); } catch { try { child.kill(); } catch { /* gone */ } }
}

/** Removes a folder, waiting for Windows to let go of files a just-stopped game still holds (EBUSY, EPERM). A folder that stays locked is left alone when `lenient`. */
export async function rmRetry(path: string, lenient = false): Promise<void> {
  for (let i = 0; ; i++) {
    try { rmSync(path, { recursive: true, force: true, maxRetries: 3, retryDelay: 200 }); return; }
    catch (e) {
      const code = (e as NodeJS.ErrnoException).code;
      if (!['EBUSY', 'EPERM', 'ENOTEMPTY', 'EACCES'].includes(code ?? '') || i >= 25) { if (lenient) return; throw e; }
      await new Promise((r) => setTimeout(r, 400));
    }
  }
}

export interface Toolchain {
  name: string;
  /** Whether this computer can build for the profile, and what to do if not. */
  ready(profile: VersionProfile): Promise<{ ok: boolean; message: string }>;
  build(dir: string, project: Project, profile: VersionProfile): Promise<BuildResult>;
  test(layer: Layer, ctx: TestCtx): Promise<LayerResult>;
  /** What a scenario can do on this computer for this version: whether a bot player exists. */
  capabilities?(profile: VersionProfile): Promise<{ bot: boolean }>;
  /** Starts the real game (a development client) with the mod so a person can play it. Lines it prints go to onLine. */
  playtest?(dir: string, project: Project, profile: VersionProfile, onLine: (line: string) => void): Promise<{ stop(): void; done: Promise<number | null> }>;
}

/** javac and Gradle error lines into structured errors. The fingerprint ignores line numbers and paths. */
export function parseBuildOutput(out: string): BuildError[] {
  const errs: BuildError[] = [];
  const seen = new Set<string>();
  for (const m of out.matchAll(/^(.+?\.java):(\d+): error: (.+)$/gm)) {
    const msg = m[3].trim();
    const fp = (m[1].split(/[\\/]/).pop() ?? '') + '|' + msg.replace(/\d+/g, '#');
    if (seen.has(fp)) continue;
    seen.add(fp);
    errs.push({ file: m[1].replace(/\\/g, '/'), line: Number(m[2]), message: msg, fingerprint: fp });
  }
  if (!errs.length && /BUILD FAILED|FAILURE: Build failed/.test(out)) {
    const why = out.match(/\* What went wrong:\s*\n([^\n]+(?:\n[^\n*][^\n]*)?)/)?.[1]?.trim() ?? 'Gradle build failed';
    errs.push({ file: '', line: 0, message: why.slice(0, 300), fingerprint: 'gradle|' + why.replace(/\d+/g, '#').slice(0, 120) });
  }
  return errs;
}

function walk(dir: string, base = dir): string[] {
  const out: string[] = [];
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    if (n === 'build' || n === '.gradle' || n === 'run') continue;
    const p = join(dir, n);
    if (statSync(p).isDirectory()) out.push(...walk(p, base));
    else out.push(relative(base, p).replace(/\\/g, '/'));
  }
  return out;
}

/** Things a mod made by an AI must never contain. Checked on every file before anything is built. */
const FORBIDDEN: [RegExp, string][] = [
  [/Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*exec|new\s+ProcessBuilder/, 'starts other programs'],
  [/System\s*\.\s*exit\s*\(/, 'shuts the game down'],
  [/openConnection\s*\(|HttpClient\.newBuilder|new\s+Socket\s*\(/, 'makes network connections (not in the spec)'],
  [/Files\s*\.\s*(delete|walkFileTree)|\.deleteOnExit\s*\(/, 'deletes files'],
  [/sun\.misc\.Unsafe|setAccessible\s*\(\s*true\s*\)/, 'uses unsafe reflection'],
];

/** Real checks on the files themselves: valid JSON, entry class, mixin list, package lines, braces, forbidden calls. */
export function staticChecks(dir: string, spec: ModSpec, profile: VersionProfile): string[] {
  const errors: string[] = [];
  const read = (p: string) => readFileSync(join(dir, p), 'utf8');
  const files = walk(dir);
  const pkg = packageOf(spec.modId);
  let mod: { entrypoints?: { main?: string[] } } | null = null;
  try { mod = JSON.parse(read('src/main/resources/fabric.mod.json')); } catch { errors.push('fabric.mod.json is missing or is not valid JSON'); }
  const cls = toClass(spec.name);
  const entry = mod?.entrypoints?.main?.[0];
  if (mod && entry !== pkg + '.' + cls) errors.push(`fabric.mod.json entrypoint should stay ${pkg}.${cls}`);
  if (!files.includes(`src/main/java/${pkg.replace(/\./g, '/')}/${cls}.java`)) errors.push(`the entry class ${cls}.java is missing`);
  let mixins: string[] = [];
  try {
    const mj = JSON.parse(read(`src/main/resources/${spec.modId}.mixins.json`));
    mixins = [...(mj.mixins ?? []), ...(mj.client ?? []), ...(mj.server ?? [])];
    for (const m of mixins) if (!files.includes(`src/main/java/${pkg.replace(/\./g, '/')}/mixin/${m.replace(/\./g, '/')}.java`) && !files.includes(`src/client/java/${pkg.replace(/\./g, '/')}/mixin/${m.replace(/\./g, '/')}.java`)) errors.push(`the mixin list names ${m}, but that class doesn't exist`);
  } catch { errors.push(`${spec.modId}.mixins.json is missing or is not valid JSON`); }
  for (const f of files.filter((x) => x.endsWith('.java'))) {
    const txt = read(f);
    if (!allowedPath(f, spec) && f.startsWith('src/')) errors.push(`${f} is outside the mod's own folders`);
    const want = f.replace(/^src\/(main|client)\/java\//, '').replace(/\/[^/]+$/, '').replace(/\//g, '.');
    const have = txt.match(/^\s*package\s+([\w.]+)\s*;/m)?.[1];
    if (have !== want) errors.push(`${f}: package line should be "package ${want};"`);
    // braces outside of strings and comments
    const clean = txt.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '').replace(/"(?:\\.|[^"\\])*"/g, '""').replace(/'(?:\\.|[^'\\])'/g, "''");
    const open = (clean.match(/\{/g) ?? []).length, close = (clean.match(/\}/g) ?? []).length;
    if (open !== close) errors.push(`${f}: braces don't match (${open} open, ${close} closed)`);
    for (const [re, why] of FORBIDDEN) if (re.test(clean)) errors.push(`${f}: ${why}`);
    if (profile.unobfuscated && /\bnet\.minecraft\.class_\d+|\bmethod_\d+|\bfield_\d+/.test(clean)) errors.push(`${f}: uses obfuscated names, but ${profile.mc} is unobfuscated and uses official names`);
    if (!profile.unobfuscated && /import\s+net\.fabricmc\.yarn\./.test(clean)) errors.push(`${f}: uses Yarn names; this project uses Mojang names`);
  }
  return errors;
}

export function runProcess(cmd: string, args: string[], o: { cwd: string; env?: Record<string, string>; timeoutMs: number; onLine?: (l: string, send: (s: string) => void) => void; shell?: boolean }): Promise<{ code: number | null; out: string; timedOut: boolean }> {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd: o.cwd, env: { ...process.env, ...(o.env ?? {}) }, shell: o.shell ?? false, windowsHide: true });
    let out = '', buf = '', timedOut = false, done = false;
    const send = (s: string) => { try { child.stdin.write(s); } catch { /* closed */ } };
    const feed = (d: Buffer) => {
      const t = d.toString('utf8');
      out += t; if (out.length > 400_000) out = out.slice(-300_000);
      buf += t;
      let i: number;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); o.onLine?.(line, send); }
    };
    child.stdout.on('data', feed); child.stderr.on('data', feed);
    const timer = setTimeout(() => { timedOut = true; killTree(child); }, o.timeoutMs);
    const finish = (code: number | null) => { if (done) return; done = true; clearTimeout(timer); resolve({ code, out, timedOut }); };
    child.on('close', finish);
    child.on('error', (e) => { out += String(e); finish(-1); });
  });
}

/** Only one real server per mod folder at a time: they share a world folder and a port. */
const SERVER_LOCKS = new Map<string, Promise<unknown>>();
function withLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const next = (SERVER_LOCKS.get(key) ?? Promise.resolve()).catch(() => {}).then(fn);
  SERVER_LOCKS.set(key, next.catch(() => {}));
  return next;
}

export interface GradleOpts {
  /** Where downloaded helpers (the popular mods the compatibility check uses) are kept. */
  toolsDir?: string;
  fetch?: typeof fetch;
  /** Only for tests: what to start instead of `gradlew runClient`. */
  launchClient?: (dir: string, bin: string) => { cmd: string; args: string[] };
  /** Only for tests: what to start instead of `gradlew runServer`. */
  launch?: (dir: string, bin: string) => { cmd: string; args: string[] };
}

/** The real thing. Needs a JDK for the profile and Gradle (Forge fetches both into data/tools on first use). */
export class GradleToolchain implements Toolchain {
  name = 'gradle';
  gradle: () => Promise<{ bin: string; javaHome: string }>;
  private opts: GradleOpts;
  constructor(resolve: (p: VersionProfile) => Promise<{ bin: string; javaHome: string }>, opts: GradleOpts = {}) { this.opts = opts; this.gradle = async () => resolve(this.cur!); }
  cur: VersionProfile | null = null;
  private async tools(p: VersionProfile) { this.cur = p; return this.gradle(); }
  private cache(dir: string, mc: string) { return join(this.opts.toolsDir ?? join(dir, '.forge-cache'), 'companions', mc); }

  async ready(p: VersionProfile) {
    try { await this.tools(p); return { ok: true, message: `Java ${p.java} and Gradle are ready.` }; }
    catch (e) { return { ok: false, message: String(e instanceof Error ? e.message : e) }; }
  }
  async capabilities(p: VersionProfile): Promise<{ bot: boolean }> {
    if (!p.unobfuscated) return { bot: false };
    const got = await fetchMods([BOT_MOD], p.mc, this.cache('.', p.mc), this.opts.fetch);
    return { bot: got.jars.length > 0 };
  }
  async playtest(dir: string, _project: Project, p: VersionProfile, onLine: (line: string) => void): Promise<{ stop(): void; done: Promise<number | null> }> {
    const { bin, javaHome } = await this.tools(p);
    const l = this.opts.launchClient?.(dir, bin) ?? { cmd: bin, args: ['runClient', '--console=plain'] };
    const win = process.platform === 'win32';
    const child = spawn(l.cmd, l.args, { cwd: dir, env: { ...process.env, JAVA_HOME: javaHome }, shell: win && !this.opts.launchClient, windowsHide: false, detached: !win });
    let buf = '';
    const feed = (d: Buffer) => { buf += d.toString('utf8'); let i: number; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); onLine(line); } };
    child.stdout.on('data', feed); child.stderr.on('data', feed);
    const done = new Promise<number | null>((r) => { child.on('close', (c) => r(c)); child.on('error', (e) => { onLine('could not start: ' + e); r(-1); }); });
    const stop = () => {
      try { if (win && child.pid) spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true }); else if (child.pid) process.kill(-child.pid); else child.kill(); } catch { try { child.kill(); } catch { /* gone */ } }
    };
    return { stop, done };
  }
  async build(dir: string, _project: Project, p: VersionProfile): Promise<BuildResult> {
    const t0 = Date.now();
    const { bin, javaHome } = await this.tools(p);
    const r = await runProcess(bin, ['build', '--console=plain', '--warning-mode', 'summary'], { cwd: dir, env: { JAVA_HOME: javaHome }, timeoutMs: 20 * 60_000, shell: process.platform === 'win32' });
    const errors = r.code === 0 ? [] : parseBuildOutput(r.out);
    if (r.timedOut) errors.push({ file: '', line: 0, message: 'the build took more than 20 minutes and was stopped', fingerprint: 'timeout' });
    return { ok: r.code === 0, ms: Date.now() - t0, errors, log: r.out.slice(-6000) };
  }
  async test(layer: Layer, c: TestCtx): Promise<LayerResult> {
    const t0 = Date.now();
    const base = { layer, worker: c.worker, errors: [] as string[], ms: 0 };
    const done = (state: LayerResult['state'], detail: string, extra: Partial<LayerResult> = {}): LayerResult => ({ ...base, state, detail, ms: Date.now() - t0, ...extra });
    if (layer === 'static') {
      const errs = staticChecks(c.dir, c.spec, c.profile);
      return done(errs.length ? 'fail' : 'pass', errs.length ? `${errs.length} problems in the files` : 'files, JSON, mixin list and safety rules are fine', { errors: errs });
    }
    if (layer === 'boot' || layer === 'soak' || layer === 'scenario' || layer === 'compat') {
      if (!c.eula) return done('skipped', 'Accept the Minecraft EULA in Settings so Forge can start a test server for you.');
      if (layer === 'scenario' && !c.scenario) return done('skipped', 'no scenario script was written');
      return withLock(c.dir, () => this.server(layer, c, t0));
    }
    return done('skipped', layer === 'multiplayer' ? 'several bots on one server is not set up' : 'worked out by Forge from this mod\'s history');
  }

  /** Starts a real headless server with the mod. Boot: wait for "Done". Soak: then fast-forward game days with /tick sprint.
   *  Scenario: then play a script of commands and check what the server says. Compat: run beside popular mods, then a short fast-forward. */
  private async server(layer: 'boot' | 'soak' | 'scenario' | 'compat', c: TestCtx, t0: number): Promise<LayerResult> {
    const { bin, javaHome } = await this.tools(c.profile);
    const run = join(c.dir, 'run');
    mkdirSync(run, { recursive: true });
    await killStrays(c.dir); // a server from an earlier run may still hold the jars, the world and the port
    for (const d of ['world', 'mods', 'crash-reports']) await rmRetry(join(run, d), d === 'crash-reports');
    writeFileSync(join(run, 'eula.txt'), 'eula=true\n');
    writeFileSync(join(run, 'server.properties'), 'online-mode=false\nserver-port=25590\nlevel-type=minecraft\\:flat\ngenerator-settings={"layers":[{"block":"minecraft\\:bedrock","height":1},{"block":"minecraft\\:dirt","height":2},{"block":"minecraft\\:grass_block","height":1}],"biome":"minecraft\\:plains"}\nspawn-protection=0\nview-distance=4\nsimulation-distance=4\nenable-command-block=false\n');
    const quick = (state: LayerResult['state'], detail: string, extra: Partial<LayerResult> = {}): LayerResult => ({ layer, worker: c.worker, errors: [], state, detail, ms: Date.now() - t0, ...extra });
    // helper mods are loaded straight from the mods folder, which only works when Minecraft has no obfuscation (26.x and later)
    let companions: string[] = [], bot = false;
    if (layer === 'compat' || layer === 'scenario') {
      if (!c.profile.unobfuscated) { if (layer === 'compat') return quick('skipped', `running beside other mods is not set up for ${c.profile.mc} yet`); }
      else {
        const got = await fetchMods(layer === 'compat' ? COMPANIONS : [BOT_MOD], c.profile.mc, this.cache(c.dir, c.profile.mc), this.opts.fetch);
        if (layer === 'compat' && !got.jars.length) return quick('skipped', `none of the popular mods have a ${c.profile.mc} version yet (${got.missing.join(', ')})`);
        if (got.jars.length) {
          mkdirSync(join(run, 'mods'), { recursive: true });
          for (const j of got.jars) {
            const dest = join(run, 'mods', j.split(/[\\/]/).pop()!);
            for (let k = 0; ; k++) {
              try { copyFileSync(j, dest); break; }
              catch (e) {
                if (existsSync(dest) && statSync(dest).size === statSync(j).size) break; // locked, but it is already this jar
                if (k >= 6) { if (layer === 'compat') return quick('skipped', 'a helper mod file stayed locked by Windows, so this check was skipped'); got.jars.length = 0; got.names.length = 0; break; } // scenario: carry on without the bot rather than stop
                if (k === 2) await killStrays(c.dir);
                await new Promise((r) => setTimeout(r, 700));
              }
            }
          }
          companions = got.names; bot = layer === 'scenario' && got.jars.length > 0;
        }
      }
    }
    const steps = layer === 'scenario' ? parseScenario(c.scenario ?? '').steps : [];
    const days = layer === 'soak' ? c.simDays : 0;
    const chunk = Math.max(1, Math.round(days / 10));
    const series: NonNullable<LayerResult['series']> = [];
    const problems: string[] = [], lines: string[] = [];
    const mine = new RegExp(`${c.spec.modId.replace(/[^\w]/g, '.')}|${packageOf(c.spec.modId).replace(/\./g, '\\.')}`, 'i');
    let doneAt = 0, simmed = 0, sprint = false, crashed = false, exited = false;
    let driver: Promise<void> | null = null;
    let played: ScenarioResult | null = null;
    const launch = this.opts.launch?.(c.dir, bin) ?? { cmd: bin, args: ['runServer', '--console=plain'] };
    const proc = runProcess(launch.cmd, launch.args, {
      cwd: c.dir, env: { JAVA_HOME: javaHome }, timeoutMs: layer === 'boot' ? 10 * 60_000 : layer === 'soak' ? 45 * 60_000 : 20 * 60_000, shell: process.platform === 'win32' && !this.opts.launch,
      onLine: (line, send) => {
        if (lines.length < 60_000) lines.push(line.slice(0, 400));
        if (/\bException\b|\bERROR\b|Mixin apply failed|Caught exception/.test(line) && !/ModLauncher|DEPRECAT/i.test(line) && (layer !== 'compat' || mine.test(line))) problems.push(line.slice(0, 220));
        if (/Crash report saved|This crash report/.test(line)) crashed = true;
        if (/\bDone \(/.test(line) && !doneAt) {
          doneAt = Date.now();
          if (layer === 'boot') send('stop\n');
          else if (layer === 'compat') { sprint = true; send('tick sprint 3000\n'); }
          else if (layer === 'scenario') {
            driver = runScenario(steps, { send: (s) => send(s), lines: () => lines, sleep: (ms) => new Promise((r) => setTimeout(r, ms)), alive: () => !exited }).then((r) => { played = r; send('stop\n'); });
          } else { sprint = true; send(`tick sprint ${chunk}d\n`); }
        }
        const m = line.match(/Sprint completed with ([\d.]+) ticks per second, or ([\d.]+) ms per tick/i);
        if (m && sprint) {
          if (layer === 'compat') { sprint = false; simmed = 1; send('stop\n'); return; }
          simmed += chunk;
          series.push({ day: simmed, tickMs: Number(m[2]), memMb: 0 });
          if (simmed >= days) { sprint = false; send('stop\n'); } else send(`tick sprint ${Math.min(chunk, days - simmed)}d\n`);
        }
      },
    });
    void proc.then(() => { exited = true; });
    const r = await proc;
    if (driver) await driver;
    const tail = () => lines.slice(-8).map((l) => l.slice(0, 160)).join(' | ');
    const report = (() => { try { const d = join(run, 'crash-reports'); const f = readdirSync(d).sort().pop(); return f ? readIfThere(join(d, f)) : ''; } catch { return ''; } })();
    await killStrays(c.dir); // the server is done: make sure nothing of it is left holding files
    await rmRetry(join(run, 'mods'), true);

    if (layer === 'compat') {
      const suspects = suspectedMods(report);
      const blamed = mine.test(suspects) || problems.length > 0;
      if (!blamed && (!doneAt || crashed || r.timedOut)) return quick('skipped', `the popular mods did not start on their own with ${c.profile.mc} (${companions.join(', ')}), so this mod could not be judged`);
      const errors = [...problems.slice(0, 8)]; if (mine.test(suspects)) errors.push('crash report names this mod: ' + suspects.replace(/\s+/g, ' ').slice(0, 160));
      const ok = doneAt > 0 && !crashed && !r.timedOut && !blamed && simmed >= 1;
      return quick(ok ? 'pass' : 'fail', ok ? `ran beside ${companions.join(', ')} for 2.5 game minutes with no errors from this mod` : errors[0] ?? 'failed beside popular mods', { errors, crashes: crashed ? 1 : 0 });
    }
    if (layer === 'scenario') {
      const pl = played as ScenarioResult | null;
      if (pl && pl.badCommands.length) return quick('skipped', `the script had ${pl.badCommands.length} command(s) the server did not understand`, { badScript: pl.badCommands });
      const errors = [...(pl?.failures ?? []), ...problems.slice(0, 6)];
      if (!doneAt) errors.push('the server never finished starting. Its last output: ' + tail());
      if (crashed) errors.push('the game crashed while the scenario ran');
      if (r.timedOut) errors.push('the scenario took too long and was stopped');
      const ok = !!pl && !errors.length;
      return quick(ok ? 'pass' : 'fail', ok ? `played on a real server: ${pl!.pass} of ${pl!.total} checks passed${bot ? ' (a bot player was available)' : ''}` : errors[0] ?? 'failed', { errors, assertions: pl ? { pass: pl.pass, total: pl.total } : undefined, crashes: crashed ? 1 : 0 });
    }
    const ok = doneAt > 0 && !crashed && !r.timedOut && problems.length === 0 && (layer === 'boot' || simmed >= days);
    const errors = [...problems.slice(0, 8)];
    if (!doneAt) errors.push('the server never finished starting. Its last output: ' + tail());
    if (crashed) errors.push('the game crashed');
    if (r.timedOut) errors.push('the test took too long and was stopped' + (doneAt ? '' : '. Its last output: ' + tail()));
    if (layer === 'soak' && simmed < days && !crashed) errors.push(`only ${simmed} of ${days} game days ran`);
    return quick(ok ? 'pass' : 'fail', ok ? (layer === 'boot' ? 'server started with the mod and stopped cleanly' : `${days} game days (${days * 24000} ticks) with no errors`) : errors[0] ?? 'failed',
      { errors, series: layer === 'soak' ? series : undefined, simDays: layer === 'soak' ? simmed : undefined, crashes: crashed ? 1 : 0 });
  }
}

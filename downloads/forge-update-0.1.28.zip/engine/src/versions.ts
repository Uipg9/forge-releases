// Version profiles. Each Minecraft version is its own profile: Java, Loom, mappings, loader, Fabric API.
// The Scout refreshes these from Fabric's own servers; until it has, `verified` stays false and the
// numbers below are only starting points. Facts here come from the Fabric blog and docs (26.1 porting guide,
// 1.21.11 release post) and Minecraft's release notes: 26.x needs Java 25, is unobfuscated (no remapping),
// and uses the Loom plugin id net.fabricmc.fabric-loom; 1.21.11 uses Java 21, fabric-loom and Mojang mappings.
import type { VersionProfile } from './types.ts';

export const BUNDLED_PROFILES: VersionProfile[] = [
  { mc: '26.3', name: 'Wilderness Bound', java: 25, loomId: 'net.fabricmc.fabric-loom', loom: '', unobfuscated: true, loader: '0.20.1', fabricApi: '', status: 'supported', verified: false, releasedAt: '2026-09-15',
    notes: ['Latest release. Java 25 is required.', 'Unobfuscated: no mappings and no remapJar.'] },
  { mc: '26.2', name: 'Chaos Cubed', java: 25, loomId: 'net.fabricmc.fabric-loom', loom: '', unobfuscated: true, loader: '0.20.1', fabricApi: '', status: 'supported', verified: false, releasedAt: '2026-06-16',
    notes: ['Previous release (kept supported alongside the latest).'] },
  { mc: '26.1', name: 'Tiny Takeover', java: 25, loomId: 'net.fabricmc.fabric-loom', loom: '', unobfuscated: true, loader: '0.19.5', fabricApi: '', status: 'testing', verified: false, releasedAt: '2026-03-24',
    notes: ['First unobfuscated release. Mods for 1.21.11 and older do not work on it, even as compile-only dependencies.'] },
  { mc: '1.21.11', name: 'Mounts of Mayhem', java: 21, loomId: 'fabric-loom', loom: '1.14.10', unobfuscated: false, loader: '0.18.1', fabricApi: '', status: 'supported', verified: false, releasedAt: '2025-12-09',
    notes: ['Last obfuscated release: Mojang mappings, remapped at build time. Fabric recommended Loom 1.14 for it.'] },
];

export const DEFAULT_PROFILE = '26.3';

export function profileFor(profiles: VersionProfile[], mc: string): VersionProfile | undefined {
  return profiles.find((p) => p.mc === mc);
}

/** Compares Minecraft versions: "26.3" > "26.1.2" > "1.21.11". */
export function cmpMc(a: string, b: string): number {
  const p = (v: string) => v.split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) - (y[i] ?? 0);
  return 0;
}

/** A release number like 26.3 or 1.21.11 (not a snapshot, pre-release or release candidate). */
export function isRelease(v: string): boolean { return /^\d+\.\d+(\.\d+)?$/.test(v); }

function lastTag(xml: string, tag: string): string | null {
  const all = [...xml.matchAll(new RegExp(`<${tag}>([^<]+)</${tag}>`, 'g'))].map((m) => m[1]);
  return all.length ? all[all.length - 1] : null;
}

export interface ScoutResult {
  profiles: VersionProfile[];
  newVersions: string[];
  /** What it could and couldn't read, for the Versions screen. */
  log: string[];
  ok: boolean;
}

/**
 * The Scout: reads Fabric's metadata and Maven listings and updates the profiles. Anything it can't read
 * keeps its old value and stays unverified. A Minecraft release it doesn't know about becomes a new
 * "testing" profile (and the Foreman will ask whether to support it).
 */
export async function scout(current: VersionProfile[], f: typeof fetch = fetch): Promise<ScoutResult> {
  const log: string[] = [];
  const profiles = current.map((p) => ({ ...p, notes: [...p.notes] }));
  const get = async (url: string): Promise<string | null> => {
    try {
      const r = await f(url, { signal: AbortSignal.timeout(15_000) });
      if (!r.ok) { log.push(`${url} answered ${r.status}`); return null; }
      return await r.text();
    } catch { log.push(`couldn't reach ${url}`); return null; }
  };
  const [gameTxt, loaderTxt, apiXml, loomMarker, loomLegacy] = await Promise.all([
    get('https://meta.fabricmc.net/v2/versions/game'),
    get('https://meta.fabricmc.net/v2/versions/loader'),
    get('https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/maven-metadata.xml'),
    get('https://maven.fabricmc.net/net/fabricmc/fabric-loom/net.fabricmc.fabric-loom.gradle.plugin/maven-metadata.xml'),
    get('https://maven.fabricmc.net/fabric-loom/fabric-loom.gradle.plugin/maven-metadata.xml'),
  ]);
  const newVersions: string[] = [];
  let verifiedAny = false;
  if (loaderTxt) {
    try {
      const l = (JSON.parse(loaderTxt) as { version: string; stable: boolean }[]).find((x) => x.stable);
      if (l) { for (const p of profiles) p.loader = l.version; verifiedAny = true; log.push(`Fabric Loader ${l.version}`); }
    } catch { log.push('loader list was not readable'); }
  }
  const loomNew = loomMarker ? lastTag(loomMarker, 'release') ?? lastTag(loomMarker, 'version') : null;
  const loomOld = loomLegacy ? lastTag(loomLegacy, 'release') ?? lastTag(loomLegacy, 'version') : null;
  if (loomNew) log.push(`Loom (26.x) ${loomNew}`);
  if (loomOld) log.push(`Loom (1.21.x) ${loomOld}`);
  if (apiXml) {
    const versions = [...apiXml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
    for (const p of profiles) {
      const mine = versions.filter((v) => v.endsWith('+' + p.mc));
      if (mine.length) { p.fabricApi = mine[mine.length - 1]; verifiedAny = true; }
    }
    log.push('Fabric API versions read');
  }
  for (const p of profiles) {
    if (p.unobfuscated && loomNew) p.loom = loomNew;
    if (!p.unobfuscated && loomOld && !p.loom) p.loom = loomOld;
    p.verified = !!(p.loom && p.fabricApi && loaderTxt);
  }
  if (gameTxt) {
    try {
      const games = (JSON.parse(gameTxt) as { version: string; stable: boolean }[]).filter((g) => g.stable && isRelease(g.version));
      const newest = games.map((g) => g.version).sort(cmpMc).pop();
      for (const g of games) {
        if (cmpMc(g.version, '26.1') >= 0 && !profiles.some((p) => p.mc === g.version) && !/^26\.\d+\.\d+$/.test(g.version)) {
          profiles.push({ mc: g.version, name: '', java: 25, loomId: 'net.fabricmc.fabric-loom', loom: loomNew ?? '', unobfuscated: true, loader: profiles[0]?.loader ?? '', fabricApi: '', status: 'testing', verified: false,
            notes: ['New release found by the Scout. Needs its canary builds to pass before it is supported.'] });
          newVersions.push(g.version);
        }
      }
      if (newest) log.push(`Newest Minecraft release on Fabric: ${newest}`);
    } catch { log.push('game list was not readable'); }
  }
  profiles.sort((a, b) => cmpMc(b.mc, a.mc));
  return { profiles, newVersions, log, ok: verifiedAny };
}

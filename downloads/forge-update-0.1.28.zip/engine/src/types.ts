// Shared types for the Forge engine. One file so every module speaks the same language.

/** The agents. Brian only ever talks to the Foreman; the rest are helpers the Foreman hands work to. */
export type AgentId = 'foreman' | 'coder' | 'builder' | 'tester' | 'scout' | 'publisher';
export const AGENTS: AgentId[] = ['foreman', 'coder', 'builder', 'tester', 'scout', 'publisher'];

/** Which model tier an agent call uses. */
export type Tier = 'worker' | 'thinker';

export interface ToolCall { id: string; name: string; args: Record<string, unknown> }

export interface Msg {
  role: 'user' | 'assistant';
  text?: string;
  toolCalls?: ToolCall[];
  toolResults?: { id: string; ok: boolean; content: string }[];
}

export interface ModelReply {
  text: string;
  toolCalls: ToolCall[];
  usage: { input: number; cachedInput: number; output: number };
  done: boolean;
}

export interface ToolSpec {
  name: string;
  description: string;
  params: Record<string, { type: 'string' | 'number' | 'boolean'; description: string; optional?: boolean }>;
}

/** What kind of mod. Vanilla Plus is the default: Mixin-first, no new assets, logic over content. */
export type Mode = 'vanilla-plus' | 'content' | 'library' | 'client' | 'server';
export const MODES: Mode[] = ['vanilla-plus', 'content', 'library', 'client', 'server'];

export interface VersionProfile {
  /** Minecraft version, for example "26.3" or "1.21.11". */
  mc: string;
  name: string;
  java: number;
  /** Loom plugin id: "net.fabricmc.fabric-loom" (26.1 and newer, no remapping) or "fabric-loom". */
  loomId: string;
  loom: string;
  /** 26.1 and newer ship unobfuscated, so there is no remapping step. */
  unobfuscated: boolean;
  loader: string;
  fabricApi: string;
  status: 'supported' | 'testing' | 'unsupported';
  /** False until the Scout has read these numbers from Fabric's own servers (or a real build passed). */
  verified: boolean;
  releasedAt?: string;
  notes: string[];
}

/** The seven test layers (see the playtesting standard). */
export type Layer = 'static' | 'boot' | 'scenario' | 'soak' | 'compat' | 'multiplayer' | 'regression';
export const LAYERS: Layer[] = ['static', 'boot', 'scenario', 'soak', 'compat', 'multiplayer', 'regression'];

export interface LayerResult {
  layer: Layer;
  state: 'pass' | 'fail' | 'skipped';
  ms: number;
  detail: string;
  /** Which tester worker ran it. */
  worker: number;
  /** Failing log lines or error text, for the Coder. */
  errors: string[];
  /** Metrics for the test visuals (soak): per simulated day. */
  series?: { day: number; tickMs: number; memMb: number }[];
  simDays?: number;
  crashes?: number;
  assertions?: { pass: number; total: number };
  /** True when Claude read the code instead of a bot playing the mod. */
  read?: boolean;
  /** Scenario script commands the server did not understand (the script, not the mod, is probably wrong). */
  badScript?: string[];
  /** This layer is turned off on purpose (for example multiplayer, for someone who plays single player). */
  off?: boolean;
}

export type Stage = 'queued' | 'research' | 'spec' | 'code' | 'build' | 'test' | 'review' | 'ready' | 'built' | 'waiting' | 'parked' | 'shipped' | 'stopped';

export interface FileRec { path: string; by: AgentId; bytes: number; purpose: string }

export interface Project {
  id: string;
  name: string;
  modId: string;
  idea: string;
  mode: Mode;
  profile: string;
  stage: Stage;
  /** What it is waiting on, or why it was parked. */
  note: string;
  spec: string;
  files: FileRec[];
  createdAt: number;
  updatedAt: number;
  rounds: { build: number; test: number };
  layers: Partial<Record<Layer, LayerResult>>;
  tokens: number;
  cost: number;
  /** Past bugs that became permanent regression checks. */
  regress: string[];
  version: string;
  shippedTo?: string;
  /** Where the last GitHub publish put this mod (its folder in the public repo), and the release page for that version. */
  githubUrl?: string;
  githubRelease?: string;
  /** The GitHub release page for each version that has been published there. */
  githubReleases?: Record<string, string>;
  fingerprints: Record<string, number>;
  /** Autopilot bookkeeping: improvement passes made, and times a parked or stuck mod was retried on its own. */
  lastChange?: string;
  autoRounds?: number;
  autoRetries?: number;
  /** What the Coder already tried for test failures, so the next fix does something different. */
  attempts?: string[];
  /** How many times Autopilot rebuilt this mod as a smaller, simpler version after it kept failing. */
  rescues?: number;
  /** What other mods already do, found online before planning, and who gets credit. */
  research?: { summary: string; refs: { name: string; url: string; license: string; reuse: 'code' | 'idea'; note: string }[]; at: number; /** The second look, after planning, has been done. */ afterDone?: boolean; /** What the Researcher searched and read, with how it went. */ log?: string[] };
}

export type CardKind = 'scope' | 'port' | 'publish' | 'setup' | 'idea' | 'stuck';

export interface ApprovalCard {
  id: string;
  kind: CardKind;
  agent: AgentId;
  project?: string;
  title: string;
  why: string;
  ifYes: string;
  ifNo: string;
  action: { type: string; args: Record<string, unknown> };
  createdAt: number;
  expiresAt: number | null;
  status: 'waiting' | 'approved' | 'declined' | 'later' | 'timed_out' | 'done';
  outcome?: string;
}

export interface EventRec {
  n: number;
  at: number;
  agent: AgentId | 'system' | 'you';
  kind: 'say' | 'tool' | 'stage' | 'layer' | 'build' | 'card' | 'alert' | 'version' | 'ship' | 'block';
  text: string;
  project?: string;
  data?: Record<string, unknown>;
}

export interface ChatMsg { at: number; from: 'you' | 'foreman'; text: string; project?: string; /** The Foreman spoke first, without being asked. */ proactive?: boolean }

export interface AgentStatus { id: AgentId; state: 'idle' | 'working' | 'waiting'; doing: string; project?: string; since: number; tokensToday: number; worker?: number }

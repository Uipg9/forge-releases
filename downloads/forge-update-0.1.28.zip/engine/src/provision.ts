// Gets a JDK and Gradle onto this computer the first time (into data/tools), so Brian installs nothing by hand.
// The URLs are built here and unit tested; the downloads only run on a real computer with internet.
import { existsSync, mkdirSync, readdirSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { runProcess } from './build.ts';
import type { VersionProfile } from './types.ts';

export function jdkUrl(java: number, platform: NodeJS.Platform = process.platform, arch: string = process.arch): string {
  const os = platform === 'win32' ? 'windows' : platform === 'darwin' ? 'mac' : 'linux';
  const a = arch === 'arm64' ? 'aarch64' : 'x64';
  return `https://api.adoptium.net/v3/binary/latest/${java}/ga/${os}/${a}/jdk/hotspot/normal/eclipse`;
}
export const gradleUrl = (version: string): string => `https://services.gradle.org/distributions/gradle-${version}-bin.zip`;
export const GRADLE_CURRENT_URL = 'https://services.gradle.org/versions/current';

async function download(url: string, to: string, f: typeof fetch): Promise<void> {
  const r = await f(url, { redirect: 'follow', signal: AbortSignal.timeout(10 * 60_000) });
  if (!r.ok) throw new Error(`download failed (${r.status}) from ${new URL(url).host}`);
  writeFileSync(to, Buffer.from(await r.arrayBuffer()));
}

async function extract(archive: string, into: string): Promise<void> {
  mkdirSync(into, { recursive: true });
  // Windows 10 and newer ship bsdtar, which reads .zip; Linux and Mac tar reads .tar.gz.
  const zip = archive.endsWith('.zip') && process.platform !== 'win32';
  const r = zip
    ? await runProcess('unzip', ['-q', '-o', archive, '-d', into], { cwd: into, timeoutMs: 5 * 60_000 })
    : await runProcess('tar', ['-xf', archive, '-C', into], { cwd: into, timeoutMs: 5 * 60_000 });
  if (r.code !== 0) throw new Error('could not unpack ' + archive + ': ' + r.out.slice(-200));
}

function firstDir(dir: string): string {
  const d = readdirSync(dir, { withFileTypes: true }).find((e) => e.isDirectory());
  if (!d) throw new Error('unpacked folder is empty');
  return join(dir, d.name);
}

export interface Tools { bin: string; javaHome: string }

/** Resolves Java for the profile and a Gradle launcher, downloading what's missing. */
export function makeResolver(toolsDir: string, f: typeof fetch = fetch, onStatus: (s: string) => void = () => {}) {
  return async (p: VersionProfile): Promise<Tools> => {
    mkdirSync(toolsDir, { recursive: true });
    const win = process.platform === 'win32';
    // Java
    let javaHome = '';
    const jdkDir = join(toolsDir, 'jdk-' + p.java);
    if (existsSync(jdkDir) && readdirSync(jdkDir).length) javaHome = firstDir(jdkDir);
    else {
      onStatus(`Downloading Java ${p.java} (one time, about 200 MB)`);
      const arc = join(toolsDir, `jdk-${p.java}.${win ? 'zip' : 'tar.gz'}`);
      await download(jdkUrl(p.java), arc, f);
      await extract(arc, jdkDir);
      rmSync(arc, { force: true });
      javaHome = firstDir(jdkDir);
    }
    // Gradle
    const gradleDir = join(toolsDir, 'gradle');
    let gradleHome = '';
    if (existsSync(gradleDir) && readdirSync(gradleDir).length) gradleHome = firstDir(gradleDir);
    else {
      onStatus('Downloading Gradle (one time)');
      const cur = (await (await f(GRADLE_CURRENT_URL, { signal: AbortSignal.timeout(15_000) })).json()) as { version: string };
      const arc = join(toolsDir, `gradle-${cur.version}.zip`);
      await download(gradleUrl(cur.version), arc, f);
      await extract(arc, gradleDir);
      rmSync(arc, { force: true });
      gradleHome = firstDir(gradleDir);
    }
    return { bin: join(gradleHome, 'bin', win ? 'gradle.bat' : 'gradle'), javaHome };
  };
}

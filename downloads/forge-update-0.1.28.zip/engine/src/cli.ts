// Command line:
//   node --experimental-strip-types src/cli.ts serve [--port 8797]
//   node --experimental-strip-types src/cli.ts practice [--nights 30] [--seeds 1,2,3]
//   node --experimental-strip-types src/cli.ts sample          (build + soak a tiny real mod; needs internet and Java)
import { writeFileSync, mkdirSync, appendFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Store } from './store.ts';
import { Studio } from './studio.ts';
import { ClaudeClient } from './model.ts';
import { StandinModel } from './standin.ts';
import { practice } from './sim/practice.ts';
import { serve } from './server.ts';
import { VERSION } from './config.ts';
import { Updater } from './updates.ts';
import { Config, lanAddresses } from './settings.ts';
import { SimToolchain } from './sim/simtool.ts';
import { GradleToolchain } from './build.ts';
import { makeResolver } from './provision.ts';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const cmd = args[0] ?? 'serve';
const flag = (k: string, d: string) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };

if (cmd === 'practice') {
  const nights = Number(flag('nights', '30'));
  const seeds = flag('seeds', flag('seed', '1')).split(',').map(Number);
  mkdirSync(join(ROOT, 'reports'), { recursive: true });
  let all = true;
  for (const seed of seeds) {
    const res = await practice({ nights, seed });
    writeFileSync(join(ROOT, 'reports', `practice-seed${seed}.json`), JSON.stringify(res, null, 2));
    all &&= res.pass;
    console.log(`seed ${seed}: ${res.pass ? 'PASS' : 'FAIL'} | ${res.hours.total} h simulated (${res.hours.studioClock} h studio clock + ${res.hours.minecraftSoaked} h of Minecraft soaked) | mods ${JSON.stringify(res.mods)} | max parallel ${res.parallel.maxCoders} coders, ${res.parallel.maxTesters} testers | blocked ${res.guardrails.blockedWrites} | kills ${res.guardrails.killSwitchPulls}, restarts ${res.guardrails.restarts}`);
    for (const v of res.violations.slice(0, 20)) console.log('   ! ' + v);
  }
  process.exit(all ? 0 : 1);
}

if (cmd === 'sample') {
  // A real end-to-end check of the toolchain: makes the skeleton mod, builds it with Gradle, boots a real server, soaks a few game days.
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { skeleton } = await import('./template.ts');
  const { profileFor, BUNDLED_PROFILES, scout } = await import('./versions.ts');
  const live = await scout(BUNDLED_PROFILES, fetch);
  console.log('scout: ' + live.log.join('; '));
  const prof = profileFor(live.profiles, flag('profile', '26.3'))!;
  console.log(`profile: mc ${prof.mc} loom ${prof.loom} loader ${prof.loader} api ${prof.fabricApi}`);
  const dir = mkdtempSync(join(tmpdir(), 'forge-sample-'));
  const spec = { modId: 'sample_mod', name: 'Sample Mod', description: 'Forge toolchain check', mode: 'vanilla-plus' as const, version: '0.1.0' };
  for (const [p, t] of Object.entries(skeleton(prof, spec))) { mkdirSync(dirname(join(dir, p)), { recursive: true }); writeFileSync(join(dir, p), t); }
  const tc = new GradleToolchain(makeResolver(process.env.FORGE_TOOLS ?? join(ROOT, 'data', 'tools'), fetch, (m) => console.log('  ' + m)));
  const proj = { id: 'sample', name: spec.name, modId: spec.modId, regress: [] } as never;
  const days = Number(flag('days', '3'));
  const ctx = { dir, project: proj, profile: prof, worker: 1, eula: true, simDays: days, spec };
  let ok = true;
  const rd = await tc.ready(prof); console.log(`tools: ${rd.ok ? 'ok' : 'FAIL'} ${rd.message}`); ok &&= rd.ok;
  if (ok) { const b = await tc.build(dir, proj, prof); console.log(`build: ${b.ok ? 'ok' : 'FAIL'} ${b.errors.slice(0, 3).map((e) => e.message).join(' | ')}`); if (!b.ok) console.log(b.log.slice(-1500)); ok &&= b.ok; }
  if (ok) for (const l of ['static', 'boot', 'soak'] as const) { const r = await tc.test(l, ctx); console.log(`${l}: ${r.state} ${r.detail}${r.errors.length ? ' | ' + r.errors.slice(0, 3).join(' | ') : ''}`); ok &&= r.state === 'pass'; }
  console.log(ok ? `SAMPLE OK on Minecraft ${prof.mc}` : `SAMPLE FAILED on Minecraft ${prof.mc}`);
  process.exit(ok ? 0 : 1);
}

if (process.env.FORGE_LOG) {
  const file = process.env.FORGE_LOG;
  const write = (...a: unknown[]) => { try { appendFileSync(file, new Date().toISOString().slice(0, 19).replace('T', ' ') + ' ' + a.map((x) => (x instanceof Error ? x.stack ?? String(x) : String(x))).join(' ') + '\n'); } catch { /* skip */ } };
  console.log = write; console.error = write; console.warn = write;
  process.on('uncaughtException', (e) => { write('crash:', e); process.exit(1); });
}

if (cmd === 'serve') {
  const dataDir = process.env.FORGE_DATA ?? join(ROOT, 'data');
  const config = new Config(dataDir);
  const store = new Store(join(dataDir, 'state.json'));
  const port = Number(flag('port', process.env.PORT ?? '8797'));
  const fetchImpl = fetch;
  const studio = new Studio({
    store, dataDir, guidesDir: join(ROOT, 'src', 'guides'), now: () => Date.now(),
    settings: () => ({ eula: config.settings.eula, simDays: config.settings.simDays, aiBudget: config.settings.aiBudget, multiplayer: config.settings.multiplayer, research: config.settings.research }),
    model: () => new StandinModel({ seed: 'demo', mischief: 0.25, rogue: 0, stubborn: 0.05 }),
    toolchain: () => (config.settings.demo ? new SimToolchain(Number(flag('pace', '40'))) : new GradleToolchain(makeResolver(join(dataDir, 'tools'), fetchImpl, (m) => studio.say('builder', 'tool', m)), { toolsDir: join(dataDir, 'tools'), fetch: fetchImpl })),
    fetch: fetchImpl,
    githubToken: () => config.secrets.githubToken ?? '',
  });
  const quit = () => { store.save(); process.exit(0); };
  process.on('SIGINT', quit); process.on('SIGTERM', quit);
  const updater = process.env.FORGE_NO_UPDATES ? undefined : new Updater({
    version: VERSION, dataDir, url: process.env.FORGE_RELEASES,
    canInstall: (process.platform === 'win32' && !!process.env.FORGE_EXE) || process.env.FORGE_UPDATE_TEST === '1',
    beforeExit: () => store.save(),
  });
  serve(studio, { port, config, appDir: join(ROOT, 'app'), practiceModel: () => new StandinModel({ seed: 'demo', mischief: 0.25, rogue: 0, stubborn: 0.05 }), onQuit: quit, updater, tickMs: 30_000 });
  console.log(`Forge ${VERSION} on http://localhost:${port}  (${config.secrets.anthropicKey && !config.settings.demo ? 'Claude' : 'demo mode, pretend AI'})`);
  for (const a of lanAddresses(port)) console.log('  on your network: ' + a);
  console.log('  app key: ' + config.secrets.token);
  void ClaudeClient;
}
